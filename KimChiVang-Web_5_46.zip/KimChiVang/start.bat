@echo off
chcp 65001 >nul
title Kim Chi Vang - may chu gia
REM 1) Ma bi mat cho EA: nhap dung ma nay vao o Token cua EA KCV_PriceFeed
set KCV_TOKEN=doi-ma-bi-mat-nay
REM 2) Mat khau trang quan tri  kimchivang.com/quan-tri  (doi thanh mat khau rieng, khong dau)
set KCV_ADMIN=doi-mat-khau-quan-tri
REM 3) (Tuy chon) Tu gui tin lenh NOI BO vao nhom Telegram: dien token bot va ID nhom, de trong neu khong dung
set KCV_TG_TOKEN=
set KCV_TG_CHAT=
REM 4) (Tuy chon) Nhom Telegram RIENG cho khach dang ky dung thu / chot khach.
REM    Dien ID nhom (-100...) HOAC ten nhom/kenh CONG KHAI dang @TenNhom (bot phai la quan tri vien).
REM    De trong KCV_TG_LEAD_TOKEN = dung chung bot o muc 3. De trong KCV_TG_LEAD_CHAT = gui chung nhom lenh nhu cu.
set KCV_TG_LEAD_TOKEN=
set KCV_TG_LEAD_CHAT=
REM 5) (Tuy chon) Nhom Telegram nhan file SAO LUU moi ngay: dien @TenNhom hoac ID -100...
REM    Nhom @ (cong khai): file tu MA HOA bang mat khau quan tri (KCV_ADMIN), khoi phuc tai trang quan tri.
REM    De trong KCV_TG_BACKUP_TOKEN = dung chung bot o muc 3.
set KCV_TG_BACKUP_TOKEN=
set KCV_TG_BACKUP_CHAT=
set PORT=80
cd /d %~dp0
:loop
node server.js
echo May chu dung, tu khoi dong lai sau 5 giay...
timeout /t 5 >nul
goto loop
