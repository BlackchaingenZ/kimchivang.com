// ============================================================================
// SAO LƯU / KHÔI PHỤC DỮ LIỆU – không cần thư viện ngoài (zip + Telegram)
// ============================================================================
"use strict";
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

// Các file dữ liệu cần sao lưu (nằm cạnh server.js)
const DATA_FILES = ["codes.json", "leads.json", "sessions.json", "push.json", "vapid.json", "internal.json", "data.json"];
const KEEP = 30;                                   // giữ 30 bản sao lưu gần nhất

// ---------- CRC32 ----------
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(buf) { let c = 0xFFFFFFFF; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }

// ---------- tạo zip (nén deflate) ----------
function makeZip(entries) {                        // entries: [{name, data: Buffer, time: Date}]
  const parts = [], central = []; let off = 0;
  for (const e of entries) {
    const name = Buffer.from(e.name, "utf8"), raw = e.data, comp = zlib.deflateRawSync(raw, { level: 9 }), crc = crc32(raw);
    const d = e.time || new Date();
    const dosT = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
    const dosD = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    const h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(8, 8);
    h.writeUInt16LE(dosT, 10); h.writeUInt16LE(dosD, 12); h.writeUInt32LE(crc, 14); h.writeUInt32LE(comp.length, 18); h.writeUInt32LE(raw.length, 22); h.writeUInt16LE(name.length, 26);
    parts.push(h, name, comp);
    const c = Buffer.alloc(46);
    c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(8, 10);
    c.writeUInt16LE(dosT, 12); c.writeUInt16LE(dosD, 14); c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(raw.length, 24); c.writeUInt16LE(name.length, 28); c.writeUInt32LE(off, 42);
    central.push(c, name);
    off += 30 + name.length + comp.length;
  }
  const cs = central.reduce((a, b) => a + b.length, 0), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(cs, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat(parts.concat(central, [end]));
}

// ---------- đọc zip (hỗ trợ không nén và deflate, đọc qua thư mục trung tâm) ----------
function readZip(buf) {
  let e = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i--) if (buf.readUInt32LE(i) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error("File không phải bản sao lưu .zip hợp lệ");
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = {};
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error("File zip bị hỏng");
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nlen).toString("utf8");
    const lnl = buf.readUInt16LE(lo + 26), lxl = buf.readUInt16LE(lo + 28), ds = lo + 30 + lnl + lxl, data = buf.slice(ds, ds + csize);
    out[path.basename(name)] = method === 0 ? data : method === 8 ? zlib.inflateRawSync(data) : null;
    p += 46 + nlen + xlen + clen;
  }
  return out;
}

// ---------- tên file / thư mục ----------
const pad = x => (x < 10 ? "0" : "") + x;
function stamp(t) { const d = new Date(t + 7 * 3600000); return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate()) + "-" + pad(d.getUTCHours()) + pad(d.getUTCMinutes()); }
const NAME_RE = /^kcv-saoluu-\d{4}-\d{2}-\d{2}-\d{4}(-[a-z-]+)?\.zip$/;   // bản trên VPS (không mã hóa)

function listBackups(dir) {
  try {
    return fs.readdirSync(dir).filter(f => NAME_RE.test(f)).map(f => { const st = fs.statSync(path.join(dir, f)); return { name: f, size: st.size, t: st.mtimeMs }; })
      .sort((a, b) => b.t - a.t);
  } catch (e) { return []; }
}

// Tạo bản sao lưu: trả về { name, file, size, buf }
function createBackup(root, dir, tag) {
  fs.mkdirSync(dir, { recursive: true });
  const entries = [];
  for (const f of DATA_FILES) {
    const p = path.join(root, f);
    if (fs.existsSync(p)) entries.push({ name: f, data: fs.readFileSync(p), time: fs.statSync(p).mtime });
  }
  const cfg = path.join(root, "public", "config.js");
  if (fs.existsSync(cfg)) entries.push({ name: "config.js", data: fs.readFileSync(cfg), time: fs.statSync(cfg).mtime });
  entries.push({ name: "THONG-TIN.txt", data: Buffer.from("Bản sao lưu Kim Chỉ Vàng\r\nTạo lúc: " + stamp(Date.now()) + " (giờ VN)\r\nGồm: " + entries.map(x => x.name).join(", ") + "\r\nKhôi phục: trang /quan-tri → Dữ liệu & sao lưu → Khôi phục từ file.\r\n", "utf8") });
  const buf = makeZip(entries);
  const name = "kcv-saoluu-" + stamp(Date.now()) + (tag ? "-" + tag : "") + ".zip", file = path.join(dir, name);
  fs.writeFileSync(file + ".tmp", buf); fs.renameSync(file + ".tmp", file);
  // chỉ giữ KEEP bản gần nhất
  for (const old of listBackups(dir).slice(KEEP)) { try { fs.unlinkSync(path.join(dir, old.name)); } catch (e) {} }
  return { name, file, size: buf.length, buf };
}

// Kiểm tra file sao lưu trước khi khôi phục: trả về { files: {tên: Buffer} } hoặc ném lỗi
function inspectBackup(buf) {
  const z = readZip(buf), files = {};
  for (const f of DATA_FILES) {
    if (!z[f]) continue;
    try { JSON.parse(z[f].toString("utf8") || "null"); } catch (e) { throw new Error("File " + f + " trong bản sao lưu bị hỏng"); }
    files[f] = z[f];
  }
  if (!files["codes.json"]) throw new Error("Bản sao lưu không có codes.json – không phải file sao lưu Kim Chỉ Vàng");
  const codes = JSON.parse(files["codes.json"].toString("utf8"));
  if (!codes || !Array.isArray(codes.list)) throw new Error("codes.json trong bản sao lưu không đúng định dạng");
  return { files, codes: codes.list.length, leads: files["leads.json"] ? (JSON.parse(files["leads.json"].toString("utf8")).list || []).length : 0 };
}

// ---------- gửi file qua Telegram (sendDocument, multipart tự dựng) ----------
async function sendTelegramFile(token, chat, filename, buf, caption) {
  const b = "----kcv" + Date.now().toString(16), CRLF = "\r\n";
  const field = (k, v) => Buffer.from("--" + b + CRLF + 'Content-Disposition: form-data; name="' + k + '"' + CRLF + CRLF + v + CRLF, "utf8");
  const body = Buffer.concat([
    field("chat_id", chat), field("caption", caption || ""),
    Buffer.from("--" + b + CRLF + 'Content-Disposition: form-data; name="document"; filename="' + filename + '"' + CRLF + "Content-Type: application/zip" + CRLF + CRLF, "utf8"),
    buf, Buffer.from(CRLF + "--" + b + "--" + CRLF, "utf8")
  ]);
  const r = await fetch("https://api.telegram.org/bot" + token + "/sendDocument", { method: "POST", headers: { "Content-Type": "multipart/form-data; boundary=" + b }, body });
  if (!r.ok) throw new Error("Telegram " + r.status + ": " + (await r.text()).slice(0, 200));
  return true;
}

// ---------- mã hóa bản sao lưu (AES-256-GCM, khóa từ mật khẩu qua scrypt) ----------
const crypto = require("crypto");
const MAGIC = Buffer.from("KCVENC1");
const isEncrypted = buf => buf.length > 51 && buf.slice(0, 7).equals(MAGIC);
function encryptBackup(buf, password) {
  const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12), key = crypto.scryptSync(String(password), salt, 32);
  const c = crypto.createCipheriv("aes-256-gcm", key, iv), data = Buffer.concat([c.update(buf), c.final()]);
  return Buffer.concat([MAGIC, salt, iv, c.getAuthTag(), data]);
}
function decryptBackup(buf, password) {
  const salt = buf.slice(7, 23), iv = buf.slice(23, 35), tag = buf.slice(35, 51), data = buf.slice(51);
  const d = crypto.createDecipheriv("aes-256-gcm", crypto.scryptSync(String(password), salt, 32), iv); d.setAuthTag(tag);
  return Buffer.concat([d.update(data), d.final()]);       // sai mật khẩu → ném lỗi
}

module.exports = { isEncrypted, encryptBackup, decryptBackup, DATA_FILES, createBackup, listBackups, inspectBackup, sendTelegramFile, readZip, makeZip, NAME_RE, stamp };
