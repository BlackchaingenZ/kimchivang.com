// ============================================================================
// Kim Chỉ Vàng – máy chủ nhận giá MT5, khóa trang bằng mã khách hàng, phục vụ web
// Chạy:  node server.js        (cần Node.js 18 trở lên, không cần cài thư viện)
// Biến môi trường (đặt trong start.bat):
//   KCV_TOKEN  mã bí mật, phải trùng với ô Token trong EA
//   KCV_ADMIN  mật khẩu trang quản trị /quan-tri
//   PORT       cổng web (mặc định 80 – MT5 chỉ gửi được qua cổng 80/443)
// ============================================================================
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = parseInt(process.env.PORT || "80", 10);
const TOKEN = process.env.KCV_TOKEN || "doi-ma-bi-mat-nay";
const ADMIN_PASS = process.env.KCV_ADMIN || "doi-mat-khau-quan-tri";
const ROOT = __dirname;
const PUB = path.join(ROOT, "public");
const VIEWS = path.join(ROOT, "views");
const DATA = path.join(ROOT, "data.json");
const CODES_FILE = path.join(ROOT, "codes.json");
const SESS_FILE = path.join(ROOT, "sessions.json");
const MAX_BARS = 3000;           // số nến máy chủ giữ
const SEND_BARS = 3000;          // số nến gửi cho trang web
const SESSION_DAYS = 90;         // khách đăng nhập 1 lần, giữ 90 ngày
const CONFIG = require("./public/config.js");
const { kcvRun } = require("./engine.js");
const { loadVapid, sendPush } = require("./webpush.js");
const { buildInternal } = require("./internal.js");
const INTERNAL_FILE = path.join(ROOT, "internal.json");
const TG_TOKEN = process.env.KCV_TG_TOKEN || "", TG_CHAT = process.env.KCV_TG_CHAT || "";
const PUSH_FILE = path.join(ROOT, "push.json");
const VAPID = loadVapid(path.join(ROOT, "vapid.json"));
const PUSH_SUBJECT = CONFIG.siteUrl || "https://kimchivang.com";

if (TOKEN === "doi-ma-bi-mat-nay") console.warn("⚠  Đang dùng Token mặc định. Hãy đổi KCV_TOKEN (trong start.bat) và Token trong EA.");
if (ADMIN_PASS === "doi-mat-khau-quan-tri") console.warn("⚠  Đang dùng mật khẩu quản trị mặc định. Hãy đổi KCV_ADMIN trong start.bat.");

// ---------- lưu file an toàn ----------
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { return d; } };
function saveJson(f, obj) { const tmp = f + ".tmp"; fs.writeFile(tmp, JSON.stringify(obj), err => { if (!err) fs.rename(tmp, f, () => {}); }); }

// ---------- dữ liệu giá ----------
let state = readJson(DATA, null);
if (!state || !Array.isArray(state.bars)) state = { symbol: "XAUUSD", digits: 3, updated: 0, bars: [] };
else console.log("Đã đọc", state.bars.length, "nến từ data.json");
let dirty = false;
setInterval(() => { if (dirty) { dirty = false; saveJson(DATA, state); } }, 15000);
function merge(incoming) {
  const map = new Map(state.bars.map(b => [b[0], b]));
  for (const b of incoming) {
    if (!Array.isArray(b) || b.length < 5) continue;
    const v = b.slice(0, 5).map(Number);
    if (!v.every(Number.isFinite) || v[0] % 60 !== 0) continue;
    map.set(v[0], v);
  }
  state.bars = [...map.values()].sort((a, b) => a[0] - b[0]).slice(-MAX_BARS);
}


// ============================================================================
// MÃ KHÁCH HÀNG & PHIÊN ĐĂNG NHẬP
// ============================================================================
let codes = readJson(CODES_FILE, { list: [] });          // {code,name,note,created,expires,maxDevices,active}
let sessions = readJson(SESS_FILE, {});                    // token -> {code,created,lastSeen,ua,ip}
let adminSessions = new Map();                             // token -> expires
let authDirty = false;
setInterval(() => { if (authDirty) { authDirty = false; saveJson(CODES_FILE, codes); saveJson(SESS_FILE, sessions); } }, 10000);
const saveAuthNow = () => { authDirty = false; saveJson(CODES_FILE, codes); saveJson(SESS_FILE, sessions); };

const normCode = s => String(s || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
const findCode = c => codes.list.find(x => normCode(x.code) === normCode(c));
const ALPH = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";      // bỏ chữ dễ nhầm O/0, I/1, L
function newCode() {
  let c;
  do { const b = crypto.randomBytes(8); c = "KCV-" + [...b.slice(0, 4)].map(x => ALPH[x % ALPH.length]).join("") + "-" + [...b.slice(4)].map(x => ALPH[x % ALPH.length]).join(""); }
  while (findCode(c));
  return c;
}
// ---------- DÙNG THỬ: chỉ trừ thời gian nằm trong khung 07:00–21:00 giờ VN ----------
const VN = 7 * 3600000, DAYMS = 86400000;
const SES_A = (CONFIG.sessStart || 7) * 3600000, SES_B = (CONFIG.sessEnd || 21) * 3600000;
const TRIAL_MIN = CONFIG.trialMinutes || 300;
function inWindowMs(a, b) {                    // tổng thời gian trong khung phiên giữa 2 mốc
  if (!a || b <= a) return 0;
  let tot = 0, d = Math.floor((a + VN) / DAYMS) * DAYMS - VN;
  for (; d < b; d += DAYMS) tot += Math.max(0, Math.min(b, d + SES_B) - Math.max(a, d + SES_A));
  return tot;
}
const isOpenNow = () => { const t = (Date.now() + VN) % DAYMS; return t >= SES_A && t < SES_B; };
function trialLeft(c) { const tot = (c.trialMinutes || TRIAL_MIN) * 60000; return c.firstUse ? Math.max(0, tot - inWindowMs(c.firstUse, Date.now())) : tot; }
const codeValid = c => c && c.active && (!c.expires || c.expires > Date.now()) && (!c.trial || trialLeft(c) > 0);
function newTrialCode() { let c; do { const b = crypto.randomBytes(4); c = "TRY-" + [...b].map(x => ALPH[x % ALPH.length]).join(""); } while (findCode(c)); return c; }
const normPhone = p => { let d = String(p || "").replace(/\D/g, ""); if (d.startsWith("84")) d = "0" + d.slice(2); return /^0[35789]\d{8}$/.test(d) ? d : null; };
const trialIpLog = new Map();                  // ip -> [thời điểm đăng ký]
const devicesOf = code => Object.entries(sessions).filter(([, s]) => normCode(s.code) === normCode(code));

function parseCookies(req) {
  const out = {}; (req.headers.cookie || "").split(";").forEach(p => { const i = p.indexOf("="); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}
function isHttps(req) { return req.headers["x-forwarded-proto"] === "https" || /https/.test(req.headers["cf-visitor"] || ""); }
function setCookie(req, res, name, val, maxAgeSec) {
  const c = name + "=" + encodeURIComponent(val) + "; Path=/; HttpOnly; SameSite=Lax; Max-Age=" + maxAgeSec + (isHttps(req) ? "; Secure" : "");
  const prev = res.getHeader("Set-Cookie"); res.setHeader("Set-Cookie", prev ? [].concat(prev, c) : c);
}
function clientIp(req) { return req.headers["cf-connecting-ip"] || (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || req.socket.remoteAddress || ""; }

// Phiên khách: trả về {token, sess, code} hoặc null
function customer(req) {
  const t = parseCookies(req).kcv_s; if (!t || !sessions[t]) return null;
  const s = sessions[t], c = findCode(s.code);
  if (!codeValid(c) || s.created + SESSION_DAYS * 86400000 < Date.now()) { delete sessions[t]; authDirty = true; return null; }
  const now = Date.now(); if (now - (s.lastSeen || 0) > 60000) { s.lastSeen = now; authDirty = true; }
  return { token: t, sess: s, code: c };
}
function isAdmin(req) { const t = parseCookies(req).kcv_a; const e = t && adminSessions.get(t); if (e && e > Date.now()) return true; if (t) adminSessions.delete(t); return false; }

// Chống dò mã: tối đa 8 lần sai / 15 phút / IP
const fails = new Map();
function tooMany(ip) { const f = fails.get(ip); return f && f.n >= 8 && f.until > Date.now(); }
function addFail(ip) { const f = fails.get(ip); if (!f || f.until < Date.now()) fails.set(ip, { n: 1, until: Date.now() + 15 * 60000 }); else f.n++; }

// ============================================================================
// THÔNG BÁO ĐẨY – dò tín hiệu mới trên nến đã đóng, gửi về máy khách đã bật
// ============================================================================
let pushSubs = readJson(PUSH_FILE, {});                  // endpoint -> {sub, code, created}
const savePush = () => saveJson(PUSH_FILE, pushSubs);
const fmtP = v => (Math.round(v * 1000) / 1000).toFixed(3);
const hmVN = t => { const d = new Date(t + 7 * 3600000); return String(d.getUTCHours()).padStart(2, "0") + ":" + String(d.getUTCMinutes()).padStart(2, "0"); };
const f2 = v => { const r = Math.round(v * 100) / 100; return Number.isInteger(r) ? String(r) : String(r); };
let seen = null, watchKey = -1, watchTimer = null;
const PUSH_WINDOW = (parseInt(process.env.KCV_PUSH_WINDOW_MIN || "5", 10) || 5) * 60000;

function eventsOf(res) {
  const ev = [];
  const sym = state.symbol && /XAU/i.test(state.symbol) ? "XAUUSD" : (state.symbol || "XAUUSD");
  for (const s of res.sigs) {
    if (CONFIG.notifySessionOnly !== false && !s.inWin) continue;
    const side = (s.isAdd ? "＋ " : "") + (s.dir === 1 ? "MUA" : "BÁN") + (s.isAdd ? " GỒNG" : "");
    const arrow = s.dir === 1 ? "▲" : "▼";
    if (CONFIG.notifyEntries !== false)
      ev.push({ key: "E" + s.tSig + s.dir + (s.isAdd ? "g" : ""), t: s.tSig, sig: s, data: {
        title: (s.isAdd ? "" : arrow + " ") + side + " " + sym + " · " + hmVN(s.tSig),
        body: "Vào " + fmtP(s.entry) + " · Lời " + fmtP(s.tp0 !== undefined ? s.tp0 : s.tp) + " · Lỗ " + fmtP(s.sl), tag: "e" + s.tSig } });
    if (CONFIG.notifyExits !== false && s.res !== null && s.res !== "?")
      ev.push({ key: "X" + s.tSig + s.dir + (s.isAdd ? "g" : ""), t: s.exitT, data: {
        title: (s.pnl > 0 ? "✅ ĂN +" + f2(s.pnl) + " giá" : s.pnl < 0 ? "❌ LỖ −" + f2(-s.pnl) + " giá" : "➖ HÒA VỐN") + " · " + side + " " + sym,
        body: "Vào " + fmtP(s.entry) + " · đóng lúc " + hmVN(s.exitT), tag: "x" + s.tSig } });
  }
  return ev;
}
function watchSignals() {
  const now = Date.now(), cb = [];
  for (const b of state.bars) if (b[0] * 1000 + 60000 <= now) cb.push({ t: b[0] * 1000, o: b[1], h: b[2], l: b[3], c: b[4] });
  if (cb.length < 100) return;
  const key = cb[cb.length - 1].t; if (key === watchKey) return; watchKey = key;
  let res;
  try { res = kcvRun(cb, { preset: CONFIG.preset, tpDist: CONFIG.tpDist, slDist: CONFIG.slDist, dcaDist: CONFIG.dcaDist, useDca: CONFIG.useDca }); }
  catch (e) { console.error("Lỗi dò tín hiệu:", e.message); return; }
  const ev = eventsOf(res);
  if (!seen) { seen = new Set(ev.map(e => e.key)); return; }     // lần đầu: chỉ ghi nhận, không gửi lại lệnh cũ
  for (const e of ev) {
    if (seen.has(e.key)) continue;
    seen.add(e.key);
    if (now - e.t > PUSH_WINDOW) continue;                     // chỉ báo sự kiện vừa xảy ra (5 phút)
    broadcast(e.data, e.sig ? internalFor(e.sig, res.sigs) : null);
  }
  if (seen.size > 5000) seen = new Set([...seen].slice(-2000));
}
function scheduleWatch() { if (!watchTimer) watchTimer = setTimeout(() => { watchTimer = null; watchSignals(); }, 1500); }
setInterval(watchSignals, 20000);

async function pushTo(list, data) {
  const payload = Object.assign({ url: "/", icon: "/icon-192.png" }, data);
  let ok = 0, gone = 0;
  for (let i = 0; i < list.length; i += 20) {
    await Promise.all(list.slice(i, i + 20).map(async ([ep, rec]) => {
      const st = await sendPush(rec.sub, payload, VAPID, PUSH_SUBJECT);
      if (st >= 200 && st < 300) ok++;
      else if (st === 404 || st === 410) { delete pushSubs[ep]; gone++; }
    }));
  }
  if (gone) savePush();
  return { ok, total: list.length };
}
// ---------- TỔNG KẾT TÍN HIỆU phiên hiện tại (tính tới thời điểm bấm) ----------
function sessionSummary() {
  const now = Date.now(), cb = [];
  for (const b of state.bars) if (b[0] * 1000 + 60000 <= now) cb.push({ t: b[0] * 1000, o: b[1], h: b[2], l: b[3], c: b[4] });
  if (cb.length < 100) return { empty: true };
  const res = kcvRun(cb, { preset: CONFIG.preset, tpDist: CONFIG.tpDist, slDist: CONFIG.slDist, dcaDist: CONFIG.dcaDist, useDca: CONFIG.useDca });
  const ses = res.session.start, last = state.bars.length ? state.bars[state.bars.length - 1][4] : NaN;
  const list = res.sigs.filter(x => x.inWin && x.tOpen >= ses);
  const rows = list.map(x => ({
    t: x.tSig, dir: x.dir, add: !!x.isAdd, entry: x.entry, sl: x.sl, tp: x.tp0 !== undefined ? x.tp0 : x.tp, tpNow: x.tp,
    res: x.res, pnl: x.res === null ? null : x.pnl, exitT: x.exitT || null,
    floating: x.res === null && isFinite(last) ? Math.round((last - x.entry) * x.dir * 100) / 100 : null
  }));
  const done = rows.filter(r => r.res !== null && r.res !== "?");
  const tot = { n: rows.length, closed: done.length, running: rows.filter(r => r.res === null).length,
    win: done.filter(r => r.pnl > 0).length, loss: done.filter(r => r.pnl < 0).length, be: done.filter(r => r.pnl === 0).length,
    net: Math.round(done.reduce((a, r) => a + r.pnl, 0) * 100) / 100 };
  tot.rate = tot.closed ? Math.round((tot.win + tot.be) / tot.closed * 100) : null;   // hòa vốn = không thua → tính thắng
  return { now, session: ses, open: res.session.inWin, last, rows, tot,
    capitals: CONFIG.capitals || [10000, 5000, 2000, 1000], lotPer1000: CONFIG.lotPer1000 || 0.04 };
}

// Khách nhận mẫu ngắn; nhân viên (mã nội bộ) nhận mẫu chi tiết khi có lệnh vào
function broadcast(data, internal) {
  const list = Object.entries(pushSubs).filter(([ep, r]) => { const c = findCode(r.code); if (!codeValid(c)) { delete pushSubs[ep]; return false; } return true; });
  savePush();
  const isStaff = ([, r]) => { const c = findCode(r.code); return !!(c && c.staff); };
  const cust = internal ? list.filter(x => !isStaff(x)) : list, staff = internal ? list.filter(isStaff) : [];
  if (cust.length) pushTo(cust, data).then(r => console.log("Đã gửi thông báo khách:", data.title, "→", r.ok + "/" + r.total, "thiết bị"));
  if (internal) {
    if (staff.length) pushTo(staff, { title: internal.push.title, body: internal.push.body, tag: "i" + internal.id, url: "/noi-bo#" + internal.id })
      .then(r => console.log("Đã gửi thông báo nội bộ:", internal.push.title, "→", r.ok + "/" + r.total, "thiết bị"));
    sendTelegram(internal.text);
  }
}

// ---------- mẫu tin nội bộ: lưu 100 tin gần nhất để nhân viên mở lại / sao chép ----------
let internalLog = readJson(INTERNAL_FILE, []);
function internalFor(sig, sigs) {
  const m = buildInternal(sig, sigs, CONFIG);
  const rec = { id: String(sig.tSig) + (sig.dir === 1 ? "b" : "s") + (sig.isAdd ? "g" : ""), t: sig.tSig, dir: sig.dir, add: !!sig.isAdd, entry: sig.entry, text: m.text, push: m.push };
  internalLog = internalLog.filter(x => x.id !== rec.id); internalLog.push(rec); internalLog = internalLog.slice(-100);
  saveJson(INTERNAL_FILE, internalLog);
  return rec;
}
async function sendTelegram(text) {
  if (!TG_TOKEN || !TG_CHAT) return;
  try {
    const r = await fetch("https://api.telegram.org/bot" + TG_TOKEN + "/sendMessage", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: TG_CHAT, text, disable_web_page_preview: true }) });
    if (!r.ok) console.error("Telegram lỗi:", r.status, (await r.text()).slice(0, 200));
  } catch (e) { console.error("Telegram lỗi:", e.message); }
}

// ============================================================================
// WEB
// ============================================================================
const TYPES = { ".jpg": "image/jpeg", ".mp4": "video/mp4", ".webmanifest": "application/manifest+json", ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".json": "application/json" };
function send(res, code, body, type) {
  res.writeHead(code, { "Content-Type": type || "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Frame-Options": "SAMEORIGIN" });
  res.end(typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function view(res, name) {
  fs.readFile(path.join(VIEWS, name), (err, buf) => err ? send(res, 500, "Thiếu file " + name, "text/plain; charset=utf-8") : send(res, 200, buf, TYPES[".html"]));
}
function readBody(req, limit, cb) {
  let body = "", size = 0, dead = false;
  req.on("data", c => { size += c.length; if (size > limit) { dead = true; req.destroy(); } else body += c; });
  req.on("end", () => { if (!dead) cb(body); });
}
const jsonBody = (req, cb) => readBody(req, 20000, b => { let j = {}; try { j = JSON.parse(b || "{}"); } catch (e) {} cb(j); });

http.createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  const P = url.pathname;

  // ---------- EA đẩy giá ----------
  if (req.method === "POST" && P === "/api/push") {
    if (req.headers["x-token"] !== TOKEN) return send(res, 401, { error: "Sai Token" });
    return readBody(req, 8e6, body => {
      try {
        const j = JSON.parse(body);
        if (!Array.isArray(j.bars)) throw new Error("thiếu bars");
        merge(j.bars);
        if (j.symbol) state.symbol = String(j.symbol).slice(0, 24);
        if (Number.isInteger(j.digits)) state.digits = j.digits;
        state.updated = Date.now(); dirty = true; scheduleWatch();
        send(res, 200, { ok: true, bars: state.bars.length });
      } catch (e) { send(res, 400, { error: "Dữ liệu không hợp lệ: " + e.message }); }
    });
  }

  // ---------- khách đăng nhập / đăng xuất ----------
  if (req.method === "POST" && P === "/api/login") {
    const ip = clientIp(req);
    if (tooMany(ip)) return send(res, 429, { error: "Nhập sai quá nhiều lần. Vui lòng thử lại sau 15 phút." });
    return jsonBody(req, j => {
      const c = findCode(j.code);
      if (!c) { addFail(ip); return send(res, 401, { error: "Mã truy cập không đúng. Kiểm tra lại hoặc nhắn Zalo để được cấp mã." }); }
      if (!c.active) return send(res, 403, { error: "Mã này đã bị khóa. Vui lòng liên hệ Zalo để được hỗ trợ." });
      if (c.expires && c.expires <= Date.now()) return send(res, 403, { error: "Mã này đã hết hạn. Vui lòng liên hệ Zalo để gia hạn." });
      // Giới hạn thiết bị: vượt quá thì đăng xuất thiết bị cũ nhất
      const devs = devicesOf(c.code).sort((a, b) => (a[1].lastSeen || a[1].created) - (b[1].lastSeen || b[1].created));
      while (devs.length >= (c.maxDevices || 2)) { delete sessions[devs.shift()[0]]; }
      const t = crypto.randomBytes(24).toString("hex");
      sessions[t] = { code: c.code, created: Date.now(), lastSeen: Date.now(), ua: String(req.headers["user-agent"] || "").slice(0, 160), ip };
      if (c.trial && !c.firstUse) c.firstUse = Date.now();
      if (c.trial && trialLeft(c) <= 0) return send(res, 403, { error: "Mã dùng thử này đã hết thời gian. Nhắn Zalo để được cấp mã chính thức." });
      c.lastLogin = Date.now(); saveAuthNow();
      setCookie(req, res, "kcv_s", t, SESSION_DAYS * 86400);
      send(res, 200, { ok: true, name: c.name || "" });
    });
  }
  if (req.method === "POST" && P === "/api/logout") {
    const cu = customer(req); if (cu) { delete sessions[cu.token]; saveAuthNow(); }
    setCookie(req, res, "kcv_s", "", 0); return send(res, 200, { ok: true });
  }

  // ---------- khách vãng lai tự đăng ký dùng thử ----------
  if (req.method === "GET" && P === "/api/trial/status") {
    const used = findCode(parseCookies(req).kcv_t || "");
    return send(res, 200, { minutes: TRIAL_MIN, used: !!used, expired: !!used && !codeValid(used), open: isOpenNow() });
  }
  if (req.method === "POST" && P === "/api/trial/resume") {          // khách đăng xuất / mất phiên nhưng còn giờ dùng thử
    const c = findCode(parseCookies(req).kcv_t || "");
    if (!c || !codeValid(c)) return send(res, 403, { error: "Thời gian dùng thử đã hết." });
    devicesOf(c.code).forEach(([t]) => delete sessions[t]);
    const t = crypto.randomBytes(24).toString("hex");
    sessions[t] = { code: c.code, created: Date.now(), lastSeen: Date.now(), ua: String(req.headers["user-agent"] || "").slice(0, 160), ip: clientIp(req) };
    saveAuthNow(); setCookie(req, res, "kcv_s", t, SESSION_DAYS * 86400); return send(res, 200, { ok: true });
  }
  if (req.method === "POST" && P === "/api/trial") {
    const ip = clientIp(req);
    return jsonBody(req, j => {
      const name = String(j.name || "").trim().slice(0, 60), phone = normPhone(j.phone), dev = String(j.device || "").slice(0, 64);
      if (name.length < 2) return send(res, 400, { error: "Vui lòng nhập họ tên." });
      if (!phone) return send(res, 400, { error: "Số Zalo chưa đúng. Nhập 10 số, ví dụ 0912 345 678." });
      const prior = findCode(parseCookies(req).kcv_t || "");
      if (prior || codes.list.some(c => c.trial && (c.phone === phone || (dev && c.device === dev))))
        return send(res, 409, { error: "Số Zalo hoặc thiết bị này đã dùng thử rồi. Nhắn Zalo 0886 558 169 để được cấp mã chính thức." });
      const now = Date.now(), log = (trialIpLog.get(ip) || []).filter(t => now - t < DAYMS);
      if (log.length >= 3) return send(res, 429, { error: "Mạng này đã đăng ký dùng thử nhiều lần hôm nay. Vui lòng nhắn Zalo để được hỗ trợ." });
      log.push(now); trialIpLog.set(ip, log);
      const c = { code: newTrialCode(), name, phone, note: "Tự đăng ký dùng thử · Zalo " + phone, created: now, expires: null,
        maxDevices: 1, active: true, trial: true, trialMinutes: TRIAL_MIN, firstUse: now, device: dev, ip, self: true };
      codes.list.push(c);
      const t = crypto.randomBytes(24).toString("hex");
      sessions[t] = { code: c.code, created: now, lastSeen: now, ua: String(req.headers["user-agent"] || "").slice(0, 160), ip };
      saveAuthNow();
      setCookie(req, res, "kcv_s", t, SESSION_DAYS * 86400);
      setCookie(req, res, "kcv_t", c.code, 365 * 86400);         // đánh dấu trình duyệt đã dùng thử
      console.log("Khách dùng thử mới:", name, phone);
      send(res, 200, { ok: true });
    });
  }

  // ---------- khách bật / tắt thông báo ----------
  if (P.startsWith("/api/push/")) {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (req.method === "GET" && P === "/api/push/key") return send(res, 200, { key: VAPID.publicKey });
    if (req.method === "POST" && P === "/api/push/subscribe") return jsonBody(req, j => {
      const sub = j.subscription;
      if (!sub || typeof sub.endpoint !== "string" || !/^https:\/\//.test(sub.endpoint) || !sub.keys || !sub.keys.p256dh || !sub.keys.auth) return send(res, 400, { error: "Đăng ký không hợp lệ" });
      const prev = pushSubs[sub.endpoint];
      pushSubs[sub.endpoint] = { sub: { endpoint: sub.endpoint, keys: { p256dh: String(sub.keys.p256dh), auth: String(sub.keys.auth) } }, code: cu.code.code, created: prev ? prev.created : Date.now() };
      savePush(); send(res, 200, { ok: true });
    });
    if (req.method === "POST" && P === "/api/push/unsubscribe") return jsonBody(req, j => { if (j.endpoint && pushSubs[j.endpoint]) { delete pushSubs[j.endpoint]; savePush(); } send(res, 200, { ok: true }); });
    return send(res, 404, { error: "Không có" });
  }

  // ---------- trang nội bộ cho nhân viên ----------
  if (P === "/noi-bo" || P === "/noi-bo/") {
    const cu = customer(req);
    if (cu && cu.code.staff) return view(res, "staff.html");
    res.writeHead(302, { Location: "/" }); return res.end();
  }
  if (req.method === "GET" && P === "/api/internal/summary") {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (!cu.code.staff) return send(res, 403, { error: "Mã này không có quyền nội bộ" });
    try { return send(res, 200, sessionSummary()); } catch (e) { return send(res, 500, { error: "Lỗi tính tổng kết" }); }
  }
  if (req.method === "GET" && P === "/api/internal") {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (!cu.code.staff) return send(res, 403, { error: "Mã này không có quyền nội bộ" });
    return send(res, 200, { list: internalLog.slice(-50).reverse(), name: cu.code.name || "", telegram: !!(TG_TOKEN && TG_CHAT), mention: CONFIG.internalMention === "" ? "" : (CONFIG.internalMention || "@All") });
  }

  // ---------- dữ liệu cho khách đã đăng nhập ----------
  if (req.method === "GET" && (P === "/api/bars" || P === "/api/me")) {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (P === "/api/me") return send(res, 200, { name: cu.code.name || "", expires: cu.code.expires || null, staff: !!cu.code.staff,
      trial: cu.code.trial ? { leftMs: trialLeft(cu.code), totalMs: (cu.code.trialMinutes || TRIAL_MIN) * 60000, firstUse: cu.code.firstUse || null, open: isOpenNow(), sesStart: CONFIG.sessStart || 7, sesEnd: CONFIG.sessEnd || 21 } : null });
    const since = parseInt(url.searchParams.get("since") || "0", 10) || 0;
    const bars = since ? state.bars.filter(b => b[0] >= since) : state.bars.slice(-SEND_BARS);
    return send(res, 200, { symbol: state.symbol, digits: state.digits, updated: state.updated, now: Date.now(), bars });
  }

  // ---------- quản trị ----------
  if (P === "/quan-tri" || P === "/quan-tri/") return view(res, "admin.html");
  if (req.method === "POST" && P === "/api/admin/login") {
    const ip = clientIp(req);
    if (tooMany(ip)) return send(res, 429, { error: "Sai quá nhiều lần, thử lại sau 15 phút." });
    return jsonBody(req, j => {
      const a = Buffer.from(String(j.password || "")), b = Buffer.from(ADMIN_PASS);
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) { addFail(ip); return send(res, 401, { error: "Sai mật khẩu" }); }
      const t = crypto.randomBytes(24).toString("hex"); adminSessions.set(t, Date.now() + 12 * 3600000);
      setCookie(req, res, "kcv_a", t, 12 * 3600); send(res, 200, { ok: true });
    });
  }
  if (P.startsWith("/api/admin/")) {
    if (!isAdmin(req)) return send(res, 401, { error: "Chưa đăng nhập quản trị" });
    if (req.method === "POST" && P === "/api/admin/logout") { adminSessions.delete(parseCookies(req).kcv_a); setCookie(req, res, "kcv_a", "", 0); return send(res, 200, { ok: true }); }
    if (req.method === "GET" && P === "/api/admin/codes") {
      const list = codes.list.map(c => {
        const devs = devicesOf(c.code).map(([, s]) => s);
        const pushN = Object.values(pushSubs).filter(r => normCode(r.code) === normCode(c.code)).length;
        return Object.assign({}, c, { push: pushN, devices: devs.length, lastSeen: devs.reduce((m, s) => Math.max(m, s.lastSeen || 0), 0) || null, valid: codeValid(c), trialLeft: c.trial ? trialLeft(c) : null });
      }).sort((a, b) => b.created - a.created);
      return send(res, 200, { trialMinutes: TRIAL_MIN, list, feed: { updated: state.updated, bars: state.bars.length }, pushTotal: Object.keys(pushSubs).length });
    }
    if (req.method === "POST" && P === "/api/admin/codes") {
      return jsonBody(req, j => {
        const name = String(j.name || "").trim().slice(0, 80);
        if (!name) return send(res, 400, { error: "Nhập tên khách" });
        const isTrial = j.days === "trial";
        const days = isTrial ? 0 : parseInt(j.days, 10) || 0;
        const c = { code: isTrial ? newTrialCode() : newCode(), name, note: String(j.note || "").slice(0, 200), created: Date.now(),
          expires: days > 0 ? Date.now() + days * 86400000 : null, maxDevices: Math.max(1, Math.min(5, parseInt(j.maxDevices, 10) || 2)), active: true };
        if (j.days === "staff") { c.staff = true; c.expires = null; c.maxDevices = Math.max(c.maxDevices, 3); }
        if (isTrial) { c.trial = true; c.trialMinutes = TRIAL_MIN; c.firstUse = null; c.maxDevices = 1; }  // giờ chạy từ lần nhập mã đầu tiên
        codes.list.push(c); saveAuthNow(); send(res, 200, c);
      });
    }
    if (req.method === "POST" && P === "/api/admin/internal-test") {
      const demo = { id: -1, tSig: Date.now(), dir: 1, entry: 4138.99, sl: 4118.99, tp: 4146.99, tp0: 4146.99, isAdd: false };
      const base = buildInternal(demo, [demo], CONFIG);
      const rec = { id: "test" + Date.now(), t: Date.now(), dir: 1, add: false, entry: demo.entry, text: "[TIN THỬ – KHÔNG GIAO DỊCH]\n" + base.text, push: { title: "[THỬ] " + base.push.title, body: base.push.body } };
      internalLog.push(rec); internalLog = internalLog.slice(-100); saveJson(INTERNAL_FILE, internalLog);
      const staff = Object.entries(pushSubs).filter(([, r]) => { const c = findCode(r.code); return c && c.staff && codeValid(c); });
      return pushTo(staff, { title: rec.push.title, body: rec.push.body, tag: "itest", url: "/noi-bo#" + rec.id }).then(r => {
        sendTelegram(rec.text); send(res, 200, { ok: r.ok, total: r.total, telegram: !!(TG_TOKEN && TG_CHAT) });
      });
    }
    if (req.method === "POST" && P === "/api/admin/push-test") {
      return jsonBody(req, async j => {
        const list = Object.entries(pushSubs).filter(([, r]) => !j.code || normCode(r.code) === normCode(j.code));
        if (!list.length) return send(res, 400, { error: "Chưa có thiết bị nào bật thông báo" });
        const r = await pushTo(list, { title: "🔔 Thử thông báo Kim Chỉ Vàng", body: "Thiết bị này sẽ nhận thông báo mỗi khi có lệnh mới.", tag: "test" });
        send(res, 200, r);
      });
    }
    if (req.method === "POST" && P === "/api/admin/update") {
      return jsonBody(req, j => {
        const c = findCode(j.code); if (!c) return send(res, 404, { error: "Không tìm thấy mã" });
        const kick = () => devicesOf(c.code).forEach(([t]) => delete sessions[t]);
        if (j.action === "lock") { c.active = false; kick(); }
        else if (j.action === "unlock") c.active = true;
        else if (j.action === "reset") kick();
        else if (j.action === "extend") { const d = parseInt(j.days, 10) || 30; if (c.trial) { c.trial = false; c.wasTrial = true; c.maxDevices = Math.max(c.maxDevices || 1, 2); } c.expires = Math.max(Date.now(), c.expires || Date.now()) + d * 86400000; }
        else if (j.action === "forever") { c.expires = null; c.trial = false; }
        else if (j.action === "convert") { const d = parseInt(j.days, 10) || 30; c.trial = false; c.wasTrial = true; c.expires = Date.now() + d * 86400000; c.maxDevices = Math.max(c.maxDevices || 1, 2); c.active = true; }
        else if (j.action === "delete") { kick(); codes.list = codes.list.filter(x => x !== c); for (const [ep, r] of Object.entries(pushSubs)) if (normCode(r.code) === normCode(c.code)) delete pushSubs[ep]; savePush(); }
        else return send(res, 400, { error: "Thao tác không hợp lệ" });
        saveAuthNow(); send(res, 200, { ok: true });
      });
    }
    return send(res, 404, { error: "Không có" });
  }

  // ---------- trang chính: đã có mã → chart, chưa có → trang nhập mã ----------
  if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, { error: "Không hỗ trợ" });
  if (P === "/" || P === "/index.html") return view(res, customer(req) ? "index.html" : "login.html");

  // ---------- file công khai (ảnh giới thiệu, cấu hình) ----------
  const file = path.normalize(path.join(PUB, decodeURIComponent(P)));
  if (!file.startsWith(PUB + path.sep)) return send(res, 403, { error: "Cấm" });
  const ext = path.extname(file).toLowerCase();
  // Video: hỗ trợ tua (Range) – iPhone bắt buộc phải có mới phát được
  if (ext === ".mp4") {
    return fs.stat(file, (err, st) => {
      if (err) return send(res, 404, "Không tìm thấy", "text/plain; charset=utf-8");
      const range = /bytes=(\d*)-(\d*)/.exec(req.headers.range || "");
      const head = { "Content-Type": "video/mp4", "Accept-Ranges": "bytes", "Cache-Control": "public, max-age=86400" };
      if (range) {
        let start = range[1] ? parseInt(range[1], 10) : st.size - parseInt(range[2], 10);
        let end = range[1] && range[2] ? Math.min(parseInt(range[2], 10), st.size - 1) : st.size - 1;
        if (isNaN(start) || start < 0 || start >= st.size || end < start) { res.writeHead(416, { "Content-Range": "bytes */" + st.size }); return res.end(); }
        res.writeHead(206, Object.assign(head, { "Content-Range": "bytes " + start + "-" + end + "/" + st.size, "Content-Length": end - start + 1 }));
        if (req.method === "HEAD") return res.end();
        return fs.createReadStream(file, { start, end }).pipe(res);
      }
      res.writeHead(200, Object.assign(head, { "Content-Length": st.size }));
      if (req.method === "HEAD") return res.end();
      fs.createReadStream(file).pipe(res);
    });
  }
  fs.readFile(file, (err, buf) => {
    if (err) return send(res, 404, "Không tìm thấy trang", "text/plain; charset=utf-8");
    send(res, 200, buf, TYPES[ext] || "application/octet-stream");
  });
}).listen(PORT, () => console.log("Kim Chỉ Vàng đang chạy: http://localhost" + (PORT === 80 ? "" : ":" + PORT) + "   ·   Quản trị: /quan-tri"));
