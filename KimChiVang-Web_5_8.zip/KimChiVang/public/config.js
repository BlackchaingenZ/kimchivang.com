// ============================================================================
// CẤU HÌNH KIM CHỈ VÀNG – dùng chung cho trang web và máy chủ
// Sửa xong: lưu file, tắt start.bat rồi bật lại.
// ============================================================================
var KCV_CONFIG = {
  preset: "Cân bằng",      // "Chặt (v1)" | "Cân bằng" | "Nhiều tín hiệu"
  tpDist: 8,               // chốt lời (giá)
  slDist: 20,              // cắt lỗ (giá)
  dcaDist: 10,             // khoảng gồng (giá)
  useDca: true,            // gồng thêm 1 lệnh
  groupUrl: "https://zalo.me/g/n0klfsnyret89urnzzec",   // link nhóm Zalo tư vấn
  accountUrl: "https://zalo.me/0886558169",            // link Zalo liên hệ tư vấn (nút thứ 2)
  hotline: "",             // số hiển thị dưới nút (để trống = ẩn)
  siteUrl: "https://kimchivang.com",   // địa chỉ web (dùng cho thông báo)
  notifyEntries: true,     // thông báo khi có lệnh vào mới (kể cả gồng)
  notifyExits: true,       // thông báo khi lệnh đóng (ăn / lỗ / hòa)
  notifySessionOnly: true  // chỉ thông báo lệnh trong khung 07:00–21:00
};
if (typeof module !== "undefined") module.exports = KCV_CONFIG;
