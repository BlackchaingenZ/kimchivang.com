﻿//+------------------------------------------------------------------+
//| KCV_PriceFeed.mq5 – Kim Chỉ Vàng · Nguyễn Euro                    |
//| Gửi nến M1 XAUUSD từ MT5 (VT Markets) lên máy chủ web.            |
//| EA này KHÔNG đặt lệnh, chỉ đọc giá và gửi đi.                      |
//|                                                                  |
//| Trước khi chạy: Tools → Options → Expert Advisors                 |
//|   ✔ Allow WebRequest for listed URL  → thêm  http://127.0.0.1     |
//|   (nếu máy chủ ở máy khác: thêm địa chỉ máy chủ đó)              |
//+------------------------------------------------------------------+
#property copyright "Kim Chỉ Vàng · Nguyễn Euro"
#property version   "1.00"
#property description "Gửi nến M1 lên web Kim Chỉ Vàng. Không đặt lệnh."

input string ServerURL    = "http://127.0.0.1/api/push"; // Địa chỉ nhận giá (MT5 chỉ dùng cổng 80/443)
input string Token        = "doi-ma-bi-mat-nay";          // Mã bí mật – phải trùng với máy chủ
input string FeedSymbol   = "";                           // Mã vàng (để trống = mã của chart đang gắn EA)
input int    HistoryBars  = 1500;                          // Số nến lịch sử gửi lần đầu
input int    PushSeconds  = 2;                             // Gửi mỗi bao nhiêu giây
input int    ResyncMinutes = 60;                           // Mỗi bao nhiêu phút gửi lại 1500 nến gần nhất (vá lỗ hổng)
input int    ChunkBars    = 5000;                          // Mỗi lần gửi tối đa bao nhiêu nến

bool     g_needFull = true;     // lần đầu: gửi toàn bộ lịch sử
bool     g_needResync = false;  // định kỳ: gửi lại 1500 nến gần nhất
datetime g_lastFull = 0;
int      g_fails    = 0;

int OnInit()
{
   string sym = Sym();
   if(!SymbolSelect(sym, true))
   {
      Print("KCV: không tìm thấy mã ", sym, ". Kiểm tra tên mã vàng trong Market Watch (vd XAUUSD, XAUUSD.std...).");
      return INIT_PARAMETERS_INCORRECT;
   }
   if(Token == "doi-ma-bi-mat-nay")
      Print("KCV: CẢNH BÁO – anh chưa đổi Token. Đổi cả ở EA và ở máy chủ cho an toàn.");
   EventSetTimer(MathMax(1, PushSeconds));
   Print("KCV: bắt đầu gửi giá ", sym, " M1 tới ", ServerURL);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason) { EventKillTimer(); }

void OnTimer()
{
   if(g_needFull) { SendHistory(); return; }
   if(TimeLocal() - g_lastFull >= ResyncMinutes * 60) g_needResync = true;
   int count = g_needResync ? 1500 : 5;
   if(Push(0, count))
   {
      if(g_needResync) { g_needResync = false; g_lastFull = TimeLocal(); }
      if(g_fails > 0) Print("KCV: kết nối lại máy chủ thành công.");
      g_fails = 0;
   }
   else
   {
      g_needResync = true;   // lỗi → lần sau gửi lại 1500 nến để không hở nến
      g_fails++;
   }
}

// Gửi lịch sử dài theo từng đợt để không quá tải
void SendHistory()
{
   int avail = Bars(Sym(), PERIOD_M1);
   int total = MathMin(HistoryBars, avail);
   if(total <= 0) { g_fails++; return; }
   int chunk = MathMax(500, ChunkBars);
   for(int start = total - chunk; ; start -= chunk)
   {
      int s = MathMax(0, start);
      int cnt = (start < 0) ? chunk + start : chunk;
      if(cnt <= 0) break;
      if(!Push(s, cnt)) { g_fails++; return; }   // lỗi → lần sau thử lại từ đầu
      if(s == 0) break;
   }
   g_needFull = false; g_lastFull = TimeLocal(); g_fails = 0;
   Print("KCV: đã gửi ", total, " nến lịch sử.");
}

string Sym() { return FeedSymbol == "" ? _Symbol : FeedSymbol; }

bool Push(int startPos, int count)
{
   string sym = Sym();
   MqlRates r[];
   ArraySetAsSeries(r, false);
   int got = CopyRates(sym, PERIOD_M1, startPos, count, r);
   if(got <= 0) { if(g_fails % 30 == 0) Print("KCV: chưa lấy được nến M1 (", GetLastError(), ")."); return false; }

   // Giờ server VT Markets (GMT+2/+3) → đổi về UTC
   long off = (long)(TimeTradeServer() - TimeGMT());
   off = (long)MathRound(off / 1800.0) * 1800;
   int dg = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);

   string js = "{\"symbol\":\"" + sym + "\",\"digits\":" + IntegerToString(dg) + ",\"bars\":[";
   for(int i = 0; i < got; i++)
   {
      if(i > 0) js += ",";
      js += "[" + IntegerToString((long)r[i].time - off) + "," +
            DoubleToString(r[i].open, dg) + "," + DoubleToString(r[i].high, dg) + "," +
            DoubleToString(r[i].low, dg) + "," + DoubleToString(r[i].close, dg) + "]";
   }
   js += "]}";

   char data[], res[];
   int len = StringToCharArray(js, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(len > 0) ArrayResize(data, len - 1);        // bỏ ký tự kết thúc chuỗi
   string resHeaders;
   string headers = "Content-Type: application/json\r\nX-Token: " + Token + "\r\n";

   ResetLastError();
   int code = WebRequest("POST", ServerURL, headers, 5000, data, res, resHeaders);
   if(code == -1)
   {
      int err = GetLastError();
      if(g_fails % 30 == 0)
      {
         if(err == 4014) Print("KCV: MT5 chưa cho phép địa chỉ ", ServerURL, ". Vào Tools → Options → Expert Advisors → Allow WebRequest, thêm http://127.0.0.1");
         else            Print("KCV: không gửi được (lỗi ", err, "). Máy chủ đã chạy chưa?");
      }
      return false;
   }
   if(code != 200)
   {
      if(g_fails % 30 == 0) Print("KCV: máy chủ trả mã ", code, ": ", CharArrayToString(res, 0, WHOLE_ARRAY, CP_UTF8));
      return false;
   }
   return true;
}
//+------------------------------------------------------------------+
