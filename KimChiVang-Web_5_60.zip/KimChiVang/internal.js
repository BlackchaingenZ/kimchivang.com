// ============================================================================
// Mẫu tin nhắn NỘI BỘ – cùng dữ liệu tín hiệu với thông báo khách, nội dung chi tiết hơn
// ============================================================================
"use strict";

const p3 = v => (Math.round(v * 1000) / 1000).toFixed(3);
const g = v => { const r = Math.round(v * 100) / 100; return Number.isInteger(r) ? String(r) : String(r); };
const money = v => Math.round(v).toLocaleString("vi-VN");               // 10000 → 10.000
const lotOf = (cap, per1000) => (Math.round(cap / 1000 * per1000 * 100) / 100).toFixed(2).replace(/0$/, "").replace(/\.$/, "");

// Lệnh NGƯỢC CHIỀU đang chạy cùng lúc với s (vd đang có MUA, có thêm tín hiệu BÁN)
// ok = chốt lời của mỗi lệnh nằm trong vùng chưa cắt lỗ của lệnh kia → vào được cả 2
function oppositeOf(s, sigs) {
  const tpOf = x => x.tp0 !== undefined ? x.tp0 : x.tp;
  const o = (sigs || []).find(x => x !== s && !x.isAdd && x.dir !== s.dir && x.tSig <= s.tSig && (x.exitT == null || x.exitT > s.tSig));
  if (!o) return null;
  const buy = s.dir === 1 ? s : o, sell = s.dir === 1 ? o : s;
  return { other: o, buy, sell, ok: tpOf(buy) < sell.sl && tpOf(sell) > buy.sl, tpOf };
}
function hedgeLine(h) {
  const B = h.buy, S = h.sell, t = h.tpOf;
  return h.ok
    ? "ℹ️ Đang có 2 lệnh ngược chiều – vẫn vào được cả 2: chốt lời lệnh MUA (" + p3(t(B)) + ") nằm dưới cắt lỗ lệnh BÁN (" + p3(S.sl) + "), chốt lời lệnh BÁN (" + p3(t(S)) + ") nằm trên cắt lỗ lệnh MUA (" + p3(B.sl) + ") → giá sẽ chạm chốt lời một lệnh trước khi chạm cắt lỗ lệnh kia."
    : "⚠️ Đang có 2 lệnh ngược chiều và chốt lời một lệnh nằm ngoài vùng cắt lỗ lệnh kia – nếu mới vào, nên cân nhắc chỉ vào 1 lệnh.";
}
// s: tín hiệu từ engine (dir, entry, sl, tp0/tp, isAdd, parent...)
// sigs: toàn bộ danh sách tín hiệu (để tra lệnh gốc khi gồng)
function buildInternal(s, sigs, cfg) {
  const sym = cfg.symbolLabel || "XAUUSD";
  const buy = s.dir === 1;
  const tp = s.tp0 !== undefined ? s.tp0 : s.tp;
  const slGap = Math.abs(s.entry - s.sl), tpGap = Math.abs(tp - s.entry);
  const caps = Array.isArray(cfg.capitals) && cfg.capitals.length ? cfg.capitals : [20000, 5000, 3000, 1000];
  const per1000 = cfg.lotPer1000 || 0.04;
  const lines = [];

  if (!s.isAdd) {
    lines.push((buy ? "🟢 BUY/MUA" : "🔴 SELL/BÁN") + " VIP " + sym + ": " + p3(s.entry));
  } else {
    lines.push((buy ? "🟢 BUY/MUA" : "🔴 SELL/BÁN") + " GỒNG VIP " + sym + ": " + p3(s.entry));
  }
  lines.push("Loại lệnh: Giá thị trường");
  lines.push("Cắt lỗ: " + g(slGap) + " giá tính từ điểm vào (" + p3(s.sl) + ")");
  lines.push("Chốt lời: " + g(tpGap) + " giá tính từ điểm vào (" + p3(tp) + ")");
  lines.push("");
  lines.push("Vốn – Khối lượng:");
  for (const c of caps) lines.push(money(c) + " USD: " + lotOf(c, per1000) + " lot");
  lines.push("");
  lines.push("📌 HƯỚNG DẪN VÀO LỆNH");
  if (!s.isAdd) {
    lines.push("✅ Mở 1 lệnh " + (buy ? "MUA" : "BÁN") + " với khối lượng tương ứng mức vốn tại mức giá được cung cấp.");
    lines.push("✅ Đặt cắt lỗ tại " + p3(s.sl) + " và chốt lời tại " + p3(tp) + ", tương ứng khoảng cắt lỗ " + g(slGap) + " giá và chốt lời " + g(tpGap) + " giá tính từ điểm vào.");
    const h = oppositeOf(s, sigs); if (h) lines.push(hedgeLine(h));
  } else {
    const parent = sigs.find(x => x.id === s.parent);
    lines.push("✅ Mở thêm 1 lệnh " + (buy ? "MUA" : "BÁN") + " (lệnh gồng) với khối lượng tương ứng mức vốn tại mức giá được cung cấp.");
    lines.push("✅ Đặt cắt lỗ tại " + p3(s.sl) + " và chốt lời tại " + p3(tp) + " cho lệnh gồng.");
    if (parent) lines.push("✅ Sửa chốt lời lệnh trước (vào " + p3(parent.entry) + ") về " + p3(parent.entry) + " (hòa vốn). Giữ nguyên cắt lỗ " + p3(parent.sl) + ".");
  }
  lines.push("");
  lines.push("⚠️ Nội dung chỉ mang tính chất tham khảo, không phải khuyến nghị đầu tư và không cam kết lợi nhuận. Anh chị vui lòng tự nghiên cứu và chịu trách nhiệm với quyết định giao dịch của mình.");
  if (cfg.internalMention !== "") lines.push(cfg.internalMention || "@All");

  const text = lines.join("\n");
  const push = {
    title: (buy ? "🟢 BUY/MUA" : "🔴 SELL/BÁN") + (s.isAdd ? " GỒNG" : "") + " VIP " + sym + ": " + p3(s.entry),
    body: "SL " + p3(s.sl) + " (" + g(slGap) + " giá) · TP " + p3(tp) + " (" + g(tpGap) + " giá) · Bấm để mở mẫu tin đầy đủ"
  };
  return { text, push };
}

module.exports = { buildInternal, lotOf, oppositeOf, hedgeLine };
