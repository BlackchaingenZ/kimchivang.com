// ============================================================================
// Mẫu tin nhắn NỘI BỘ – cùng dữ liệu tín hiệu với thông báo khách, nội dung chi tiết hơn
// ============================================================================
"use strict";

let ROUND = true;                                                        // làm tròn giá như chart (config.roundEntry)
const p3 = v => ROUND ? String(Math.round(v)) : (Math.round(v * 1000) / 1000).toFixed(3);
const g = v => { const r = Math.round(v * 100) / 100; return Number.isInteger(r) ? String(r) : String(r); };
const money = v => Math.round(v).toLocaleString("vi-VN");               // 10000 → 10.000
const lotOf = (cap, per1000) => (Math.round(cap / 1000 * per1000 * 100) / 100).toFixed(2).replace(/0$/, "").replace(/\.$/, "");

// Lệnh NGƯỢC CHIỀU đang chạy cùng lúc với s (vd đang có MUA, có thêm tín hiệu BÁN)
// ok = chốt lời của mỗi lệnh nằm trong vùng chưa cắt lỗ của lệnh kia → vào được cả 2
function oppositeOf(s, sigs) {
  const tpOf = x => x.tp0 !== undefined ? x.tp0 : x.tp;
  const o = (sigs || []).find(x => x !== s && !x.isAdd && x.dir !== s.dir && x.tSig <= s.tSig && (x.exitT == null || x.exitT > s.tSig));
  if (!o) return null;
  const buy = s.dir === 1 ? s : o, sell = s.dir === 1 ? o : s;
  return { other: o, buy, sell, ok: tpOf(buy) < sell.sl && tpOf(sell) > buy.sl, tpOf };
}
function hedgeLine(h) {
  const B = h.buy, S = h.sell, t = h.tpOf;
  return h.ok
    ? "ℹ️ Đang có 2 lệnh ngược chiều – vẫn vào được cả 2: chốt lãi lệnh MUA (" + p3(t(B)) + ") nằm dưới cắt lỗ lệnh BÁN (" + p3(S.sl) + "), chốt lãi lệnh BÁN (" + p3(t(S)) + ") nằm trên cắt lỗ lệnh MUA (" + p3(B.sl) + ") → giá sẽ chạm chốt lãi một lệnh trước khi chạm cắt lỗ lệnh kia."
    : "⚠️ Đang có 2 lệnh ngược chiều và chốt lãi một lệnh nằm ngoài vùng cắt lỗ lệnh kia – nếu mới vào, nên cân nhắc chỉ vào 1 lệnh.";
}
// s: tín hiệu từ engine (dir, entry, sl, tp0/tp, isAdd, parent...)
// sigs: toàn bộ danh sách tín hiệu (để tra lệnh gốc khi gồng)
function buildInternal(s, sigs, cfg) {
  ROUND = cfg.roundEntry !== false;
  const sym = (cfg.symbolLabel || "XAUUSD") + (cfg.tfLabel ? " " + cfg.tfLabel : "");      // vd XAUUSD M15
  const buy = s.dir === 1;
  const tp = s.tp0 !== undefined ? s.tp0 : s.tp;
  const slGap = Math.abs(Number(p3(s.entry)) - Number(p3(s.sl))), tpGap = Math.abs(Number(p3(tp)) - Number(p3(s.entry)));
  const caps = Array.isArray(cfg.capitals) && cfg.capitals.length ? cfg.capitals : [20000, 5000, 3000, 1000];
  const per1000 = cfg.lotPer1000 || 0.04;
  const lines = [];

  if (!s.isAdd) {
    lines.push((buy ? "🟢 BUY/MUA" : "🔴 SELL/BÁN") + " " + sym + ": " + p3(s.entry));
  } else {
    lines.push((buy ? "🟢 BUY/MUA" : "🔴 SELL/BÁN") + " GỒNG " + sym + ": " + p3(s.entry));
  }
  lines.push(s.isAdd ? "Loại lệnh: Giá thị trường" : "Loại lệnh: Lệnh chờ/LIMIT hoặc thị trường nếu giá tốt hơn có thể vào luôn");
  lines.push("Cắt lỗ: " + g(slGap) + " giá tính từ điểm vào (" + p3(s.sl) + ")");
  lines.push("Chốt lãi: " + g(tpGap) + " giá tính từ điểm vào (" + p3(tp) + ")");
  lines.push("");
  lines.push("Vốn – Khối lượng:");
  for (const c of caps) lines.push(money(c) + " USD: " + lotOf(c, per1000) + " lot");
  lines.push("");
  lines.push("📌 HƯỚNG DẪN VÀO LỆNH");
  if (!s.isAdd) {
    lines.push("✅ Mở 1 lệnh " + (buy ? "MUA" : "BÁN") + " với khối lượng tương ứng mức vốn tại mức giá được cung cấp.");
    lines.push("✅ Đặt cắt lỗ tại " + p3(s.sl) + " và chốt lãi tại " + p3(tp) + ", tương ứng khoảng cắt lỗ " + g(slGap) + " giá và chốt lãi " + g(tpGap) + " giá tính từ điểm vào.");
    const h = oppositeOf(s, sigs); if (h) lines.push(hedgeLine(h));
  } else {
    const parent = sigs.find(x => x.id === s.parent);
    lines.push("✅ Mở thêm 1 lệnh " + (buy ? "MUA" : "BÁN") + " (lệnh gồng) với khối lượng tương ứng mức vốn tại mức giá được cung cấp.");
    lines.push("✅ Đặt cắt lỗ tại " + p3(s.sl) + " và chốt lãi tại " + p3(tp) + " cho lệnh gồng.");
    if (parent) lines.push("✅ Sửa chốt lãi lệnh trước (vào " + p3(parent.entry) + ") về " + p3(parent.entry) + " (hòa vốn). Giữ nguyên cắt lỗ " + p3(parent.sl) + ".");
  }
  lines.push("");
  lines.push("⚠️ Nội dung chỉ mang tính chất tham khảo, không phải khuyến nghị đầu tư và không cam kết lợi nhuận. Anh chị vui lòng tự nghiên cứu và chịu trách nhiệm với quyết định giao dịch của mình.");
  if (cfg.internalMention !== "") lines.push(cfg.internalMention || "@All");

  const text = lines.join("\n");
  const push = {
    title: (buy ? "🟢 BUY/MUA" : "🔴 SELL/BÁN") + (s.isAdd ? " GỒNG" : "") + " " + sym + ": " + p3(s.entry),
    body: "Cắt lỗ " + p3(s.sl) + " (" + g(slGap) + " giá) · Chốt lãi " + p3(tp) + " (" + g(tpGap) + " giá) · Bấm để mở mẫu tin đầy đủ"
  };
  return { text, push };
}

// ---------- Mẫu tin NỘI BỘ / TELEGRAM theo tín hiệu vùng MUA / BÁN – cùng dữ liệu với thông báo + bảng lệnh của khách ----------
// z: { tf, dir, e (điểm vào), far (đầu kia của vùng), sl, tp, t, inWin } · opp: đang có tín hiệu ngược chiều còn chạy
function buildZoneInternal(z, cfg, opp) {
  const sym = (cfg.symbolLabel || "XAUUSD") + (cfg.tfLabel ? " " + cfg.tfLabel : "");
  const buy = z.dir === 1, side = buy ? "MUA" : "BÁN", head = (buy ? "🟢 BUY/MUA" : "🔴 SELL/BÁN") + " " + sym + ": " + z.e + " – " + z.far;
  const slGap = Math.abs(z.e - z.sl), tpGap = Math.abs(z.tp - z.e);
  const caps = Array.isArray(cfg.capitals) && cfg.capitals.length ? cfg.capitals : [20000, 5000, 3000, 1000];
  const per1000 = cfg.lotPer1000 || 0.04;
  const S = cfg.sessStart || 7, E = cfg.sessEnd || 23, pad = x => (x < 10 ? "0" : "") + x;
  const L = [];
  L.push(head);
  L.push("Vùng " + side + ": " + z.e + " – " + z.far);
  L.push("Giá vàng vào vùng này thì mở lệnh " + side + ", giá càng " + (buy ? "thấp" : "cao") + " càng tốt.");
  L.push("Điểm vào: " + z.e + " – " + z.far);
  L.push("Cắt lỗ: " + z.sl + " (" + g(slGap) + " giá tính từ điểm vào " + z.e + ")");
  L.push("Chốt lãi: " + z.tp + " (" + g(tpGap) + " giá tính từ điểm vào " + z.e + ")");
  if (z.inWin === false) L.push("🌙 Tín hiệu ngoài phiên " + pad(S) + ":00–" + pad(E) + ":00");
  L.push("");
  L.push("Vốn – Khối lượng:");
  for (const c of caps) L.push(money(c) + " USD: " + lotOf(c, per1000) + " lot");
  L.push("");
  L.push("📌 HƯỚNG DẪN VÀO LỆNH");
  L.push("✅ Mở 1 lệnh " + side + " XAUUSD khi giá nằm trong vùng " + (buy ? "từ " + z.e + " xuống " + z.far : "từ " + z.e + " lên " + z.far) + ".");
  L.push("✅ Đặt Cắt lỗ " + z.sl + " và Chốt lãi " + z.tp + " ngay khi vào lệnh.");
  L.push("✅ Khối lượng theo vốn (bảng trên). Mỗi chiều chỉ giữ 1 lệnh.");
  if (opp) { L.push(""); L.push("⚠️ Có tín hiệu ngược chiều: Nếu đã mở giao dịch vào tín hiệu nào đó, hãy đặt Chốt lãi – Cắt lỗ đầy đủ, hoặc nếu lệnh đó đang có lãi thì đóng luôn."); }
  L.push("");
  L.push("⚠️ Nội dung chỉ mang tính chất tham khảo, không phải khuyến nghị đầu tư và không cam kết lợi nhuận. Anh chị vui lòng tự nghiên cứu và chịu trách nhiệm với quyết định giao dịch của mình.");
  if (cfg.internalMention !== "") L.push(cfg.internalMention || "@All");
  return { text: L.join("\n"), push: { title: head + (z.inWin === false ? " · ngoài phiên" : ""), body: "Cắt lỗ " + z.sl + " · Chốt lãi " + z.tp + (opp ? " · Có tín hiệu ngược chiều" : "") + " · Bấm để mở mẫu tin đầy đủ" } };
}

module.exports = { buildInternal, buildZoneInternal, lotOf, oppositeOf, hedgeLine };
