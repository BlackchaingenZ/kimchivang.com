// ============================================================================
// Kim Chỉ Vàng · Hướng dẫn CÀI APP về điện thoại (thêm vào màn hình chính) + bật thông báo
// Dùng chung cho trang đăng nhập và trang chart. Nút: <button data-install>…</button>
// ============================================================================
(function () {
  "use strict";
  const ua = navigator.userAgent || "";
  const isIOS = /iPhone|iPad|iPod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  const isAndroid = /Android/i.test(ua);
  const inApp = /Zalo|FBAN|FBAV|FB_IAB|Instagram|Messenger|Line\/|TikTok|musical_ly/i.test(ua);   // trình duyệt trong Zalo / Facebook…
  const iosNotSafari = isIOS && /CriOS|FxiOS|EdgiOS/i.test(ua);
  const standalone = (window.matchMedia && matchMedia("(display-mode: standalone)").matches) || navigator.standalone === true;
  let deferred = null;                                         // Android / máy tính Chrome: hộp cài đặt 1 chạm
  window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); deferred = e; render(); });
  window.addEventListener("appinstalled", () => { deferred = null; installed = true; render(); });
  let installed = standalone;
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => {});   // cần để Chrome cho cài app

  const css = `
.inst-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 13px;border-radius:99px;border:1px solid var(--gold,#e3b23c);background:rgba(227,178,60,.12);color:var(--gold,#e3b23c);font:700 13px var(--f-ui,system-ui);cursor:pointer;white-space:nowrap}
.inst-btn:hover{background:rgba(227,178,60,.22)}.inst-btn.done{border-color:rgba(31,196,111,.6);color:#4ade80;background:rgba(31,196,111,.1)}
.inst-ov{position:fixed;inset:0;z-index:80;background:rgba(5,6,9,.78);backdrop-filter:blur(4px);display:flex;align-items:flex-end;justify-content:center;padding:0}
@media (min-width:640px){.inst-ov{align-items:center;padding:16px}}
.inst-box{width:100%;max-width:520px;max-height:92vh;overflow:auto;background:var(--surface,#14171c);border:1px solid rgba(227,178,60,.4);border-radius:18px 18px 0 0;box-shadow:0 30px 80px rgba(0,0,0,.6);color:var(--fg,#f1ece0);font-family:var(--f-ui,system-ui)}
@media (min-width:640px){.inst-box{border-radius:18px}}
.inst-hd{position:sticky;top:0;display:flex;align-items:center;gap:12px;padding:16px 18px 12px;background:var(--surface,#14171c);border-bottom:1px solid var(--line,#262b33);z-index:1}
.inst-hd img{width:44px;height:44px;border-radius:11px}
.inst-hd b{display:block;font-size:17px}.inst-hd span{display:block;font-size:12.5px;color:var(--muted,#9aa0aa)}
.inst-box .inst-x{margin-left:auto;flex:0 0 34px;width:34px;height:34px;padding:0;display:grid;place-items:center;border-radius:50%;border:1px solid var(--line,#262b33);background:transparent;color:var(--fg,#fff);font-size:15px;line-height:1;cursor:pointer}
.inst-why{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:12px 18px 4px}
.inst-why div{background:rgba(255,255,255,.04);border:1px solid var(--line,#262b33);border-radius:10px;padding:9px 8px;text-align:center;font-size:12px;color:#c9c5ba;line-height:1.35}
.inst-why div i{display:block;font-style:normal;font-size:20px;margin-bottom:3px}
.inst-tabs{display:flex;gap:6px;padding:12px 18px 0}
.inst-tabs button{flex:1;padding:9px 6px;border-radius:9px;border:1px solid var(--line,#262b33);background:transparent;color:var(--muted,#9aa0aa);font:700 13px var(--f-ui,system-ui);cursor:pointer}
.inst-tabs button.on{background:var(--gold,#e3b23c);border-color:var(--gold,#e3b23c);color:#1b1405}
.inst-body{padding:12px 18px 18px}
.inst-warn{background:rgba(255,181,71,.1);border:1px solid rgba(255,181,71,.45);color:#f3d9a8;border-radius:10px;padding:10px 12px;font-size:13px;line-height:1.5;margin-bottom:10px}
.inst-warn b{color:#fff}
.inst-ok{background:rgba(31,196,111,.1);border:1px solid rgba(31,196,111,.45);color:#b6f0cc;border-radius:10px;padding:10px 12px;font-size:13.5px;line-height:1.5;margin-bottom:10px}
.inst-steps{list-style:none;margin:0;padding:0;counter-reset:s}
.inst-steps li{position:relative;padding:10px 0 10px 40px;border-bottom:1px dashed var(--line,#262b33);font-size:14px;line-height:1.55;color:#d9d4c8;counter-increment:s}
.inst-steps li:last-child{border-bottom:0}
.inst-steps li::before{content:counter(s);position:absolute;left:0;top:9px;width:28px;height:28px;border-radius:50%;display:grid;place-items:center;font-weight:800;font-size:13px;color:#1b1405;background:linear-gradient(145deg,#f6d47a,#e3b23c)}
.inst-steps b{color:#fff}
.inst-ic{display:inline-flex;align-items:center;justify-content:center;vertical-align:-5px;width:24px;height:24px;border-radius:6px;background:#fff;margin:0 2px}
.inst-ic svg{width:16px;height:16px}
.inst-go{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin:4px 0 10px;padding:13px;border-radius:11px;border:0;background:var(--gold,#e3b23c);color:#1b1405;font:800 15px var(--f-ui,system-ui);cursor:pointer}
.inst-copy{display:inline-flex;margin-top:8px;padding:8px 12px;border-radius:9px;border:1px solid var(--gold,#e3b23c);background:transparent;color:var(--gold,#e3b23c);font:700 13px var(--f-ui,system-ui);cursor:pointer}
.inst-note{margin:10px 0 0;font-size:12px;color:var(--muted,#9aa0aa);line-height:1.5}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  // biểu tượng minh họa (giống trên điện thoại)
  const IC = {
    share: '<svg viewBox="0 0 24 24" fill="none" stroke="#1a73e8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="M8 7l4-4 4 4"/><path d="M5 11v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-8"/></svg>',
    add: '<svg viewBox="0 0 24 24" fill="none" stroke="#111" stroke-width="2" stroke-linecap="round"><rect x="3.5" y="3.5" width="17" height="17" rx="4"/><path d="M12 8v8M8 12h8"/></svg>',
    dots: '<svg viewBox="0 0 24 24" fill="#111"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>',
    hdots: '<svg viewBox="0 0 24 24" fill="#111"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>',
    inst: '<svg viewBox="0 0 24 24" fill="none" stroke="#111" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="13" rx="2"/><path d="M12 8v6M9 11l3 3 3-3"/><path d="M8 21h8"/></svg>',
    bell: '<svg viewBox="0 0 24 24" fill="none" stroke="#b7791f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>'
  };
  const ic = k => '<span class="inst-ic" aria-hidden="true">' + IC[k] + "</span>";
  const NOTI = 'Đăng nhập bằng mã, rồi bấm nút ' + ic("bell") + ' <b>"Bật thông báo"</b> trên trang chart → chọn <b>Cho phép</b>. Từ giờ có lệnh MUA/BÁN là điện thoại báo ngay.';
  const OPEN_BROWSER = isIOS
    ? 'Anh/chị đang mở trong <b>Zalo / Facebook</b> nên chưa cài được. Bấm ' + ic("hdots") + ' ở góc trên → chọn <b>"Mở bằng trình duyệt"</b> (Safari), hoặc sao chép link rồi dán vào <b>Safari</b>.'
    : 'Anh/chị đang mở trong <b>Zalo / Facebook</b> nên chưa cài được. Bấm ' + ic("dots") + ' ở góc trên → chọn <b>"Mở bằng trình duyệt"</b> (Chrome), hoặc sao chép link rồi dán vào <b>Chrome</b>.';

  const TABS = {
    ios: { label: "iPhone / iPad", html: () => {
      let h = "";
      if (inApp) h += '<div class="inst-warn">⚠️ ' + OPEN_BROWSER + '<br><button type="button" class="inst-copy" data-copy>📋 Sao chép link</button></div>';
      else if (iosNotSafari) h += '<div class="inst-warn">⚠️ Nên dùng <b>Safari</b> để cài app và nhận thông báo ổn định nhất. Sao chép link rồi mở bằng Safari.<br><button type="button" class="inst-copy" data-copy>📋 Sao chép link</button></div>';
      h += '<ol class="inst-steps">' +
        '<li>Mở <b>' + location.host + '</b> bằng trình duyệt <b>Safari</b>.</li>' +
        '<li>Bấm nút <b>Chia sẻ</b> ' + ic("share") + ' ở thanh dưới cùng (iPad: góc trên bên phải).</li>' +
        '<li>Kéo xuống, chọn <b>"Thêm vào MH chính"</b> ' + ic("add") + ' → bấm <b>Thêm</b>.</li>' +
        '<li>Ra màn hình chính, mở biểu tượng <b>Kim Chỉ Vàng</b> (logo KV) như một ứng dụng.</li>' +
        '<li>' + NOTI + '</li></ol>' +
        '<p class="inst-note">iPhone chỉ nhận thông báo khi mở bằng biểu tượng trên màn hình chính, cần iOS 16.4 trở lên (Cài đặt → Cài đặt chung → Giới thiệu để xem phiên bản).</p>';
      return h; } },
    android: { label: "Android", html: () => {
      let h = "";
      if (inApp) h += '<div class="inst-warn">⚠️ ' + OPEN_BROWSER + '<br><button type="button" class="inst-copy" data-copy>📋 Sao chép link</button></div>';
      if (deferred) h += '<button type="button" class="inst-go" data-prompt>📲 Cài đặt Kim Chỉ Vàng ngay</button><p class="inst-note" style="margin:0 0 10px">Bấm nút trên → chọn <b>Cài đặt</b> là xong. Hoặc làm theo các bước dưới:</p>';
      h += '<ol class="inst-steps">' +
        '<li>Mở <b>' + location.host + '</b> bằng trình duyệt <b>Chrome</b>.</li>' +
        '<li>Bấm nút ' + ic("dots") + ' (3 chấm) ở góc trên bên phải.</li>' +
        '<li>Chọn <b>"Cài đặt ứng dụng"</b> hoặc <b>"Thêm vào màn hình chính"</b> ' + ic("add") + ' → bấm <b>Cài đặt</b>.</li>' +
        '<li>Mở biểu tượng <b>Kim Chỉ Vàng</b> (logo KV) trên màn hình chính.</li>' +
        '<li>' + NOTI + '</li></ol>' +
        '<p class="inst-note">Nếu không thấy thông báo: Cài đặt điện thoại → Ứng dụng → Chrome (hoặc Kim Chỉ Vàng) → Thông báo → bật. Máy Xiaomi/Oppo/Vivo nên tắt "tiết kiệm pin" cho Chrome.</p>';
      return h; } },
    pc: { label: "Máy tính", html: () => {
      let h = "";
      if (deferred) h += '<button type="button" class="inst-go" data-prompt>💻 Cài Kim Chỉ Vàng lên máy tính</button>';
      h += '<ol class="inst-steps">' +
        '<li>Mở <b>' + location.host + '</b> bằng <b>Chrome</b> hoặc <b>Edge</b>.</li>' +
        '<li>Bấm biểu tượng cài đặt ' + ic("inst") + ' ở cuối thanh địa chỉ, hoặc menu ' + ic("dots") + ' → <b>"Cài đặt Kim Chỉ Vàng"</b> / <b>"Lưu và chia sẻ → Cài đặt trang"</b>.</li>' +
        '<li>Kim Chỉ Vàng mở thành cửa sổ riêng, có biểu tượng ở thanh tác vụ / Desktop.</li>' +
        '<li>' + NOTI + '</li></ol>';
      return h; } }
  };
  let tab = isIOS ? "ios" : isAndroid ? "android" : "pc", ov = null;

  function render() {
    document.querySelectorAll("[data-install]").forEach(b => { b.classList.toggle("done", installed); const sm = window.matchMedia && matchMedia("(max-width:639px)").matches; b.textContent = installed ? (sm ? "✓ App" : "✓ Đã cài app · Bật thông báo") : (sm ? "📲 Cài app" : "📲 Cài app về điện thoại"); });
    if (!ov) return;
    const body = ov.querySelector(".inst-body");
    let h = installed ? '<div class="inst-ok">✅ Anh/chị đang dùng <b>app Kim Chỉ Vàng</b> trên màn hình chính. Chỉ cần bật thông báo:</div><ol class="inst-steps"><li>' + NOTI + "</li></ol>" : TABS[tab].html();
    body.innerHTML = h;
    ov.querySelectorAll(".inst-tabs button").forEach(b => b.classList.toggle("on", b.dataset.t === tab));
    ov.querySelector(".inst-tabs").hidden = installed;
    const pr = body.querySelector("[data-prompt]");
    if (pr) pr.onclick = async () => { if (!deferred) return; deferred.prompt(); try { const r = await deferred.userChoice; if (r && r.outcome === "accepted") { installed = true; } } catch (e) {} deferred = null; render(); };
    body.querySelectorAll("[data-copy]").forEach(b => b.onclick = async () => {
      const url = location.origin + "/";
      try { await navigator.clipboard.writeText(url); } catch (e) { const t = document.createElement("textarea"); t.value = url; document.body.appendChild(t); t.select(); document.execCommand("copy"); t.remove(); }
      b.textContent = "✓ Đã sao chép – dán vào " + (isIOS ? "Safari" : "Chrome"); });
  }
  function open() {
    if (ov) { ov.hidden = false; render(); return; }
    ov = document.createElement("div"); ov.className = "inst-ov"; ov.setAttribute("role", "dialog"); ov.setAttribute("aria-modal", "true"); ov.setAttribute("aria-label", "Cài app Kim Chỉ Vàng");
    ov.innerHTML = '<div class="inst-box"><div class="inst-hd"><img src="/icon-192.png" alt=""><div><b>Cài app Kim Chỉ Vàng</b><span>Thêm vào màn hình chính · 30 giây · miễn phí</span></div><button type="button" class="inst-x" aria-label="Đóng">✕</button></div>' +
      '<div class="inst-why"><div><i>⚡</i>Mở nhanh 1 chạm như ứng dụng</div><div><i>🔔</i>Báo lệnh MUA/BÁN về máy</div><div><i>📱</i>Toàn màn hình, không thanh địa chỉ</div></div>' +
      '<div class="inst-tabs">' + Object.entries(TABS).map(([k, v]) => '<button type="button" data-t="' + k + '">' + v.label + "</button>").join("") + '</div><div class="inst-body"></div></div>';
    document.body.appendChild(ov);
    ov.addEventListener("click", e => { if (e.target === ov || e.target.closest(".inst-x")) ov.hidden = true; });
    ov.querySelectorAll(".inst-tabs button").forEach(b => b.onclick = () => { tab = b.dataset.t; render(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape" && ov && !ov.hidden) ov.hidden = true; });
    render();
  }
  function wire() { document.querySelectorAll("[data-install]").forEach(b => { if (!b.dataset.wired) { b.dataset.wired = "1"; b.onclick = open; } }); render(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", wire); else wire();
  window.kcvInstallOpen = open;
})();
