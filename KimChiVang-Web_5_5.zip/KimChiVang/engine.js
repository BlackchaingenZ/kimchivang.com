// ============================================================================
// KIM CHỈ VÀNG EP – engine JavaScript (port 1:1 từ Pine Script v6)
// Chỉ chạy trên các nến M1 ĐÃ ĐÓNG. bars = [{t: open ms UTC, o, h, l, c}]
// ============================================================================
const KCV_PRESETS = {
  "Chặt (v1)":      { trendMode: "HHHL", useFast: false, useEmaLn: false, confMode: "strict", maxWait: 3, maxActive: 1, penK: 0.25, zoneK: 0.6, entryK: 1.5, leaveK: 0.5 },
  "Cân bằng":       { trendMode: "BOS",  useFast: true,  useEmaLn: false, confMode: "wide",   maxWait: 5, maxActive: 2, penK: 0.25, zoneK: 0.6, entryK: 1.5, leaveK: 0.25 },
  "Nhiều tín hiệu": { trendMode: "BOS",  useFast: true,  useEmaLn: true,  confMode: "wide",   maxWait: 6, maxActive: 3, penK: 0.25, zoneK: 1.0, entryK: 1.5, leaveK: 0.25 }
};
const KCV_FIXED = {
  pvLeft: 5, pvRight: 3, fastL: 3, fastR: 2, minGap: 8, minGapF: 5, maxSpan: 120, maxAge: 180,
  minBody: 0.5, minStepAtr: 0.10, emaLnLen: 20,
  tpDist: 8, slDist: 20, useDca: true, dcaDist: 10, priceUnit: 1, lateTol: 3,
  sessSH: 7, sessSM: 0, sessEH: 21, sessEM: 0, tzOff: 7 * 3600000, tick: 0.001
};

function kcvRun(bars, cfg) {
  const P = Object.assign({}, KCV_FIXED, KCV_PRESETS[(cfg && cfg.preset) || "Cân bằng"] || KCV_PRESETS["Cân bằng"], cfg || {});
  const n = bars.length;
  const O = new Array(n), H = new Array(n), L = new Array(n), C = new Array(n), T = new Array(n);
  for (let i = 0; i < n; i++) { const b = bars[i]; O[i] = b.o; H[i] = b.h; L[i] = b.l; C[i] = b.c; T[i] = b.t; }
  const rt = v => Math.round(v / P.tick) * P.tick;
  const DAY = 86400000;

  // ---------- series ----------
  const atr = new Array(n).fill(NaN);
  { let s = 0;
    for (let i = 0; i < n; i++) {
      const tr = i === 0 ? H[i] - L[i] : Math.max(H[i] - L[i], Math.abs(H[i] - C[i - 1]), Math.abs(L[i] - C[i - 1]));
      if (i < 13) s += tr; else if (i === 13) { s += tr; atr[i] = s / 14; } else atr[i] = (atr[i - 1] * 13 + tr) / 14;
    } }
  const ema = len => {
    const out = new Array(n).fill(NaN), a = 2 / (len + 1); let s = 0;
    for (let i = 0; i < n; i++) {
      if (i < len - 1) s += C[i]; else if (i === len - 1) { s += C[i]; out[i] = s / len; } else out[i] = a * C[i] + (1 - a) * out[i - 1];
    }
    return out;
  };
  const emaLn = ema(P.emaLnLen);
  const pivH = (i, l, r) => { const c = i - r; if (c - l < 0) return NaN; const v = H[c];
    for (let j = c - l; j < c; j++) if (H[j] >= v) return NaN;
    for (let j = c + 1; j <= i; j++) if (H[j] > v) return NaN; return v; };
  const pivL = (i, l, r) => { const c = i - r; if (c - l < 0) return NaN; const v = L[c];
    for (let j = c - l; j < c; j++) if (L[j] <= v) return NaN;
    for (let j = c + 1; j <= i; j++) if (L[j] < v) return NaN; return v; };

  // ---------- state ----------
  const MAXPV = 30;
  const phMP = [], phMB = [], plMP = [], plMB = [], phFP = [], phFB = [], plFP = [], plFB = [];
  let bullBroken = false, bearBroken = false, bosDir = 0, trendDir = 0, structWhy = "Chưa đủ pivot";
  let buM = null, beM = null, buF = null, beF = null;
  const tls = [];
  const mkSetup = () => ({ st: 0, touchB: 0, ext: 0, fail: "" });
  const sBuM = mkSetup(), sBuF = mkSetup(), sBuE = mkSetup(), sBeM = mkSetup(), sBeF = mkSetup(), sBeE = mkSetup();
  let active = [];
  const sigs = [], marks = [], exits = [], rs = [];
  let nSig = 0, nTP = 0, nSL = 0, nUnk = 0, pnlAll = 0;
  let sesStartV = NaN, sesEndV = NaN, inWinV = false, cutoffV = 0;
  let i = 0, penTol = 0, zoneTol = 0, entryMax = 0, leaveDst = 0;

  const lineVal = (t, b) => t.a1P + t.slope * (b - t.a1B);
  const isValid = t => !!t && t.status === 1;
  const valAt = t => t ? lineVal(t, i) : NaN;
  const known = t => t ? t.knownB : 0;

  function fValid(bull, a1B, a1P, a2B, a2P, tol) {
    const slope = (a2P - a1P) / (a2B - a1B);
    for (let b = a1B + 1; b <= a2B - 1; b++) {
      const y = a1P + slope * (b - a1B);
      if (bull ? L[b] < y - tol : H[b] > y + tol) return false;
    }
    for (let b = a2B + 1; b <= i; b++) {
      const y = a1P + slope * (b - a1B);
      if (bull ? C[b] < y - tol : C[b] > y + tol) return false;
    }
    return true;
  }
  function fBuild(bull, Pa, BX, gapMin, isFast) {
    if (Pa.length < 2) return null;
    const a2B = BX[0], a2P = Pa[0];
    for (let k = 1; k < Pa.length; k++) {
      const cB = BX[k], cP = Pa[k], gap = a2B - cB;
      if (gap > P.maxSpan) break;
      if (gap >= gapMin && (bull ? cP < a2P : cP > a2P) && fValid(bull, cB, cP, a2B, a2P, penTol)) {
        const t = { a1B: cB, a1P: cP, a2B, a2P, slope: (a2P - cP) / (a2B - cB), knownB: i, status: 1, fast: isFast, bull, retireB: null };
        tls.push(t);
        return t;
      }
    }
    return null;
  }
  const retire = t => { if (t && t.retireB === null) t.retireB = i; };
  function fStatus(t, bull) {
    if (t && t.status === 1 && i > t.knownB) {
      const v = lineVal(t, i);
      if (bull ? C[i] < v - penTol : C[i] > v + penTol) { t.status = 2; retire(t); }
      else if (i - t.a2B > P.maxAge) { t.status = 3; retire(t); }
    }
  }
  function confBull() {
    const rng = H[i] - L[i];
    const strict = rng > 0 && C[i] > O[i] && (C[i] - O[i]) >= P.minBody * rng && C[i] > H[i - 1];
    if (P.confMode === "strict") return strict;
    const engulf = C[i] > O[i] && C[i - 1] < O[i - 1] && C[i] >= O[i - 1] && O[i] <= C[i - 1];
    const pin = rng > 0 && (Math.min(O[i], C[i]) - L[i]) >= 0.5 * rng && C[i] >= L[i] + 0.6 * rng;
    return strict || engulf || pin;
  }
  function confBear() {
    const rng = H[i] - L[i];
    const strict = rng > 0 && C[i] < O[i] && (O[i] - C[i]) >= P.minBody * rng && C[i] < L[i - 1];
    if (P.confMode === "strict") return strict;
    const engulf = C[i] < O[i] && C[i - 1] > O[i - 1] && C[i] <= O[i - 1] && O[i] >= C[i - 1];
    const pin = rng > 0 && (H[i] - Math.max(O[i], C[i])) >= 0.5 * rng && C[i] <= H[i] - 0.6 * rng;
    return strict || engulf || pin;
  }
  function fSetup(s, bull, v, isOn, knownB, canSig) {
    let fire = false;
    if (!isOn || isNaN(v) || i <= knownB) { s.st = 0; return false; }
    const edge = bull ? v + zoneTol : v - zoneTol;
    const far = bull ? L[i] > edge + leaveDst : H[i] < edge - leaveDst;
    const touch = bull ? L[i] <= edge : H[i] >= edge;
    const dep = bull ? L[i] - v : v - H[i];
    if (s.st === 0 && far) s.st = 1;
    else if (s.st === 1 && touch) { s.st = 2; s.touchB = i; s.ext = dep; }
    else if (s.st === 2) s.ext = Math.min(s.ext, dep);
    if (s.st === 2) {
      if (s.ext < -penTol) { s.st = 0; s.fail = "Nhịp hồi xuyên sâu quá dung sai"; }
      else {
        const conf = bull ? confBull() : confBear();
        const distOk = bull ? (C[i] > v && C[i] - v <= entryMax) : (C[i] < v && v - C[i] <= entryMax);
        if (conf && distOk && canSig) { fire = true; s.fail = ""; }
        else {
          s.fail = !conf ? (bull ? "Chờ nến xác nhận tăng" : "Chờ nến xác nhận giảm") : !distOk ? "Entry quá xa đường" : "Đã đủ số lệnh";
          if (i - s.touchB >= P.maxWait) s.st = 0; else if (far) s.st = 1;
        }
      }
    }
    return fire;
  }
  const pushPv = (Pa, BX, v, b) => { Pa.unshift(v); BX.unshift(b); if (Pa.length > MAXPV) { Pa.pop(); BX.pop(); } };

  // ---------- main loop: mỗi nến đã đóng ----------
  for (i = 0; i < n; i++) {
    const a = atr[i];
    if (isNaN(a)) continue;
    penTol = P.penK * a; zoneTol = P.zoneK * a; entryMax = P.entryK * a; leaveDst = P.leaveK * a;
    const tClose = T[i] + 60000;

    // 6.0 phiên (giờ Việt Nam)
    const dayStart = Math.floor((tClose + P.tzOff) / DAY) * DAY - P.tzOff;
    let sesDur = (P.sessEH * 60 + P.sessEM - P.sessSH * 60 - P.sessSM) * 60000; if (sesDur <= 0) sesDur += DAY;
    let sesStart = dayStart + (P.sessSH * 60 + P.sessSM) * 60000; if (tClose < sesStart) sesStart -= DAY;
    sesStartV = sesStart; sesEndV = sesStart + sesDur;
    inWinV = tClose >= sesStartV && tClose <= sesEndV;

    // 6.1 pivot
    const phM = pivH(i, P.pvLeft, P.pvRight), plM = pivL(i, P.pvLeft, P.pvRight);
    const phF = pivH(i, P.fastL, P.fastR), plF = pivL(i, P.fastL, P.fastR);
    const newPHM = !isNaN(phM), newPLM = !isNaN(plM), newPHF = P.useFast && !isNaN(phF), newPLF = P.useFast && !isNaN(plF);
    if (newPHM) { pushPv(phMP, phMB, phM, i - P.pvRight); bearBroken = false; }
    if (newPLM) { pushPv(plMP, plMB, plM, i - P.pvRight); bullBroken = false; }
    if (newPHF) pushPv(phFP, phFB, phF, i - P.fastR);
    if (newPLF) pushPv(plFP, plFB, plF, i - P.fastR);

    // 6.2 xu hướng
    let raw = 0;
    if (P.trendMode === "HHHL") {
      if (phMP.length >= 2 && plMP.length >= 2) {
        const step = P.minStepAtr * a;
        const hh = phMP[0] > phMP[1] + step, hl = plMP[0] > plMP[1] + step;
        const lh = phMP[0] < phMP[1] - step, ll = plMP[0] < plMP[1] - step;
        const sd = hh && hl ? 1 : lh && ll ? -1 : 0;
        if (sd === 1 && C[i] < plMP[0]) bullBroken = true;
        if (sd === -1 && C[i] > phMP[0]) bearBroken = true;
        raw = sd === 1 && !bullBroken ? 1 : sd === -1 && !bearBroken ? -1 : 0;
        structWhy = sd === 0 ? "Đỉnh/đáy không cùng chiều" : raw === 0 ? "Cấu trúc mất hiệu lực" : "";
      } else structWhy = "Chưa đủ 2 đỉnh và 2 đáy";
    } else {
      if (phMP.length > 0 && plMP.length > 0) {
        if (C[i] > phMP[0]) bosDir = 1; else if (C[i] < plMP[0]) bosDir = -1;
        raw = bosDir; structWhy = bosDir === 0 ? "Chưa có phá cấu trúc" : "";
      } else structWhy = "Chưa đủ đỉnh/đáy";
    }
    trendDir = raw;

    // 6.3 trendline
    if (newPLM) { const t = fBuild(true, plMP, plMB, P.minGap, false); if (t) { if (isValid(buM)) retire(buM); buM = t; sBuM.st = 0; } }
    if (newPHM) { const t = fBuild(false, phMP, phMB, P.minGap, false); if (t) { if (isValid(beM)) retire(beM); beM = t; sBeM.st = 0; } }
    if (newPLF) { const t = fBuild(true, plFP, plFB, P.minGapF, true); if (t) { if (isValid(buF)) retire(buF); buF = t; sBuF.st = 0; } }
    if (newPHF) { const t = fBuild(false, phFP, phFB, P.minGapF, true); if (t) { if (isValid(beF)) retire(beF); beF = t; sBeF.st = 0; } }
    // 6.4
    fStatus(buM, true); fStatus(beM, false); fStatus(buF, true); fStatus(beF, false);

    // 6.5 theo dõi lệnh
    let justExited = false;
    for (let k = active.length - 1; k >= 0; k--) {
      const sg = active[k];
      if (!(i > sg.bar)) continue;
      const hitTP = sg.dir === 1 ? H[i] >= sg.tp : L[i] <= sg.tp;
      const hitSL = sg.dir === 1 ? L[i] <= sg.sl : H[i] >= sg.sl;
      if (hitTP || hitSL) {
        const res = hitTP && hitSL ? "?" : hitTP ? "TP" : "SL";
        const exPx = res === "TP" ? sg.tp : sg.sl;
        const pnl = (exPx - sg.entry) * sg.dir / P.priceUnit;
        pnlAll += pnl;
        if (res === "TP") nTP++; else if (res === "SL") nSL++; else nUnk++;
        // Web: chỉ tính lệnh vào VÀ đóng trong cùng khung 07:00–21:00
        sg.closedOut = tClose > sg.sesEnd;
        if (sg.inWin && !sg.closedOut) rs.push({ tClose, tOpen: sg.tOpen, kind: res, pnl });
        justExited = true;
        sg.endBar = i; sg.res = res; sg.pnl = pnl; sg.exitT = tClose;
        exits.push({ bar: i, dir: sg.dir, res, pnl, y: sg.dir === 1 ? H[i] : L[i] });
        active.splice(k, 1);
      } else if (P.useDca && !sg.isAdd && !sg.added) {
        const dcaHit = sg.dir === 1 ? L[i] <= sg.addAt : H[i] >= sg.addAt;
        if (dcaHit) {
          sg.added = true; sg.tp = sg.entry; sg.tpBE = true;
          sg.boxTP = [Math.max(sg.entry, sg.addAt), Math.min(sg.entry, sg.addAt)];
          const sg2 = { id: sigs.length, dir: sg.dir, bar: i, entry: sg.addAt, tp: sg.entry, sl: sg.sl, src: "Gồng", tOpen: sg.tOpen, tSig: tClose,
            inWin: sg.inWin, sesEnd: sg.sesEnd, isAdd: true, added: true, addAt: NaN, endBar: null, res: null, pnl: null, parent: sg.id, boxTP: null, boxSL: null };
          nSig++; sigs.push(sg2); active.push(sg2);
          marks.push({ bar: i, dir: sg.dir, dca: true, y: sg.dir === 1 ? L[i] : H[i] });
        }
      }
    }

    // 6.6 thiết lập
    const canSig = active.length < P.maxActive && !(P.maxActive === 1 && justExited);
    let bFire = false, bSrc = "";
    if (fSetup(sBuM, true, valAt(buM), trendDir === 1 && isValid(buM), known(buM), canSig)) { bFire = true; bSrc = "TL"; }
    if (fSetup(sBuF, true, valAt(buF), P.useFast && trendDir === 1 && isValid(buF), known(buF), canSig && !bFire)) { bFire = true; bSrc = bSrc || "TLn"; }
    if (fSetup(sBuE, true, emaLn[i], P.useEmaLn && trendDir === 1, 0, canSig && !bFire)) { bFire = true; bSrc = bSrc || "EMA"; }
    let sFire = false, sSrc = "";
    if (fSetup(sBeM, false, valAt(beM), trendDir === -1 && isValid(beM), known(beM), canSig)) { sFire = true; sSrc = "TL"; }
    if (fSetup(sBeF, false, valAt(beF), P.useFast && trendDir === -1 && isValid(beF), known(beF), canSig && !sFire)) { sFire = true; sSrc = sSrc || "TLn"; }
    if (fSetup(sBeE, false, emaLn[i], P.useEmaLn && trendDir === -1, 0, canSig && !sFire)) { sFire = true; sSrc = sSrc || "EMA"; }
    if (bFire) { sBuM.st = 0; sBuF.st = 0; sBuE.st = 0; }
    if (sFire) { sBeM.st = 0; sBeF.st = 0; sBeE.st = 0; }

    // 6.7 phát tín hiệu
    if (bFire || sFire) {
      const d = bFire ? 1 : -1, e = rt(C[i]);
      const sg = { id: sigs.length, dir: d, bar: i, entry: e, tp: rt(e + d * P.tpDist * P.priceUnit), sl: rt(e - d * P.slDist * P.priceUnit),
        src: bFire ? bSrc : sSrc, tOpen: tClose, tSig: tClose, inWin: inWinV, sesEnd: sesEndV, isAdd: false, added: false,
        addAt: rt(e - d * P.dcaDist * P.priceUnit), endBar: null, res: null, pnl: null, tpBE: false };
      sg.tp0 = sg.tp;   // chốt lời ban đầu (trước khi gồng dời về hòa vốn)
      sg.boxTP = [Math.max(e, sg.tp), Math.min(e, sg.tp)];
      sg.boxSL = [Math.max(e, sg.sl), Math.min(e, sg.sl)];
      nSig++; sigs.push(sg); active.push(sg);
      marks.push({ bar: i, dir: d, dca: false, y: d === 1 ? L[i] : H[i] });
    }
    cutoffV = sesStartV;
  }

  // ---------- thống kê phiên ----------
  let wWin = 0, wLoss = 0, wBe = 0, wNet = 0;
  for (const r of rs) {
    if (r.tClose >= cutoffV && r.tOpen >= cutoffV) {
      wNet += r.pnl;
      if (r.pnl > 0) wWin++; else if (r.pnl < 0) wLoss++; else wBe++;
    }
  }
  return {
    P, n, sigs, marks, exits, tls, active, trendDir, structWhy,
    stats: { wWin, wLoss, wBe, wNet, nSig, nTP, nSL, nUnk, pnlAll },
    session: { start: sesStartV, end: sesEndV, inWin: inWinV }
  };
}

// ============================================================================
// TỔNG KẾT TUẦN / THÁNG – chỉ lệnh vào và đóng trong 07:00–21:00 (giờ VN)
// Làm mới mỗi tháng: chỉ tính các lệnh vào trong tháng hiện tại.
// ============================================================================
function kcvSummary(res, nowMs) {
  const TZ = 7 * 3600000, DAY = 86400000;
  const vn = t => new Date(t + TZ);
  const now = vn(nowMs), Y = now.getUTCFullYear(), M = now.getUTCMonth();
  const monthStart = Date.UTC(Y, M, 1) - TZ, monthEnd = Date.UTC(Y, M + 1, 1) - TZ;   // mốc UTC
  const dayKey = t => { const d = vn(t); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()); }; // ms của 00:00 VN (tính như UTC)
  const blank = () => ({ n: 0, win: 0, loss: 0, be: 0, net: 0 });
  const add = (g, s) => { g.n++; g.net += s.pnl; if (s.pnl > 0) g.win++; else if (s.pnl < 0) g.loss++; else g.be++; };
  const fin = g => { g.net = Math.round(g.net * 100) / 100; g.rate = g.n ? Math.round(g.win / g.n * 100) : null; return g; };
  const trades = res.sigs.filter(s => s.res !== null && s.inWin && !s.closedOut && s.tOpen >= monthStart && s.tOpen < monthEnd);
  const total = blank(), days = new Map();
  for (const s of trades) { add(total, s); const k = dayKey(s.tOpen); if (!days.has(k)) days.set(k, blank()); add(days.get(k), s); }
  // các tuần (thứ 2 → CN), cắt theo tháng, tới tuần hiện tại
  const first = Date.UTC(Y, M, 1), last = Date.UTC(Y, M + 1, 0), today = dayKey(nowMs);
  const weeks = [];
  let ws = first, idx = 1;
  while (ws <= Math.min(last, today)) {
    const dow = (new Date(ws).getUTCDay() + 6) % 7;            // 0 = thứ 2
    const we = Math.min(last, ws + (6 - dow) * DAY);
    const g = blank();
    for (const [k, v] of days) if (k >= ws && k <= we) { g.n += v.n; g.win += v.win; g.loss += v.loss; g.be += v.be; g.net += v.net; }
    weeks.push(Object.assign(fin(g), { idx: idx++, from: ws, to: we, current: today >= ws && today <= we }));
    ws = we + DAY;
  }
  const dayList = [...days.entries()].sort((a, b) => a[0] - b[0]).map(([k, v]) => Object.assign(fin(v), { day: k }));
  let best = null, worst = null;
  for (const d of dayList) { if (!best || d.net > best.net) best = d; if (!worst || d.net < worst.net) worst = d; }
  return { month: M + 1, year: Y, total: fin(total), weeks, days: dayList, best, worst, tradingDays: dayList.length, updated: nowMs };
}
if (typeof module !== "undefined") module.exports = { kcvRun, kcvSummary, KCV_PRESETS, KCV_FIXED };
