// ============================================================================
// Kim Chỉ Vàng – máy chủ nhận giá MT5, khóa trang bằng mã khách hàng, phục vụ web
// Chạy:  node server.js        (cần Node.js 18 trở lên, không cần cài thư viện)
// Biến môi trường (đặt trong start.bat):
//   KCV_TOKEN  mã bí mật, phải trùng với ô Token trong EA
//   KCV_ADMIN  mật khẩu trang quản trị /quan-tri
//   PORT       cổng web (mặc định 80 – MT5 chỉ gửi được qua cổng 80/443)
// ============================================================================
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = parseInt(process.env.PORT || "80", 10);
const TOKEN = process.env.KCV_TOKEN || "doi-ma-bi-mat-nay";
const ADMIN_PASS = process.env.KCV_ADMIN || "doi-mat-khau-quan-tri";
const ROOT = __dirname;
const PUB = path.join(ROOT, "public");
const VIEWS = path.join(ROOT, "views");
const DATA = path.join(ROOT, "data.json");
const CODES_FILE = path.join(ROOT, "codes.json");
const SESS_FILE = path.join(ROOT, "sessions.json");
const MAX_BARS = 30000;          // số nến M1 máy chủ giữ (~3 tuần giao dịch) – đủ cho khung 3m / 15m / 1h
const SEND_BARS = 3000;          // số nến gửi cho trang web (mỗi khung) và số nến M1 dùng để sinh tín hiệu
const SESSION_DAYS = 90;         // khách đăng nhập 1 lần, giữ 90 ngày
const CONFIG = require("./public/config.js");
const { kcvRun } = require("./engine.js");
const KCV_OPT = { tpDist: CONFIG.tpDist, slDist: CONFIG.slDist, dcaDist: CONFIG.dcaDist, useDca: CONFIG.useDca, swingLen: CONFIG.swingLen, boxExtend: CONFIG.boxExtend, entryOffset: CONFIG.entryOffset,
  roundEntry: CONFIG.roundEntry, slMode: CONFIG.slMode, slBuffer: CONFIG.slBuffer, rr: CONFIG.rr, trendOnly: CONFIG.trendOnly, maxPerDir: CONFIG.maxPerDir };
const { loadVapid, sendPush } = require("./webpush.js");
const { buildInternal, oppositeOf } = require("./internal.js");
const BK = require("./backup.js");
const BACKUP_DIR = path.join(ROOT, "backups");
const INTERNAL_FILE = path.join(ROOT, "internal.json");
const MLEADS_FILE = path.join(ROOT, "leads.json");        // khách nhân viên tự thêm (FB, Zalo, giới thiệu…)
const TG_TOKEN = process.env.KCV_TG_TOKEN || "", TG_CHAT = String(process.env.KCV_TG_CHAT || "").trim();
// Nhóm Telegram RIÊNG cho khách đăng ký dùng thử / chốt khách (bỏ trống token → dùng chung bot ở trên).
// Chưa điền KCV_TG_LEAD_CHAT thì tin khách vẫn gửi vào nhóm lệnh như cũ.
// Nhận cả ID số (-100…) lẫn tên nhóm/kênh công khai dạng @TenNhom (gõ thiếu @ sẽ tự thêm)
const tgChat = v => { v = String(v || "").trim(); return !v || /^-?\d+$/.test(v) || v.startsWith("@") ? v : "@" + v; };
const TG_LEAD_TOKEN = process.env.KCV_TG_LEAD_TOKEN || TG_TOKEN, TG_LEAD_CHAT = tgChat(process.env.KCV_TG_LEAD_CHAT);
const LEAD_TG = TG_LEAD_CHAT ? { token: TG_LEAD_TOKEN, chat: TG_LEAD_CHAT } : null;
// Nhóm Telegram nhận file sao lưu hằng ngày: ID (-100…) hoặc @TenNhom.
// Gửi vào nhóm @ (công khai) → file luôn được MÃ HÓA bằng mật khẩu sao lưu (mặc định = mật khẩu quản trị).
const TG_BK_TOKEN = process.env.KCV_TG_BACKUP_TOKEN || TG_TOKEN, TG_BK_CHAT = tgChat(process.env.KCV_TG_BACKUP_CHAT);
const BK_PASS = process.env.KCV_BACKUP_PASSWORD || ADMIN_PASS;
const BK_ENCRYPT = TG_BK_CHAT.startsWith("@") || process.env.KCV_BACKUP_ENCRYPT === "1";
const PUSH_FILE = path.join(ROOT, "push.json");
const VAPID = loadVapid(path.join(ROOT, "vapid.json"));
const PUSH_SUBJECT = CONFIG.siteUrl || "https://kimchivang.com";

if (TOKEN === "doi-ma-bi-mat-nay") console.warn("⚠  Đang dùng Token mặc định. Hãy đổi KCV_TOKEN (trong start.bat) và Token trong EA.");
if (ADMIN_PASS === "doi-mat-khau-quan-tri") console.warn("⚠  Đang dùng mật khẩu quản trị mặc định. Hãy đổi KCV_ADMIN trong start.bat.");

// ---------- lưu file an toàn ----------
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { return d; } };
function saveJson(f, obj) { const tmp = f + ".tmp"; fs.writeFile(tmp, JSON.stringify(obj), err => { if (!err) fs.rename(tmp, f, () => {}); }); }

// ---------- dữ liệu giá ----------
let state = readJson(DATA, null);
if (!state || !Array.isArray(state.bars)) state = { symbol: "XAUUSD", digits: 3, updated: 0, bars: [] };
else console.log("Đã đọc", state.bars.length, "nến từ data.json");
// gộp nến M1 thành khung 3m / 15m / 1h (mốc theo giờ UTC, giống TradingView) – lưu đệm theo lần cập nhật giá
const aggCache = {};
function aggBars(tf) {
  const key = state.updated + ":" + state.bars.length + ":" + (state.bars.length ? state.bars[state.bars.length - 1][4] : 0);
  if (aggCache[tf] && aggCache[tf].key === key) return aggCache[tf].bars;
  const out = [], sec = tf * 60;
  for (const b of state.bars) {
    const t = Math.floor(b[0] / sec) * sec, l = out[out.length - 1];
    if (l && l[0] === t) { if (b[2] > l[2]) l[2] = b[2]; if (b[3] < l[3]) l[3] = b[3]; l[4] = b[4]; }
    else out.push([t, b[1], b[2], b[3], b[4]]);
  }
  aggCache[tf] = { key, bars: out }; return out;
}
let dirty = false;
setInterval(() => { if (dirty) { dirty = false; saveJson(DATA, state); } }, 15000);
function merge(incoming) {
  const map = new Map(state.bars.map(b => [b[0], b]));
  for (const b of incoming) {
    if (!Array.isArray(b) || b.length < 5) continue;
    const v = b.slice(0, 5).map(Number);
    if (!v.every(Number.isFinite) || v[0] % 60 !== 0) continue;
    map.set(v[0], v);
  }
  state.bars = [...map.values()].sort((a, b) => a[0] - b[0]).slice(-MAX_BARS);
}


// ============================================================================
// MÃ KHÁCH HÀNG & PHIÊN ĐĂNG NHẬP
// ============================================================================
let codes = readJson(CODES_FILE, { list: [] });          // {code,name,note,created,expires,maxDevices,active}
let sessions = readJson(SESS_FILE, {});                    // token -> {code,created,lastSeen,ua,ip}
let adminSessions = new Map();                             // token -> expires
let authDirty = false;
setInterval(() => { if (authDirty) { authDirty = false; saveJson(CODES_FILE, codes); saveJson(SESS_FILE, sessions); } }, 10000);
const saveAuthNow = () => { authDirty = false; saveJson(CODES_FILE, codes); saveJson(SESS_FILE, sessions); };

const normCode = s => String(s || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
// tìm mã; mã dùng thử đã lên chính thức vẫn tìm được bằng mã TRY cũ (cookie trình duyệt, link cũ)
const findCode = c => { const n = normCode(c); if (!n) return undefined; return codes.list.find(x => !x.removed && normCode(x.code) === n) || codes.list.find(x => !x.removed && x.trialCode && normCode(x.trialCode) === n); };
// ---------- LINK GIỚI THIỆU (quản lý trên trang quản trị, lưu trong codes.json) ----------
// codes.refs = [{ slug, name, note, contact, active, created, clicks, uniq }]
const refSlugOk = s => /^[a-z0-9][a-z0-9-]{1,39}$/.test(s);
const RESERVED = ["api", "noi-bo", "quan-tri", "index", "index.html", "config.js", "sw.js", "manifest.webmanifest", "public", "views", "admin", "login"];
function refList() {
  if (!codes.refs) {                     // lần đầu: lấy các link đã khai báo trong config.js (refLinks)
    codes.refs = Object.entries(CONFIG.refLinks || {}).filter(([k]) => refSlugOk(String(k).toLowerCase()))
      .map(([k, v]) => ({ slug: String(k).toLowerCase(), name: String(v), note: "", contact: "", active: true, created: Date.now(), clicks: 0, uniq: 0 }));
  }
  return codes.refs;
}
let refTimer = null; const dirtyRefs = () => { if (!refTimer) refTimer = setTimeout(() => { refTimer = null; saveAuthNow(); }, 5000); };
const findRef = slug => refList().find(r => r.slug === String(slug || "").toLowerCase());
const ALPH = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";      // bỏ chữ dễ nhầm O/0, I/1, L
// Đổi mã dùng thử TRY-… thành mã chính thức KCV-XXXX-XXXX: giữ nguyên thiết bị đang đăng nhập và thông báo
function promoteCode(c) {
  const old = c.code, nc = newCode();
  c.trialCode = old; c.code = nc;
  for (const x of Object.values(sessions)) if (normCode(x.code) === normCode(old)) x.code = nc;
  let p = false; for (const r of Object.values(pushSubs)) if (normCode(r.code) === normCode(old)) { r.code = nc; p = true; }
  if (p) savePush();
  if (typeof mleads !== "undefined") { let m = false; for (const l of mleads.list) if (l.codeRef && normCode(l.codeRef) === normCode(old)) { l.codeRef = nc; m = true; } if (m) saveMleads(); }
  return nc;
}
function newCode() {
  let c;
  do { const b = crypto.randomBytes(8); c = "KCV-" + [...b.slice(0, 4)].map(x => ALPH[x % ALPH.length]).join("") + "-" + [...b.slice(4)].map(x => ALPH[x % ALPH.length]).join(""); }
  while (codes.list.some(x => normCode(x.code) === normCode(c)));
  return c;
}
// ---------- DÙNG THỬ: chỉ trừ thời gian nằm trong khung 07:00–21:00 giờ VN ----------
const VN = 7 * 3600000, DAYMS = 86400000;
const SES_A = (CONFIG.sessStart || 7) * 3600000, SES_B = (CONFIG.sessEnd || 21) * 3600000;
const TRIAL_MIN = CONFIG.trialMinutes || 300;
function inWindowMs(a, b) {                    // tổng thời gian trong khung phiên giữa 2 mốc
  if (!a || b <= a) return 0;
  let tot = 0, d = Math.floor((a + VN) / DAYMS) * DAYMS - VN;
  for (; d < b; d += DAYMS) tot += Math.max(0, Math.min(b, d + SES_B) - Math.max(a, d + SES_A));
  return tot;
}
const isOpenNow = () => { const t = (Date.now() + VN) % DAYMS; return t >= SES_A && t < SES_B; };
// Dùng thử: đếm liên tục (cả trong lẫn ngoài phiên) kể từ lúc đăng ký / mở mã lần đầu
function trialLeft(c) { const tot = (c.trialMinutes || TRIAL_MIN) * 60000; return c.firstUse ? Math.max(0, tot - (Date.now() - c.firstUse)) : tot; }
// Chuyển khách đang dùng thử theo cách tính cũ (chỉ trừ trong phiên) sang đếm liên tục, giữ nguyên số giờ còn lại
{ let n = 0; const now = Date.now();
  for (const c of codes.list) if (c.trial && c.firstUse && c.clock !== "wall") {
    const tot = (c.trialMinutes || TRIAL_MIN) * 60000, left = Math.max(0, tot - inWindowMs(c.firstUse, now));
    c.firstUse = now - (tot - left); c.clock = "wall"; n++; }
  if (n) { saveAuthNow(); console.log("Đã chuyển", n, "mã dùng thử sang đếm giờ liên tục (giữ nguyên thời gian còn lại)."); } }
const codeValid = c => c && c.active && (!c.expires || c.expires > Date.now()) && (!c.trial || trialLeft(c) > 0);
function newTrialCode() { let c; do { const b = crypto.randomBytes(4); c = "TRY-" + [...b].map(x => ALPH[x % ALPH.length]).join(""); } while (findCode(c)); return c; }

// ---------- tạo mã (dùng chung cho quản trị và nhân viên nội bộ) ----------
// by = null → quản trị tạo; by = mã nội bộ của nhân viên → ghi lại người cấp
const STAFF_DAYS = ["trial", "3", "30", "90", "180", "365"];          // nhân viên không được cấp mã nội bộ / không giới hạn
const STAFF_DAILY_MAX = 30;                                           // mỗi nhân viên tối đa 30 mã / 24 giờ
function makeCode(j, by) {
  const name = String(j.name || "").trim().slice(0, 80);
  if (!name) return { error: "Nhập tên khách" };
  const dk = String(j.days);
  if (by) {
    if (!STAFF_DAYS.includes(dk)) return { error: "Thời hạn này chỉ quản trị mới cấp được" };
    const n = codes.list.filter(c => c.byCode && !c.self && normCode(c.byCode) === normCode(by.code) && Date.now() - c.created < DAYMS).length;   // khách dùng thử được chốt không tính vào hạn mức cấp mã
    if (n >= STAFF_DAILY_MAX) return { error: "Bạn đã cấp " + n + " mã trong 24 giờ qua. Liên hệ quản trị nếu cần cấp thêm." };
  }
  const isTrial = dk === "trial";
  const days = isTrial ? 0 : parseInt(dk, 10) || 0;
  const maxDev = Math.max(1, Math.min(by ? 3 : 5, parseInt(j.maxDevices, 10) || 2));
  const c = { code: isTrial ? newTrialCode() : newCode(), name, note: String(j.note || "").slice(0, 200), created: Date.now(),
    expires: days > 0 ? Date.now() + days * 86400000 : null, maxDevices: maxDev, active: true };
  if (!by && dk === "staff") { c.staff = true; c.expires = null; c.maxDevices = Math.max(c.maxDevices, 3); }
  if (isTrial) { c.trial = true; c.trialMinutes = TRIAL_MIN; c.firstUse = null; c.maxDevices = 1; c.clock = "wall"; }  // giờ chạy từ lần nhập mã đầu tiên
  if (by) { c.byCode = by.code; c.byName = by.name || by.code; }
  codes.list.push(c); saveAuthNow();
  console.log("Cấp mã mới:", c.code, name, by ? "· bởi " + c.byName : "· bởi Admin");
  return c;
}
// ---------- thao tác trên mã: quản trị (by = null) hoặc nhân viên (by = mã nội bộ, chỉ với mã mình cấp) ----------
const ACT_LABEL = { lock: "Khóa", unlock: "Mở khóa", reset: "Đăng xuất thiết bị", extend: "Gia hạn", convert: "Chuyển chính thức", forever: "Vĩnh viễn", delete: "Xóa" };
const STAFF_ACTS = ["lock", "unlock", "reset", "extend", "convert", "delete"];
const STAFF_EXT = [3, 30, 90, 180, 365];
const deletedLog = () => (codes.deleted = codes.deleted || []);
function applyAction(c, j, by) {
  const a = String(j.action || "");
  let d = parseInt(j.days, 10) || 30;
  if (by) {
    if (!STAFF_ACTS.includes(a)) return { error: "Thao tác này chỉ quản trị mới làm được" };
    if ((a === "extend" || a === "convert") && !STAFF_EXT.includes(d)) return { error: "Thời hạn gia hạn không hợp lệ" };
  }
  const kick = () => devicesOf(c.code).forEach(([t]) => delete sessions[t]);
  if (a === "lock") { c.active = false; kick(); }
  else if (a === "unlock") c.active = true;
  else if (a === "reset") kick();
  else if (a === "extend") { if (c.trial) { c.trial = false; c.wasTrial = true; c.maxDevices = Math.max(c.maxDevices || 1, 2); } c.expires = Math.max(Date.now(), c.expires || Date.now()) + d * 86400000; }
  else if (a === "forever") { c.expires = null; c.trial = false; }
  else if (a === "convert") { c.trial = false; c.wasTrial = true; c.expires = Date.now() + d * 86400000; c.maxDevices = Math.max(c.maxDevices || 1, 2); c.active = true; }
  else if (a === "delete") {
    kick();
    if (c.self) { c.removed = Date.now(); c.removedBy = by ? (by.name || by.code) : "Admin"; c.active = false; }   // khách tự đăng ký: giữ hồ sơ ở Khách mới / KPI, mã không dùng được nữa
    else codes.list = codes.list.filter(x => x !== c);
    for (const [ep, r] of Object.entries(pushSubs)) if (normCode(r.code) === normCode(c.code)) delete pushSubs[ep];
    savePush();
  }
  else return { error: "Thao tác không hợp lệ" };
  if (a === "extend" || a === "forever" || a === "convert") delete c.remind;          // hạn mới → nhắc lại từ đầu
  if ((a === "extend" || a === "convert" || a === "forever") && /^TRY-/i.test(c.code)) {
    promoteCode(c);
    // khách tự đăng ký dùng thử → nhân viên chốt: ghi nhân viên là người cấp mã chính thức (hiện ở "Mã bạn đã cấp")
    if (by && !c.byCode) { c.byCode = by.code; c.byName = by.name || by.code; c.issuedAt = Date.now(); }
  }   // lên chính thức → cấp mã đăng nhập chính thức KCV-…
  const who = by ? (by.name || by.code) : "Admin";
  const what = ACT_LABEL[a] + (a === "extend" || a === "convert" ? " " + d + " ngày" : "");
  // khách dùng thử vừa lên chính thức → ghi công người chốt (ưu tiên nhân viên đang phụ trách) và báo cả nhóm
  if ((a === "convert" || a === "extend") && c.wasTrial && !c.trial && !c.closedAt) {
    c.closedAt = Date.now(); c.closedDays = d;
    c.closedBy = c.careBy || who; c.closedByCode = c.careByCode || (by ? by.code : null); c.convertedBy = who;
    notifyClose(c);
  }
  const h = { t: Date.now(), by: who, byCode: by ? by.code : null, act: what };
  if (a === "delete") { const L = deletedLog(); L.push({ code: c.code, name: c.name, note: c.note || "", issuer: byLabel(c), t: h.t, by: who }); codes.deleted = L.slice(-300); }
  else { c.hist = (c.hist || []).concat(h).slice(-20); }
  console.log("Thao tác mã:", c.code, c.name, "·", what, "· bởi", who);
  return { ok: true };
}
// Người cấp hiển thị trên trang quản trị (lấy tên hiện tại của nhân viên nếu còn mã)
function byLabel(c) {
  if (c.self && !c.byCode) return "Khách tự đăng ký";
  if (c.self) { const st = findCode(c.byCode); return ((st ? st.name : c.byName) || c.byCode) + " (chốt từ dùng thử)"; }
  if (!c.byCode) return "Admin";
  const st = findCode(c.byCode);
  return (st ? st.name : c.byName) || c.byCode;
}
const normPhone = p => { let d = String(p || "").replace(/\D/g, ""); if (d.startsWith("84")) d = "0" + d.slice(2); return /^0[35789]\d{8}$/.test(d) ? d : null; };
// ---------- chống lạm dụng dùng thử: nhận diện thiết bị + mạng ----------
// Mạng gần nhau: IPv4 cùng /24 (cùng wifi / cùng trạm), IPv6 cùng /48. "Vùng nhà mạng": IPv4 /16, IPv6 /32.
function expand6(ip) { const [h, t = ""] = ip.split("::"); const a = h ? h.split(":") : [], b = t ? t.split(":") : []; return a.concat(Array(Math.max(0, 8 - a.length - b.length)).fill("0"), b).map(x => x.toLowerCase().replace(/^0+(?=.)/, "")); }
function netOf(ip, wide) {
  ip = String(ip || "").replace(/^::ffff:/i, "");
  if (/^\d+\.\d+\.\d+\.\d+$/.test(ip)) return ip.split(".").slice(0, wide ? 2 : 3).join(".");
  if (ip.includes(":")) return expand6(ip).slice(0, wide ? 2 : 3).join(":");
  return ip;
}
const FP_DAYS = 60;                                // so khớp với các lượt dùng thử trong 60 ngày gần nhất
function trialAbuse(fp, ip) {
  const now = Date.now(), net = netOf(ip), wide = netOf(ip, true), hits = [];
  if (!fp || !fp.hw) return { block: false, flags: [{ why: "Không lấy được dấu thiết bị (trình duyệt chặn hoặc tắt JavaScript)" }] };
  for (const c of codes.list) {
    if (!c.self || !c.fp || now - c.created > FP_DAYS * DAYMS) continue;
    const sameFp = c.fp.fp && c.fp.fp === fp.fp, sameHw = c.fp.hw === fp.hw, sameNet = netOf(c.ip) === net, sameWide = netOf(c.ip, true) === wide, recent = now - c.created < 7 * DAYMS;
    const who = { code: c.code, name: c.name, phone: c.phone };
    if (sameFp && sameNet) hits.push(Object.assign({ block: true, why: "Cùng thiết bị và cùng mạng với lượt dùng thử trước" }, who));
    else if (sameHw && sameNet) hits.push(Object.assign({ block: true, why: "Cùng máy (khác trình duyệt / ẩn danh) và cùng mạng với lượt dùng thử trước" }, who));
    else if (sameFp && sameWide && recent) hits.push(Object.assign({ block: true, why: "Cùng thiết bị, cùng nhà mạng, đăng ký lại trong 7 ngày" }, who));
    else if (sameFp) hits.push(Object.assign({ block: false, why: "Trùng dấu thiết bị (có thể chỉ là cùng dòng máy)" }, who));
    else if (sameHw && sameWide && recent) hits.push(Object.assign({ block: false, why: "Cùng loại máy, cùng nhà mạng, đăng ký trong 7 ngày" }, who));
  }
  return { block: hits.some(h => h.block), flags: hits.slice(0, 3) };
}
const recentSelfFromIp = ip => codes.list.filter(c => c.self && c.ip === ip && Date.now() - c.created < DAYMS).length;   // đếm theo dữ liệu đã lưu → khởi động lại không mất
const devicesOf = code => Object.entries(sessions).filter(([, s]) => normCode(s.code) === normCode(code));

function parseCookies(req) {
  const out = {}; (req.headers.cookie || "").split(";").forEach(p => { const i = p.indexOf("="); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}
function isHttps(req) { return req.headers["x-forwarded-proto"] === "https" || /https/.test(req.headers["cf-visitor"] || ""); }
function setCookie(req, res, name, val, maxAgeSec) {
  const c = name + "=" + encodeURIComponent(val) + "; Path=/; HttpOnly; SameSite=Lax; Max-Age=" + maxAgeSec + (isHttps(req) ? "; Secure" : "");
  const prev = res.getHeader("Set-Cookie"); res.setHeader("Set-Cookie", prev ? [].concat(prev, c) : c);
}
function clientIp(req) { return req.headers["cf-connecting-ip"] || (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || req.socket.remoteAddress || ""; }

// Phiên khách: trả về {token, sess, code} hoặc null
function customer(req) {
  const t = parseCookies(req).kcv_s; if (!t || !sessions[t]) return null;
  const s = sessions[t], c = findCode(s.code);
  if (!codeValid(c) || s.created + SESSION_DAYS * 86400000 < Date.now()) { delete sessions[t]; authDirty = true; return null; }
  const now = Date.now(); if (now - (s.lastSeen || 0) > 60000) { s.lastSeen = now; authDirty = true; }
  return { token: t, sess: s, code: c };
}
function isAdmin(req) { const t = parseCookies(req).kcv_a; const e = t && adminSessions.get(t); if (e && e > Date.now()) return true; if (t) adminSessions.delete(t); return false; }

// ============================================================================
// BẢO TRÌ & KIỂM THỬ – trạng thái lưu ở maint.json (khởi động lại không mất)
//  · Bảo trì: khách/nhân viên chỉ thấy trang thông báo, API trả 503; máy chủ vẫn nhận giá, dò tín hiệu bình thường
//    nhưng KHÔNG gửi thông báo khách / nhân viên / Telegram và KHÔNG ghi tin nội bộ → số liệu chính thức không bị lẫn
//  · Kiểm thử: chỉ trình duyệt đang đăng nhập quản trị mới bật được (cookie kcv_x gắn với phiên quản trị)
// ============================================================================
const MAINT_FILE = path.join(ROOT, "maint.json");
const MAINT_MSG = "Hệ thống đang được bảo trì và nâng cấp. Các chức năng và tín hiệu giao dịch sẽ tạm thời ngừng hoạt động. Vui lòng quay lại sau.";
let maint = readJson(MAINT_FILE, null);
if (!maint || typeof maint !== "object") maint = { on: false };
if (!Array.isArray(maint.log)) maint.log = [];
if (!maint.testSubs || typeof maint.testSubs !== "object") maint.testSubs = {};      // thiết bị nhận thông báo kiểm thử (tách khỏi push.json)
const saveMaint = () => { try { writeJsonSync(MAINT_FILE, maint); } catch (e) { console.error("Không lưu được maint.json:", e.message); } };
const testSessions = new Map();                            // token kiểm thử -> {exp, admin}
function isTester(req) {
  const ck = parseCookies(req), x = ck.kcv_x && testSessions.get(ck.kcv_x);
  if (!x) return false;
  if (x.exp < Date.now() || x.admin !== ck.kcv_a || !isAdmin(req)) { testSessions.delete(ck.kcv_x); return false; }   // hết phiên quản trị → hết quyền kiểm thử
  return true;
}
function maintLog(req, act, extra) {
  maint.log.unshift(Object.assign({ t: Date.now(), act, by: "Quản trị", ip: req ? clientIp(req) : "", ua: req ? String(req.headers["user-agent"] || "").slice(0, 120) : "" }, extra || {}));
  maint.log = maint.log.slice(0, 300); saveMaint();
  console.log("[BẢO TRÌ]", act, extra && extra.note ? "· " + extra.note : "");
}
const durTxt = ms => { const m = Math.round(ms / 60000); return m < 60 ? m + " phút" : Math.floor(m / 60) + " giờ " + (m % 60) + " phút"; };
// thông báo tín hiệu lúc bảo trì: chỉ gửi tới thiết bị kiểm thử, có nhãn [KIỂM THỬ]
function pushTest(data) {
  const list = Object.entries(maint.testSubs); if (!list.length) return Promise.resolve({ ok: 0, total: 0 });
  return pushTo(list, Object.assign({}, data, { title: "[KIỂM THỬ] " + (data.title || ""), tag: "kt-" + (data.tag || Date.now()) }), maint.testSubs);
}

// Chống dò mã: tối đa 8 lần sai / 15 phút / IP
const fails = new Map();
function tooMany(ip) { const f = fails.get(ip); return f && f.n >= 8 && f.until > Date.now(); }
function addFail(ip) { const f = fails.get(ip); if (!f || f.until < Date.now()) fails.set(ip, { n: 1, until: Date.now() + 15 * 60000 }); else f.n++; }

// ============================================================================
// THÔNG BÁO ĐẨY – dò tín hiệu mới trên nến đã đóng, gửi về máy khách đã bật
// ============================================================================
let pushSubs = readJson(PUSH_FILE, {});                  // endpoint -> {sub, code, created}
const savePush = () => saveJson(PUSH_FILE, pushSubs);
const fmtP = v => CONFIG.roundEntry !== false ? String(Math.round(v)) : (Math.round(v * 1000) / 1000).toFixed(3);   // giá làm tròn như chart
const hmVN = t => { const d = new Date(t + 7 * 3600000); return String(d.getUTCHours()).padStart(2, "0") + ":" + String(d.getUTCMinutes()).padStart(2, "0"); };
const f2 = v => { const r = Math.round(v * 100) / 100; return Number.isInteger(r) ? String(r) : String(r); };
let seen = null, watchTimer = null;
const PUSH_WINDOW = (parseInt(process.env.KCV_PUSH_WINDOW_MIN || "5", 10) || 5) * 60000;

// ghi chú khi lệnh mới ngược chiều lệnh đang chạy
function hedgeTxt(s, sigs) {
  if (s.isAdd) return ""; const h = oppositeOf(s, sigs); if (!h) return "";
  return h.ok ? " · Ngược chiều lệnh " + (h.other.dir === 1 ? "MUA" : "BÁN") + " đang chạy – vẫn vào được cả 2 (chốt lãi lệnh này nằm trong vùng chưa cắt lỗ lệnh kia)"
              : " · Ngược chiều lệnh " + (h.other.dir === 1 ? "MUA" : "BÁN") + " đang chạy – cân nhắc chỉ vào 1 lệnh";
}
// khung sinh LỆNH nội bộ + Telegram + tổng kết (chọn ở trang quản trị, lưu trong maint.json)
const orderTf = () => [1, 3, 15, 60].includes(maint.orderTf) ? maint.orderTf : 1;
let seedOrders = false;                                   // vừa đổi khung: ghi nhận lệnh cũ của khung mới, không gửi bù
function eventsOf(res, tf) {
  tf = tf || 1;
  const ev = [], tn = " " + ({ 1: "M1", 3: "M3", 15: "M15", 60: "H1" })[tf];
  const sym = (state.symbol && /XAU/i.test(state.symbol) ? "XAUUSD" : (state.symbol || "XAUUSD")) + tn;
  for (const s of res.sigs) {
    // lệnh ngoài phiên 07:00–21:00 chỉ gửi cho thiết bị chọn chế độ "Cả 24 giờ"
    const side = (s.isAdd ? "＋ " : "") + (s.dir === 1 ? "MUA" : "BÁN") + (s.isAdd ? " GỒNG" : "");
    const arrow = s.dir === 1 ? "▲" : "▼";
    if (CONFIG.notifyEntries !== false)
      ev.push({ key: "E" + tf + ":" + s.tSig + s.dir + (s.isAdd ? "g" : ""), ord: true, aud: "staff", t: s.tSig, sig: s.inWin ? s : null, inWin: s.inWin, data: {
        title: (s.isAdd ? "" : arrow + " ") + side + " " + sym + " · " + hmVN(s.tSig) + (s.inWin ? "" : " · ngoài phiên"),
        body: "Vào " + fmtP(s.entry) + " · Chốt lãi " + fmtP(s.tp0 !== undefined ? s.tp0 : s.tp) + " · Cắt lỗ " + fmtP(s.sl) + (s.inWin ? "" : " · Lệnh ngoài phiên 07:00–21:00, không tính vào tổng kết") + hedgeTxt(s, res.sigs), tag: "e" + s.tSig } });
    if (CONFIG.notifyExits !== false && s.res !== null && s.res !== "?")
      ev.push({ key: "X" + tf + ":" + s.tSig + s.dir + (s.isAdd ? "g" : ""), ord: true, aud: "staff", t: s.exitT, inWin: s.inWin, data: {
        title: (s.pnl > 0 ? "✅ ĂN +" + f2(s.pnl) + " giá" : s.pnl < 0 ? "❌ LỖ −" + f2(-s.pnl) + " giá" : "➖ HÒA VỐN") + " · " + side + " " + sym + (s.inWin ? "" : " · ngoài phiên"),
        body: "Vào " + fmtP(s.entry) + " · đóng lúc " + hmVN(s.exitT), tag: "x" + s.tSig } });
  }
  return ev;
}
// ---------- nhật ký tín hiệu vùng MUA / BÁN đã báo (khách xem lại trên web) ----------
const SIGNALS_FILE = path.join(ROOT, "signals.json");
let signalLog = readJson(SIGNALS_FILE, []); if (!Array.isArray(signalLog)) signalLog = [];
function logSignal(s) {
  signalLog.push(s); signalLog = signalLog.filter(x => Date.now() - x.t < 3 * DAYMS).slice(-500);
  saveJson(SIGNALS_FILE, signalLog);
}
// ---------- thông báo "giá đang trong vùng MUA / BÁN" theo từng khung (khách chọn khung khi bật thông báo) ----------
const NOTIFY_TFS = [1, 3, 15, 60], TF_NAME = { 1: "M1", 3: "M3", 15: "M15", 60: "H1" };
const resCache = {};
function runTf(tf, now) {
  const src = (tf === 1 ? state.bars : aggBars(tf)).slice(-SEND_BARS), ms = tf * 60000, cb = [];
  let forming = null;
  for (const b of src) { const x = { t: b[0] * 1000, o: b[1], h: b[2], l: b[3], c: b[4] }; if (x.t + ms <= now) cb.push(x); else forming = x; }
  if (cb.length < 60) return null;
  const key = cb[cb.length - 1].t + ":" + cb.length + ":" + cb[cb.length - 1].c;
  if (!resCache[tf] || resCache[tf].key !== key) resCache[tf] = { key, res: kcvRun(cb, tf === 1 ? KCV_OPT : Object.assign({}, KCV_OPT, { barMs: ms })) };
  return { res: resCache[tf].res, forming };
}
// tín hiệu mẫu cho tin thử: quanh giá hiện tại, lời / lỗ theo đúng công thức trong config
function demoSig(dir) {
  const px = state.bars.length ? state.bars[state.bars.length - 1][4] : 4140, e = Math.round(px - dir * 3);
  const ob = CONFIG.slMode === "ob", risk = ob ? 2 + 2 + (CONFIG.slBuffer || 2) : (CONFIG.slDist || 20);
  const sl = e - dir * risk, tp = e + dir * (ob ? (CONFIG.rr || 2) * risk : (CONFIG.tpDist || 8));
  return { id: -1, tSig: Date.now(), dir, entry: e, sl, tp, tp0: tp, isAdd: false };
}
// thông báo mẫu đúng dạng khách nhận (vùng MUA + vùng BÁN)
async function sampleZonePush(list, store, prefix) {
  if (!list.length) return { ok: 0, total: 0 };
  let ok = 0;
  for (const d of [1, -1]) {
    const s = demoSig(d), z = { dir: d, entry: s.entry, bot: d === 1 ? s.entry - 4 : s.entry + 2, top: d === 1 ? s.entry - 2 : s.entry + 4, t0: Date.now() + d };
    const e = zoneEvent(z, 1, Date.now(), true);
    const r = await pushTo(list, Object.assign({}, e.data, { title: (prefix || "[THỬ] ") + e.data.title, tag: "ztest" + d }), store || undefined); ok = Math.max(ok, r.ok);
  }
  return { ok, total: list.length };
}
// mức cắt lỗ / chốt lãi nếu vào theo vùng (cùng công thức engine)
function zoneLevels(z) {
  const d = z.dir, e = z.entry;
  if (CONFIG.slMode === "ob") { const raw = d === 1 ? z.bot - (CONFIG.slBuffer || 2) : z.top + (CONFIG.slBuffer || 2), sl = d === 1 ? Math.floor(raw) : Math.ceil(raw); return { sl, tp: Math.round(e + d * (CONFIG.rr || 2) * Math.abs(e - sl)) }; }
  return { sl: Math.round(e - d * (CONFIG.slDist || 20)), tp: Math.round(e + d * (CONFIG.tpDist || 8)) };
}
function zoneEvent(z, tf, t, inWin) {
  const sym = state.symbol && /XAU/i.test(state.symbol) ? "XAUUSD" : (state.symbol || "XAUUSD"), buy = z.dir === 1, e = Math.round(z.entry), far = Math.round(buy ? z.bot : z.top), lv = zoneLevels(z);
  return { key: "Z" + tf + ":" + z.t0 + ":" + z.dir, aud: "all", tf, t, inWin, data: {
    title: (buy ? "🟢 GIÁ ĐANG TRONG VÙNG MUA" : "🔴 GIÁ ĐANG TRONG VÙNG BÁN") + " · " + sym + " " + TF_NAME[tf] + (inWin ? "" : " · ngoài phiên"),
    body: "Khung " + TF_NAME[tf] + " · " + (buy ? "MUA từ " + e + " trở xuống, tới " + far : "BÁN từ " + e + " trở lên, tới " + far) + " · Cắt lỗ " + lv.sl + " · Chốt lãi " + lv.tp + " · Bấm để xem cách vào lệnh",
    tag: "z" + tf + "-" + z.t0,
    url: "/?sig=" + [tf, z.dir, e, far, lv.sl, lv.tp, t].join("_") }, sig: { tf, dir: z.dir, e, far, sl: lv.sl, tp: lv.tp, t, inWin: !!inWin } };   // bấm thông báo → trang chart mở thẻ hướng dẫn vào lệnh
}
function watchSignals() {
  const now = Date.now(), ev = [];
  let m1, ord, otf = orderTf();
  try {
    m1 = runTf(1, now); if (!m1) return;
    ord = otf === 1 ? m1 : runTf(otf, now); if (!ord) ord = m1, otf = 1;
    ev.push(...eventsOf(ord.res, otf));                            // lệnh khớp / đóng (nội bộ + Telegram) – theo khung chọn ở trang quản trị
    if (CONFIG.notifyZones !== false) for (const tf of NOTIFY_TFS) {
      const r = tf === 1 ? m1 : runTf(tf, now); if (!r) continue;
      for (const z of r.res.zones) if (z.touch !== null && z.tTouch) ev.push(zoneEvent(z, tf, z.tTouch, z.inWin));
      // nến đang chạy chạm điểm vào của vùng còn hiệu lực → báo ngay, không chờ đóng nến (khung 15m / 1h)
      const f = r.forming; if (f) for (const z of r.res.pending || []) if (z.touch === null && (z.dir === 1 ? f.l <= z.entry && f.h >= z.bot : f.h >= z.entry && f.l <= z.top)) ev.push(zoneEvent(z, tf, now, isOpenNow()));
    }
  } catch (e) { console.error("Lỗi dò tín hiệu:", e.message); return; }
  if (!seen) { seen = new Set(ev.map(e => e.key)); seedOrders = false; return; }     // lần đầu: chỉ ghi nhận, không gửi lại tín hiệu cũ
  if (seedOrders) { for (const e of ev) if (e.ord) seen.add(e.key); seedOrders = false; }   // vừa đổi khung lệnh: không gửi bù lệnh cũ của khung mới
  for (const e of ev) {
    if (seen.has(e.key)) continue;
    seen.add(e.key);
    if (now - e.t > PUSH_WINDOW) continue;                     // chỉ báo sự kiện vừa xảy ra (5 phút)
    if (maint.on) { pushTest(e.data).catch(() => {}); continue; }
    if (e.sig) logSignal(e.sig);                                // lưu lại để khách mở web xem lại "Tín hiệu gần đây"   // bảo trì: không gửi khách/nhân viên/Telegram, không ghi tin nội bộ; tắt bảo trì cũng không gửi bù
    broadcast(e.data, e.sig ? internalFor(e.sig, ord.res.sigs, otf) : null, e.inWin, e.aud, e.tf);
  }
  if (seen.size > 8000) seen = new Set([...seen].slice(-3000));
}
function scheduleWatch() { if (!watchTimer) watchTimer = setTimeout(() => { watchTimer = null; watchSignals(); }, 1500); }
setInterval(watchSignals, 20000);

async function pushTo(list, data, store) {
  const payload = Object.assign({ url: "/", icon: "/icon-192.png" }, data);
  let ok = 0, gone = 0;
  for (let i = 0; i < list.length; i += 20) {
    await Promise.all(list.slice(i, i + 20).map(async ([ep, rec]) => {
      const st = await sendPush(rec.sub, payload, VAPID, PUSH_SUBJECT);
      if (st >= 200 && st < 300) ok++;
      else if (st === 404 || st === 410) { delete (store || pushSubs)[ep]; gone++; }
    }));
  }
  if (gone) store ? saveMaint() : savePush();
  return { ok, total: list.length };
}
// ---------- báo nhân viên nội bộ khi có khách tự đăng ký dùng thử ----------
const fmtPhone = p => String(p || "").replace(/^(\d{4})(\d{3})(\d+)$/, "$1 $2 $3");
const contactOf = c => c.phone ? "Zalo " + fmtPhone(c.phone) : (c.contact || "chưa có SĐT");
const vnTime = t => { const d = new Date(t + 7 * 3600000), z = x => (x < 10 ? "0" : "") + x; return z(d.getUTCHours()) + ":" + z(d.getUTCMinutes()) + " " + z(d.getUTCDate()) + "/" + z(d.getUTCMonth() + 1); };
function notifyLead(c) {
  const staff = Object.entries(pushSubs).filter(([, r]) => { const k = findCode(r.code); return k && k.staff && codeValid(k); });
  pushTo(staff, { title: "🎁 Khách dùng thử mới: " + c.name, body: "Zalo " + fmtPhone(c.phone) + (c.ref ? " · nguồn " + c.ref : "") + " · đăng ký lúc " + vnTime(c.created) + (c.suspect ? " · ⚠️ nghi dùng thử lại" : "") + ". Bấm để nhận chăm sóc.",
    tag: "lead-" + c.code, url: "/noi-bo#khach-moi" }).catch(() => {});
  sendTelegram(LEAD_TG, "🎁 KHÁCH DÙNG THỬ MỚI\nTên: " + c.name + "\nZalo: " + fmtPhone(c.phone) + " (https://zalo.me/" + c.phone + ")" + (c.ref ? "\nNguồn: " + c.ref.toUpperCase() : "") + "\nĐăng ký: " + vnTime(c.created) +
    (c.suspect ? "\n⚠️ NGHI DÙNG THỬ LẠI: " + c.suspect.map(x => x.why + (x.name ? " – trùng " + x.name + " (" + fmtPhone(x.phone) + ")" : "")).join("; ") : "") +
    "\nMã: " + c.code + "\n👉 Nhận chăm sóc tại trang nội bộ: " + (CONFIG.siteUrl ? CONFIG.siteUrl.replace(/\/$/, "") : "") + "/noi-bo#khach-moi");
}
function leadView(c) {
  return { code: c.code, name: c.name, phone: c.phone || "", created: c.created, firstUse: c.firstUse || null, trial: !!c.trial, wasTrial: !!c.wasTrial,
    valid: codeValid(c), active: c.active, trialLeft: c.trial ? trialLeft(c) : null, expires: c.expires || null,
    careBy: c.careBy || null, careByCode: c.careByCode || null, careAt: c.careAt || null,
    closedAt: c.closedAt || null, closedBy: c.closedBy || null, closedByCode: c.closedByCode || null, closedDays: c.closedDays || null, acct: c.acct || null,
    lostAt: c.lostAt || null, lostReason: c.lostReason || null, lostNote: c.lostNote || "", lostBy: c.lostBy || null, followAt: c.followAt || null,
    outcomes: (c.outcomes || []).slice(-10), suspect: c.suspect || null, ref: c.ref || null, removed: c.removed || null, removedBy: c.removedBy || null, maxDevices: c.maxDevices || 2, trialCode: c.trialCode || null };
}
// ---------- khách KHÔNG ĐỒNG Ý / HẸN GỌI LẠI ----------
const LOST_REASONS = ["Chưa có vốn", "Chưa có nhu cầu / chỉ xem thử", "Đã giao dịch nơi khác", "Không liên lạc được", "Hẹn suy nghĩ thêm", "Lý do khác"];
function setLost(c, j, who) {
  const reason = String(j.reason || "");
  if (!LOST_REASONS.includes(reason)) return { error: "Chọn lý do khách không đồng ý" };
  const note = String(j.note || "").trim().slice(0, 300);
  if (reason === "Lý do khác" && !note) return { error: "Ghi rõ lý do vào ô ghi chú" };
  let followAt = null;
  if (j.followAt) {
    followAt = Number(j.followAt);
    if (!isFinite(followAt) || followAt < Date.now() - 60000 || followAt > Date.now() + 120 * DAYMS) return { error: "Ngày hẹn gọi lại phải trong vòng 120 ngày tới" };
  }
  const now = Date.now(), again = !!c.lostAt;
  c.lostAt = now; c.lostReason = reason; c.lostNote = note; c.lostBy = who.name || who.code; c.lostByCode = who.code;
  c.followAt = followAt; c.followNotified = false;
  const act = (followAt ? "Hẹn gọi lại " + vnTime(followAt) : "Không đồng ý") + " · " + reason;
  c.outcomes = (c.outcomes || []).concat({ t: now, by: c.lostBy, act, note }).slice(-20);
  c.hist = (c.hist || []).concat({ t: now, by: c.lostBy, byCode: who.code, act: (again ? "Cập nhật: " : "") + act }).slice(-20);
  return { ok: true };
}
function reopenLead(c, who) {
  const now = Date.now(), name = who.name || who.code;
  c.lostAt = c.lostReason = c.lostBy = c.lostByCode = c.followAt = null; c.lostNote = ""; c.followNotified = false;
  c.outcomes = (c.outcomes || []).concat({ t: now, by: name, act: "Chăm sóc lại" }).slice(-20);
  c.hist = (c.hist || []).concat({ t: now, by: name, byCode: who.code, act: "Chăm sóc lại" }).slice(-20);
}
// Nhắc nhân viên khi đến hẹn gọi lại (kiểm tra mỗi phút)
function checkFollowUps() {
  const now = Date.now(); let changed = false;
  for (const c of codes.list.concat(mleads.list)) {
    if (!c.followAt || c.followNotified || c.closedAt || c.removed || c.followAt > now) continue;
    c.followNotified = true; changed = true;
    const staff = Object.entries(pushSubs).filter(([, r]) => c.careByCode && normCode(r.code) === normCode(c.careByCode));
    pushTo(staff, { title: "📅 Đến hẹn gọi lại: " + c.name, body: contactOf(c) + " · " + (c.lostReason || "") + (c.lostNote ? " – " + c.lostNote : ""), tag: "follow-" + c.code, url: c.manual ? "/noi-bo#khach-tu-them" : "/noi-bo#khach-moi" }).catch(() => {});
    sendTelegram(LEAD_TG, "📅 ĐẾN HẸN GỌI LẠI\nKhách: " + c.name + " · " + contactOf(c) + "\nPhụ trách: " + (c.careBy || "—") + "\nLý do lần trước: " + (c.lostReason || "—") + (c.lostNote ? " – " + c.lostNote : ""));
  }
  if (changed) { saveAuthNow(); saveMleads(); }
}
setInterval(checkFollowUps, 60000); setTimeout(checkFollowUps, 5000);
// ============================================================================
// NHẮC HẾT HẠN MÃ
// 1) Khách (đã bật thông báo): còn 3 ngày, còn 1 ngày, khi hết hạn – gửi trong 09:00–21:00 giờ VN; dùng thử: còn 30 phút
// 2) Mỗi sáng 09:00: tin tổng hợp mã sắp hết hạn (7 ngày) → nhóm Telegram khách + điện thoại nhân viên đã cấp mã
// ============================================================================
const REMIND_DAYS = [3, 1];
const vnHour = t => new Date(t + VN).getUTCHours();
const fmtDate = t => { const d = new Date(t + VN), z = x => (x < 10 ? "0" : "") + x; return z(d.getUTCDate()) + "/" + z(d.getUTCMonth() + 1) + "/" + d.getUTCFullYear(); };
const leftTxt = ms => ms >= DAYMS ? Math.ceil(ms / DAYMS) + " ngày" : ms >= 3600000 ? Math.floor(ms / 3600000) + " giờ" : Math.max(1, Math.round(ms / 60000)) + " phút";
const renewable = c => c.active && !c.staff && !c.trial && c.expires;
const subsOf = code => Object.entries(pushSubs).filter(([, r]) => normCode(r.code) === normCode(code));
const zaloUrl = () => CONFIG.accountUrl || "https://zalo.me/0886558169";
function checkExpiry() {
  const now = Date.now(), day = vnHour(now) >= 9 && vnHour(now) < 21; let changed = false;
  for (const c of (maint.on ? [] : codes.list)) {                // bảo trì: tạm dừng nhắc hạn cho khách, mở lại sẽ nhắc tiếp
    // dùng thử: còn 30 phút (gửi bất kỳ giờ nào, vì chỉ có 5 tiếng)
    if (c.trial && c.active && c.firstUse) {
      const left = trialLeft(c);
      if (left > 0 && left <= 30 * 60000 && !(c.remind && c.remind.t30)) {
        c.remind = Object.assign({}, c.remind, { t30: now }); changed = true;
        pushTo(subsOf(c.code), { title: "⏳ Còn " + leftTxt(left) + " dùng thử", body: "Thời gian dùng thử sắp hết. Nhắn Zalo để được cấp mã chính thức và tiếp tục nhận tín hiệu.", tag: "exp-" + c.code, url: zaloUrl() }).catch(() => {});
      }
      continue;
    }
    if (!renewable(c) || !day) continue;
    const left = c.expires - now, r = c.remind || {};
    let key = null, title = "", body = "";
    if (left <= 0) { if (!r.exp && -left < 2 * DAYMS) { key = "exp"; title = "⛔ Mã Kim Chỉ Vàng đã hết hạn"; body = "Mã của bạn hết hạn lúc " + vnTime(c.expires) + ". Nhắn Zalo để gia hạn và tiếp tục nhận tín hiệu."; } }
    else for (const d of REMIND_DAYS.slice().sort((a, b) => a - b)) {
      if (left <= d * DAYMS && !r["d" + d]) { key = "d" + d; title = "⏰ Mã còn " + leftTxt(left) + " sử dụng"; body = "Mã dùng đến " + vnTime(c.expires) + ". Nhắn Zalo để gia hạn sớm, không bị gián đoạn tín hiệu."; break; }
    }
    if (!key) continue;
    // đánh dấu cả các mốc lớn hơn để không gửi dồn (vd mã tạo khi chỉ còn 1 ngày)
    const mark = { [key]: now }; for (const d of REMIND_DAYS) if (key === "exp" || d >= Number(key.slice(1))) mark["d" + d] = r["d" + d] || now;
    c.remind = Object.assign({}, r, mark); changed = true;
    pushTo(subsOf(c.code), { title, body, tag: "exp-" + c.code, url: zaloUrl() }).catch(() => {});
  }
  // tin tổng hợp mỗi sáng
  if (vnHour(now) >= 9 && codes.digestDay !== vnDay(now)) { codes.digestDay = vnDay(now); changed = true; expiryDigest(now); }
  if (changed) saveAuthNow();
}
function expiringList(now, days = 7) {
  return codes.list.filter(c => renewable(c) && c.expires - now <= days * DAYMS && now - c.expires < 3 * DAYMS).sort((a, b) => a.expires - b.expires);
}
function expiryDigest(now) {
  const L = expiringList(now); if (!L.length) return;
  const line = c => "• " + c.name + (c.phone ? " · Zalo " + fmtPhone(c.phone) : "") + " · " + (c.expires <= now ? "ĐÃ HẾT HẠN " + fmtDate(c.expires) : "còn " + leftTxt(c.expires - now) + " (hết " + fmtDate(c.expires) + ")") + " · cấp bởi " + byLabel(c);
  sendTelegram(LEAD_TG, "⏰ MÃ SẮP HẾT HẠN – " + fmtDate(now) + "\n" + L.length + " khách cần nhắc gia hạn:\n" + L.slice(0, 40).map(line).join("\n") + (L.length > 40 ? "\n… và " + (L.length - 40) + " khách khác" : "") + "\n👉 Xem tại trang quản trị / trang nội bộ (Cấp mã khách → Sắp hết hạn)");
  const by = new Map(); for (const c of L) if (c.byCode) { const k = normCode(c.byCode); by.set(k, (by.get(k) || []).concat(c)); }
  for (const [k, list] of by) {
    const st = findCode(k); if (!st || !st.staff || !codeValid(st)) continue;
    const gone = list.filter(c => c.expires <= now).length;
    pushTo(subsOf(st.code), { title: "⏰ " + list.length + " khách của bạn sắp hết hạn", body: list.slice(0, 4).map(c => c.name + " (" + (c.expires <= now ? "đã hết" : "còn " + leftTxt(c.expires - now)) + ")").join(", ") + (list.length > 4 ? "…" : "") + (gone ? " · gọi gia hạn ngay!" : " · nhắc khách gia hạn sớm."), tag: "digest-" + k, url: "/noi-bo#cap-ma" }).catch(() => {});
  }
}
setInterval(checkExpiry, 60000); setTimeout(checkExpiry, 8000);
// bổ sung dữ liệu cũ: khách dùng thử đã được nhân viên chốt trước bản này → ghi nhân viên chốt là người cấp mã
setTimeout(() => { let n = 0; for (const c of codes.list) if (c.self && !c.trial && !c.byCode && c.closedByCode) { const st = findCode(c.closedByCode); if (st && st.staff) { c.byCode = st.code; c.byName = c.closedBy || st.name; c.issuedAt = c.closedAt || Date.now(); if (/^TRY-/i.test(c.code)) promoteCode(c); n++; } }
  if (n) { saveAuthNow(); console.log("Đã ghi nhận", n, "khách dùng thử đã chốt vào danh sách mã của nhân viên"); } }, 0);   // chạy sau khi nạp xong mọi dữ liệu
// ============================================================================
// KHÁCH NHÂN VIÊN TỰ THÊM (nguồn ngoài: Facebook, Zalo, TikTok, giới thiệu…)
// Mỗi khách thuộc về nhân viên đã thêm (careByCode); dùng chung logic chốt / không đồng ý / hẹn gọi lại
// ============================================================================
const SOURCES = ["Facebook", "Zalo", "TikTok", "YouTube", "Người quen giới thiệu", "Sự kiện / Hội thảo", "Khác"];
let mleads = readJson(MLEADS_FILE, { list: [] });
const saveMleads = () => saveJson(MLEADS_FILE, mleads);
const findLead = id => mleads.list.find(x => x.code === id);
function newLeadId() { let c; do { c = "L" + crypto.randomBytes(5).toString("hex").toUpperCase(); } while (findLead(c)); return c; }
function mleadView(l) {
  const k = l.codeRef ? findCode(l.codeRef) : null;
  return Object.assign(leadView(l), { manual: true, source: l.source, sourceNote: l.sourceNote || "", contact: l.contact || "", account: l.account || "", note: l.note || "",
    owner: l.careBy, ownerCode: l.careByCode, editedAt: l.editedAt || null,
    codeInfo: k ? { code: k.code, name: k.name, trial: !!k.trial, expires: k.expires || null, maxDevices: k.maxDevices, valid: codeValid(k), trialLeft: k.trial ? trialLeft(k) : null, firstUse: k.firstUse || null, active: k.active } : (l.codeRef ? { code: l.codeRef, deleted: true } : null) });
}
function leadFields(l, j) {
  const name = String(j.name || "").trim().slice(0, 80);
  if (name.length < 2) return { error: "Nhập tên khách" };
  // SĐT / Zalo và link liên hệ đều có thể để trống
  const rawPhone = String(j.phone || "").trim();
  let phone = rawPhone ? (normPhone(rawPhone) || rawPhone.replace(/[^\d+]/g, "")) : "";
  if (rawPhone && !/^\+?\d{8,15}$/.test(phone)) return { error: "Số điện thoại / Zalo chưa đúng (chỉ gồm số, 8–15 chữ số)" };
  const contact = String(j.contact || "").trim().slice(0, 200);
  const account = String(j.account || "").trim().slice(0, 120);
  const source = SOURCES.includes(j.source) ? j.source : null;
  if (!source) return { error: "Chọn nguồn khách" };
  return { name, phone, contact, account, source, sourceNote: String(j.sourceNote || "").trim().slice(0, 120), note: String(j.note || "").trim().slice(0, 500) };
}
// Chặn trùng theo SỐ TÀI KHOẢN / EMAIL (không phân biệt hoa thường, bỏ khoảng trắng)
const acctKey = v => String(v || "").toLowerCase().replace(/\s+/g, "");
function dupOf(account, self) {
  const k = acctKey(account); if (!k) return null;
  for (const x of mleads.list) {
    if (x === self) continue;
    if (acctKey(x.account) === k || (x.acct && acctKey(x.acct.account) === k))
      return "Số tài khoản / email này đã có trong danh sách khách của " + (x.careBy || "nhân viên khác") + " (khách " + x.name + ", thêm ngày " + vnTime(x.created) + ")";
  }
  for (const c of codes.list) {
    if (c === self || (self && self.codeRef && c.code === self.codeRef)) continue;
    if (c.acct && acctKey(c.acct.account) === k)
      return "Số tài khoản / email này đã được ghi cho khách " + c.name + " (mã " + c.code + (c.careBy || c.closedBy ? ", " + (c.closedBy || c.careBy) + " phụ trách" : "") + ")";
  }
  return null;
}

function notifyClose(c) {
  const staff = Object.entries(pushSubs).filter(([, r]) => { const k = findCode(r.code); return k && k.staff && codeValid(k); });
  const t = "✅ " + c.closedBy + " vừa chốt khách " + c.name, b = "Gói " + c.closedDays + " ngày · " + contactOf(c);
  pushTo(staff, { title: t, body: b, tag: "close-" + c.code, url: "/noi-bo#khach-moi" }).catch(() => {});
  sendTelegram(LEAD_TG, t + "\n" + b);
}
// Thông tin tài khoản sau khi chốt: số tài khoản live hoặc email + vốn nạp (USD); giữ lịch sử sửa
function setAcct(c, j, who) {
  const account = String(j.account || "").trim().slice(0, 120);
  const raw = String(j.deposit === undefined || j.deposit === null ? "" : j.deposit).replace(/[\s.,](?=\d{3}(\D|$))/g, "").replace(",", ".").trim();
  let deposit = null;
  if (raw !== "") { deposit = Number(raw); if (!isFinite(deposit) || deposit < 0 || deposit > 1e9) return { error: "Vốn nạp chưa đúng (nhập số USD, ví dụ 5000)" }; deposit = Math.round(deposit * 100) / 100; }
  if (!account && deposit === null) return { error: "Nhập số tài khoản / email hoặc vốn nạp" };
  const old = c.acct || null, now = Date.now();
  c.acct = { account, deposit, updatedAt: now, updatedBy: who, createdAt: old ? old.createdAt || now : now, createdBy: old ? old.createdBy || who : who,
    log: ((old && old.log) || []).concat({ t: now, by: who, account, deposit }).slice(-20) };
  c.hist = (c.hist || []).concat({ t: now, by: who, act: old ? "Sửa TK / vốn nạp" : "Thêm TK / vốn nạp" }).slice(-20);
  return { ok: true };
}

// ---------- TỔNG KẾT TÍN HIỆU phiên hiện tại (tính tới thời điểm bấm) ----------
function sessionSummary() {
  const now = Date.now(), otf = orderTf(), r = runTf(otf, now);
  if (!r) return { empty: true };
  const res = r.res;
  const ses = res.session.start, last = state.bars.length ? state.bars[state.bars.length - 1][4] : NaN;
  const list = res.sigs.filter(x => x.inWin && x.tOpen >= ses);
  const rows = list.map(x => ({
    t: x.tSig, dir: x.dir, add: !!x.isAdd, entry: x.entry, sl: x.sl, tp: x.tp0 !== undefined ? x.tp0 : x.tp, tpNow: x.tp,
    res: x.res, pnl: x.res === null ? null : x.pnl, exitT: x.exitT || null,
    floating: x.res === null && isFinite(last) ? Math.round((last - x.entry) * x.dir * 100) / 100 : null
  }));
  const done = rows.filter(r => r.res !== null && r.res !== "?");
  const tot = { n: rows.length, closed: done.length, running: rows.filter(r => r.res === null).length,
    win: done.filter(r => r.pnl > 0).length, loss: done.filter(r => r.pnl < 0).length, be: done.filter(r => r.pnl === 0).length,
    net: Math.round(done.reduce((a, r) => a + r.pnl, 0) * 100) / 100 };
  tot.rate = tot.closed ? Math.round((tot.win + tot.be) / tot.closed * 100) : null;   // hòa vốn = không thua → tính thắng
  return { now, session: ses, open: res.session.inWin, last, rows, tot, tf: otf, tfName: ({ 1: "M1", 3: "M3", 15: "M15", 60: "H1" })[otf],
    capitals: CONFIG.capitals || [20000, 5000, 3000, 1000], lotPer1000: CONFIG.lotPer1000 || 0.04, usdVnd: CONFIG.usdVnd || 26000 };
}

// Khách nhận mẫu ngắn; nhân viên (mã nội bộ) nhận mẫu chi tiết khi có lệnh vào
const DEFAULT_MODE = CONFIG.notifySessionOnly === false ? "all" : "session";
const modeOf = r => r.mode === "all" || r.mode === "session" ? r.mode : DEFAULT_MODE;
const tfsOf = r => Array.isArray(r.tfs) && r.tfs.length ? r.tfs : [1];          // khung nhận thông báo (mặc định 1 phút)
const cleanTfs = v => Array.isArray(v) ? [...new Set(v.map(Number).filter(x => [1, 3, 15, 60].includes(x)))].sort((a, b) => a - b) : [];
// aud: "all" = khách + nhân viên (thông báo vùng MUA/BÁN) · "staff" = chỉ nhân viên nội bộ (lệnh vào, lệnh đóng, Telegram)
function broadcast(data, internal, inWin, aud, tf) {
  let list = Object.entries(pushSubs).filter(([ep, r]) => { const c = findCode(r.code); if (!codeValid(c)) { if (!c || !c.active || (c.expires && Date.now() - c.expires > 30 * DAYMS)) delete pushSubs[ep]; return false; } return true; });   // mã vừa hết hạn: giữ đăng ký để nhắc gia hạn, gia hạn xong nhận tin lại ngay
  savePush();
  if (inWin === false) list = list.filter(([, r]) => modeOf(r) === "all");   // lệnh ngoài phiên: chỉ thiết bị chọn "Cả 24 giờ"
  if (tf) list = list.filter(([, r]) => tfsOf(r).includes(tf));                // thông báo vùng: chỉ thiết bị chọn khung này
  const isStaff = ([, r]) => { const c = findCode(r.code); return !!(c && c.staff); };
  if (maint.staffOnly) list = list.filter(isStaff);                              // công tắc "Chỉ nội bộ nhận thông báo": khách không nhận tín hiệu
  if (aud === "staff") {
    const st = list.filter(isStaff);
    if (!internal) { if (st.length) pushTo(st, data).then(r => console.log("Đã gửi thông báo nội bộ:", data.title, "→", r.ok + "/" + r.total, "thiết bị")); return; }
    list = st;
  }
  const cust = internal ? list.filter(x => !isStaff(x)) : list, staff = internal ? list.filter(isStaff) : [];
  if (cust.length) pushTo(cust, data).then(r => console.log("Đã gửi thông báo khách:", data.title, "→", r.ok + "/" + r.total, "thiết bị"));
  if (internal) {
    if (staff.length) pushTo(staff, { title: internal.push.title, body: internal.push.body, tag: "i" + internal.id, url: "/noi-bo#" + internal.id })
      .then(r => console.log("Đã gửi thông báo nội bộ:", internal.push.title, "→", r.ok + "/" + r.total, "thiết bị"));
    sendTelegram(internal.text);
  }
}

// ---------- mẫu tin nội bộ: lưu 100 tin gần nhất để nhân viên mở lại / sao chép ----------
let internalLog = readJson(INTERNAL_FILE, []);
function internalFor(sig, sigs, tf) {
  tf = tf || 1;
  const m = buildInternal(sig, sigs, Object.assign({}, CONFIG, { tfLabel: ({ 1: "M1", 3: "M3", 15: "M15", 60: "H1" })[tf] }));
  const rec = { id: (tf === 1 ? "" : tf + "m") + String(sig.tSig) + (sig.dir === 1 ? "b" : "s") + (sig.isAdd ? "g" : ""), t: sig.tSig, dir: sig.dir, add: !!sig.isAdd, entry: sig.entry, text: m.text, push: m.push };
  internalLog = internalLog.filter(x => x.id !== rec.id); internalLog.push(rec); internalLog = internalLog.slice(-100);
  saveJson(INTERNAL_FILE, internalLog);
  return rec;
}
// sendTelegram(text) → nhóm lệnh; sendTelegram({token, chat}, text) → nhóm chỉ định (null = nhóm lệnh)
async function sendTelegram(dest, text) {
  if (text === undefined) { text = dest; dest = null; }
  const token = dest ? dest.token : TG_TOKEN, chat = dest ? dest.chat : TG_CHAT;
  if (!token || !chat) return false;
  try {
    const r = await fetch("https://api.telegram.org/bot" + token + "/sendMessage", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chat, text, disable_web_page_preview: true }) });
    if (!r.ok) { console.error("Telegram lỗi:", r.status, (await r.text()).slice(0, 200)); return false; }
    return true;
  } catch (e) { console.error("Telegram lỗi:", e.message); return false; }
}

// ============================================================================
// SAO LƯU HẰNG NGÀY + DỌN DẸP + THEO DÕI DUNG LƯỢNG
// ============================================================================
const BK_STATE_FILE = path.join(BACKUP_DIR, "trang-thai.json");
let bkState = readJson(BK_STATE_FILE, {});
const saveBkState = () => { try { fs.mkdirSync(BACKUP_DIR, { recursive: true }); fs.writeFileSync(BK_STATE_FILE, JSON.stringify(bkState)); } catch (e) {} };
function writeJsonSync(f, obj) { const tmp = f + ".tmp"; fs.writeFileSync(tmp, JSON.stringify(obj)); fs.renameSync(tmp, f); }
// ghi ngay mọi dữ liệu trong bộ nhớ ra file (trước khi sao lưu)
function flushAll() {
  writeJsonSync(CODES_FILE, codes); writeJsonSync(SESS_FILE, sessions); writeJsonSync(PUSH_FILE, pushSubs);
  writeJsonSync(MLEADS_FILE, mleads); writeJsonSync(INTERNAL_FILE, internalLog); writeJsonSync(DATA, state); writeJsonSync(MAINT_FILE, maint); writeJsonSync(SIGNALS_FILE, signalLog); authDirty = false;
}
async function runBackup(tag, send) {
  flushAll();
  const b = BK.createBackup(ROOT, BACKUP_DIR, tag);
  bkState.lastAt = Date.now(); bkState.lastName = b.name; bkState.lastSize = b.size;
  console.log("Đã sao lưu:", b.name, Math.round(b.size / 1024) + " KB");
  if (send && TG_BK_TOKEN && TG_BK_CHAT) {
    try {
      const out = BK_ENCRYPT ? BK.encryptBackup(b.buf, BK_PASS) : b.buf, fname = BK_ENCRYPT ? b.name.replace(/\.zip$/, ".kcvbak") : b.name;
      await BK.sendTelegramFile(TG_BK_TOKEN, TG_BK_CHAT, fname, out, "💾 Sao lưu Kim Chỉ Vàng · " + vnTime(Date.now()) + "\n" + codes.list.length + " mã · " + mleads.list.length + " khách tự thêm · " + Math.round(b.size / 1024) + " KB" +
        (BK_ENCRYPT ? "\n🔒 File đã mã hóa – khôi phục tại trang quản trị (mật khẩu quản trị)." : ""));
      bkState.lastSent = Date.now(); bkState.lastErr = null;
    } catch (e) { bkState.lastErr = e.message; console.error("Gửi sao lưu Telegram lỗi:", e.message); }
  }
  saveBkState();
  return b;
}
// tự sao lưu mỗi ngày sau 03:00 (giờ VN), kiểm tra 10 phút/lần
const vnDay = t => Math.floor((t + VN) / DAYMS);
function autoBackup() {
  const now = Date.now(), h = ((now + VN) % DAYMS) / 3600000;
  if (h >= 3 && vnDay(bkState.lastAuto || 0) !== vnDay(now)) {
    bkState.lastAuto = now; saveBkState();
    runBackup("", true).catch(e => console.error("Sao lưu lỗi:", e.message));
  }
}
setInterval(autoBackup, 10 * 60000); setTimeout(autoBackup, 30000);
// dọn dẹp mỗi giờ: phiên đăng nhập hết hạn / của mã đã xóa, khóa; thiết bị nhận thông báo của mã không còn
function cleanup() {
  const now = Date.now(); let s = 0, p = 0;
  for (const [t, x] of Object.entries(sessions)) { const c = findCode(x.code); if (!c || !c.active || x.created + SESSION_DAYS * DAYMS < now || (c.expires && c.expires + 30 * DAYMS < now)) { delete sessions[t]; s++; } }
  for (const [ep, r] of Object.entries(pushSubs)) { if (!findCode(r.code)) { delete pushSubs[ep]; p++; } }
  if (s) saveAuthNow(); if (p) savePush();
  if (s || p) console.log("Dọn dẹp:", s, "phiên đăng nhập cũ,", p, "thiết bị thông báo không còn dùng");
}
setInterval(cleanup, 3600000); setTimeout(cleanup, 60000);
// thống kê dung lượng cho trang quản trị
const SQLITE_HINT = { records: 20000, bytes: 40 * 1024 * 1024 };
function storageInfo() {
  const files = BK.DATA_FILES.map(f => { try { const st = fs.statSync(path.join(ROOT, f)); return { name: f, size: st.size, t: st.mtimeMs }; } catch (e) { return { name: f, size: 0, t: null }; } });
  const total = files.reduce((a, f) => a + f.size, 0), records = codes.list.length + mleads.list.length;
  let disk = null; try { const st = fs.statfsSync ? fs.statfsSync(ROOT) : null; if (st) disk = { free: st.bavail * st.bsize, size: st.blocks * st.bsize }; } catch (e) {}
  return { files, total, disk, records,
    counts: { codes: codes.list.length, staff: codes.list.filter(c => c.staff).length, trial: codes.list.filter(c => c.self).length, mleads: mleads.list.length, sessions: Object.keys(sessions).length, push: Object.keys(pushSubs).length, bars: state.bars.length },
    backups: BK.listBackups(BACKUP_DIR), state: bkState, tg: { configured: !!(TG_BK_TOKEN && TG_BK_CHAT), chat: TG_BK_CHAT.startsWith("@") ? TG_BK_CHAT : (TG_BK_CHAT ? "nhóm riêng tư" : ""), encrypted: BK_ENCRYPT },
    hint: SQLITE_HINT, needUpgrade: records >= SQLITE_HINT.records || total >= SQLITE_HINT.bytes, near: records >= SQLITE_HINT.records * 0.7 || total >= SQLITE_HINT.bytes * 0.7 };
}
function readRaw(req, limit, cb, fail) {
  const chunks = []; let size = 0, dead = false;
  req.on("data", c => { size += c.length; if (size > limit) { dead = true; fail(); req.destroy(); } else chunks.push(c); });
  req.on("end", () => { if (!dead) cb(Buffer.concat(chunks)); });
}

// ============================================================================
// WEB
// ============================================================================
const TYPES = { ".jpg": "image/jpeg", ".mp4": "video/mp4", ".webmanifest": "application/manifest+json", ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".json": "application/json" };
function send(res, code, body, type) {
  res.writeHead(code, { "Content-Type": type || "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Frame-Options": "SAMEORIGIN" });
  res.end(typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function view(res, name) {
  fs.readFile(path.join(VIEWS, name), (err, buf) => err ? send(res, 500, "Thiếu file " + name, "text/plain; charset=utf-8") : send(res, 200, buf, TYPES[".html"]));
}
function readBody(req, limit, cb) {
  let body = "", size = 0, dead = false;
  req.on("data", c => { size += c.length; if (size > limit) { dead = true; req.destroy(); } else body += c; });
  req.on("end", () => { if (!dead) cb(body); });
}
const jsonBody = (req, cb) => readBody(req, 20000, b => { let j = {}; try { j = JSON.parse(b || "{}"); } catch (e) {} cb(j); });

http.createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  const P = url.pathname;

  // ---------- EA đẩy giá ----------
  if (req.method === "POST" && P === "/api/push") {
    if (req.headers["x-token"] !== TOKEN) return send(res, 401, { error: "Sai Token" });
    return readBody(req, 8e6, body => {
      try {
        const j = JSON.parse(body);
        if (!Array.isArray(j.bars)) throw new Error("thiếu bars");
        merge(j.bars);
        if (j.symbol) state.symbol = String(j.symbol).slice(0, 24);
        if (Number.isInteger(j.digits)) state.digits = j.digits;
        state.updated = Date.now(); dirty = true; scheduleWatch();
        send(res, 200, { ok: true, bars: state.bars.length });
      } catch (e) { send(res, 400, { error: "Dữ liệu không hợp lệ: " + e.message }); }
    });
  }

  // ---------- bảo trì: trạng thái công khai + chặn khách ở phía máy chủ ----------
  if (req.method === "GET" && P === "/api/maint/status") return send(res, 200, { on: !!maint.on, since: maint.on ? maint.since : null, note: maint.on ? (maint.note || "") : "", msg: MAINT_MSG, tester: isTester(req) });
  if (maint.on && !isTester(req)) {
    const adminArea = P === "/quan-tri" || P === "/quan-tri/" || P.startsWith("/api/admin/");
    if (!adminArea && P !== "/api/logout") {
      if (P.startsWith("/api/")) {
        res.writeHead(503, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "Retry-After": "300", "X-KCV-Maint": "1" });
        return res.end(JSON.stringify({ maint: true, error: MAINT_MSG }));
      }
      const slug = P.replace(/^\/+|\/+$/g, "").toLowerCase();
      if (P === "/" || P === "/index.html" || slug === "noi-bo" || (slug && findRef(slug))) return view(res, "maintenance.html");
    }
  }

  // ---------- khách đăng nhập / đăng xuất ----------
  if (req.method === "POST" && P === "/api/login") {
    const ip = clientIp(req);
    if (tooMany(ip)) return send(res, 429, { error: "Nhập sai quá nhiều lần. Vui lòng thử lại sau 15 phút." });
    return jsonBody(req, j => {
      const c = findCode(j.code);
      if (!c) { addFail(ip); return send(res, 401, { error: "Mã truy cập không đúng. Kiểm tra lại hoặc nhắn Zalo để được cấp mã." }); }
      if (!c.active) return send(res, 403, { error: "Mã này đã bị khóa. Vui lòng liên hệ Zalo để được hỗ trợ." });
      if (c.expires && c.expires <= Date.now()) return send(res, 403, { error: "Mã này đã hết hạn. Vui lòng liên hệ Zalo để gia hạn." });
      // Giới hạn thiết bị: vượt quá thì đăng xuất thiết bị cũ nhất
      const devs = devicesOf(c.code).sort((a, b) => (a[1].lastSeen || a[1].created) - (b[1].lastSeen || b[1].created));
      while (devs.length >= (c.maxDevices || 2)) { delete sessions[devs.shift()[0]]; }
      const t = crypto.randomBytes(24).toString("hex");
      sessions[t] = { code: c.code, created: Date.now(), lastSeen: Date.now(), ua: String(req.headers["user-agent"] || "").slice(0, 160), ip };
      if (c.trial && !c.firstUse) { c.firstUse = Date.now(); c.clock = "wall"; }
      if (c.trial && trialLeft(c) <= 0) return send(res, 403, { error: "Mã dùng thử này đã hết thời gian. Nhắn Zalo để được cấp mã chính thức." });
      c.lastLogin = Date.now(); saveAuthNow();
      setCookie(req, res, "kcv_s", t, SESSION_DAYS * 86400);
      send(res, 200, { ok: true, name: c.name || "" });
    });
  }
  if (req.method === "POST" && P === "/api/logout") {
    const cu = customer(req); if (cu) { delete sessions[cu.token]; saveAuthNow(); }
    setCookie(req, res, "kcv_s", "", 0); return send(res, 200, { ok: true });
  }

  // ---------- khách vãng lai tự đăng ký dùng thử ----------
  if (req.method === "GET" && P === "/api/trial/status") {
    const used = findCode(parseCookies(req).kcv_t || "");
    return send(res, 200, { minutes: TRIAL_MIN, used: !!used, expired: !!used && !codeValid(used), converted: !!used && !used.trial, open: isOpenNow() });
  }
  if (req.method === "POST" && P === "/api/trial/resume") {          // khách đăng xuất / mất phiên nhưng còn giờ dùng thử
    const c = findCode(parseCookies(req).kcv_t || "");
    if (!c || !codeValid(c)) return send(res, 403, { error: "Thời gian dùng thử đã hết." });
    if (!c.trial) return send(res, 403, { error: "Bạn đã là khách chính thức – vui lòng nhập mã truy cập được gửi qua Zalo." });
    devicesOf(c.code).forEach(([t]) => delete sessions[t]);
    const t = crypto.randomBytes(24).toString("hex");
    sessions[t] = { code: c.code, created: Date.now(), lastSeen: Date.now(), ua: String(req.headers["user-agent"] || "").slice(0, 160), ip: clientIp(req) };
    saveAuthNow(); setCookie(req, res, "kcv_s", t, SESSION_DAYS * 86400); return send(res, 200, { ok: true });
  }
  if (req.method === "POST" && P === "/api/trial") {
    if (isTester(req)) return send(res, 403, { error: "Đang ở chế độ kiểm thử: không tạo khách dùng thử thật (tránh gửi tin Telegram và lẫn số liệu khách)." });
    const ip = clientIp(req);
    return jsonBody(req, j => {
      const name = String(j.name || "").trim().slice(0, 60), phone = normPhone(j.phone), dev = String(j.device || "").slice(0, 64);
      const hx = v => /^[0-9a-f]{16}$/.test(String(v || "")) ? String(v) : "";
      const fp = j.fp && typeof j.fp === "object" && hx(j.fp.hw) ? { fp: j.fp.noisy ? "" : hx(j.fp.fp), fpRaw: hx(j.fp.fp), hw: hx(j.fp.hw), noisy: !!j.fp.noisy, gpu: String(j.fp.gpu || "").slice(0, 80) } : null;
      if (name.length < 2) return send(res, 400, { error: "Vui lòng nhập họ tên." });
      if (!phone) return send(res, 400, { error: "Số Zalo chưa đúng. Nhập 10 số, ví dụ 0912 345 678." });
      const slug = String(parseCookies(req).kcv_ref || "").toLowerCase(), rr = findRef(slug);
      const ref = rr && rr.active ? rr.name : null;                                    // nguồn giới thiệu (từ link riêng)
      const prior = findCode(parseCookies(req).kcv_t || "");
      if (prior || codes.list.some(c => (c.trial || c.self || c.trialCode) && (c.phone === phone || (dev && c.device === dev))))
        return send(res, 409, { error: "Số Zalo hoặc thiết bị này đã dùng thử rồi. Nhắn Zalo 0886 558 169 để được cấp mã chính thức." });
      const now = Date.now();
      if (recentSelfFromIp(ip) >= 3) return send(res, 429, { error: "Mạng này đã đăng ký dùng thử nhiều lần hôm nay. Vui lòng nhắn Zalo để được hỗ trợ." });
      const ab = trialAbuse(fp, ip);
      if (ab.block) {
        const h = ab.flags.find(x => x.block); console.log("Chặn dùng thử lại:", name, phone, "·", h.why, "· trùng", h.name, h.phone);
        codes.blocked = [{ t: now, name, phone, ip, why: h.why, match: { code: h.code, name: h.name, phone: h.phone } }].concat(codes.blocked || []).slice(0, 200); saveAuthNow();
        return send(res, 409, { error: "Thiết bị này đã dùng thử rồi. Nhắn Zalo 0886 558 169 để được cấp mã chính thức." });
      }
      const c = { code: newTrialCode(), name, phone, note: "Tự đăng ký dùng thử · Zalo " + phone, created: now, expires: null,
        maxDevices: 1, active: true, trial: true, trialMinutes: TRIAL_MIN, firstUse: now, clock: "wall", device: dev, ip, self: true, fp, ref, refSlug: ref ? slug : null };
      if (ref) c.note += " · Nguồn: " + ref;
      if (ab.flags.length) c.suspect = ab.flags.map(x => ({ why: x.why, code: x.code || null, name: x.name || null, phone: x.phone || null }));
      codes.list.push(c);
      const t = crypto.randomBytes(24).toString("hex");
      sessions[t] = { code: c.code, created: now, lastSeen: now, ua: String(req.headers["user-agent"] || "").slice(0, 160), ip };
      saveAuthNow();
      setCookie(req, res, "kcv_s", t, SESSION_DAYS * 86400);
      setCookie(req, res, "kcv_t", c.code, 365 * 86400);         // đánh dấu trình duyệt đã dùng thử
      console.log("Khách dùng thử mới:", name, phone);
      notifyLead(c);
      send(res, 200, { ok: true });
    });
  }

  // ---------- khách bật / tắt thông báo ----------
  if (P.startsWith("/api/push/")) {
    const cu = customer(req);
    if (!cu && isTester(req)) {                     // admin kiểm thử: đăng ký thông báo vào kho riêng, không lẫn với khách thật
      if (req.method === "GET" && P === "/api/push/key") return send(res, 200, { key: VAPID.publicKey });
      if (req.method === "POST" && P === "/api/push/subscribe") return jsonBody(req, j => {
        const sub = j.subscription;
        if (!sub || typeof sub.endpoint !== "string" || !/^https:\/\//.test(sub.endpoint) || !sub.keys || !sub.keys.p256dh || !sub.keys.auth) return send(res, 400, { error: "Đăng ký không hợp lệ" });
        maint.testSubs[sub.endpoint] = { sub: { endpoint: sub.endpoint, keys: { p256dh: String(sub.keys.p256dh), auth: String(sub.keys.auth) } }, created: Date.now(), mode: "all", tfs: [1, 3, 15, 60] };
        saveMaint(); send(res, 200, { ok: true, mode: "all", tfs: [1, 3, 15, 60], test: true });
      });
      if (req.method === "POST" && P === "/api/push/unsubscribe") return jsonBody(req, j => { if (j.endpoint && maint.testSubs[j.endpoint]) { delete maint.testSubs[j.endpoint]; saveMaint(); } send(res, 200, { ok: true }); });
      return send(res, 404, { error: "Không có" });
    }
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (req.method === "GET" && P === "/api/push/key") return send(res, 200, { key: VAPID.publicKey });
    if (req.method === "POST" && P === "/api/push/subscribe") return jsonBody(req, j => {
      if (maint.staffOnly && !cu.code.staff) return send(res, 503, { error: "Chức năng thông báo đang bảo trì", notifyPaused: true });   // chỉ nội bộ: khách chưa bật được
      const sub = j.subscription;
      if (!sub || typeof sub.endpoint !== "string" || !/^https:\/\//.test(sub.endpoint) || !sub.keys || !sub.keys.p256dh || !sub.keys.auth) return send(res, 400, { error: "Đăng ký không hợp lệ" });
      const prev = pushSubs[sub.endpoint];
      const mode = j.mode === "all" || j.mode === "session" ? j.mode : prev ? modeOf(prev) : DEFAULT_MODE;
      const tfs = cleanTfs(j.tfs).length ? cleanTfs(j.tfs) : prev ? tfsOf(prev) : [1];
      pushSubs[sub.endpoint] = { sub: { endpoint: sub.endpoint, keys: { p256dh: String(sub.keys.p256dh), auth: String(sub.keys.auth) } }, code: cu.code.code, created: prev ? prev.created : Date.now(), mode, tfs };
      savePush(); send(res, 200, { ok: true, mode, tfs });
    });
    if (req.method === "POST" && P === "/api/push/unsubscribe") return jsonBody(req, j => { if (j.endpoint && pushSubs[j.endpoint]) { delete pushSubs[j.endpoint]; savePush(); } send(res, 200, { ok: true }); });
    return send(res, 404, { error: "Không có" });
  }

  // ---------- trang nội bộ cho nhân viên ----------
  if (P === "/noi-bo" || P === "/noi-bo/") {
    const cu = customer(req);
    if (cu && cu.code.staff) return view(res, "staff.html");
    res.writeHead(302, { Location: "/" }); return res.end();
  }
  if (req.method === "GET" && P === "/api/internal/summary") {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (!cu.code.staff) return send(res, 403, { error: "Mã này không có quyền nội bộ" });
    try { return send(res, 200, sessionSummary()); } catch (e) { return send(res, 500, { error: "Lỗi tính tổng kết" }); }
  }
  if (req.method === "GET" && P === "/api/internal") {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (!cu.code.staff) return send(res, 403, { error: "Mã này không có quyền nội bộ" });
    return send(res, 200, { list: internalLog.slice(-50).reverse(), name: cu.code.name || "", telegram: !!(TG_TOKEN && TG_CHAT), mention: CONFIG.internalMention === "" ? "" : (CONFIG.internalMention || "@All") });
  }

  // ---------- nhân viên nội bộ: khách TỰ THÊM (nguồn ngoài) ----------
  if (P.startsWith("/api/staff/mleads")) {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (!cu.code.staff) return send(res, 403, { error: "Mã này không có quyền nội bộ" });
    const me = { code: cu.code.code, name: cu.code.name || cu.code.code };
    const mine = l => l && normCode(l.careByCode) === normCode(me.code);
    if (req.method === "GET" && P === "/api/staff/mleads")
      return send(res, 200, { list: mleads.list.filter(mine).sort((a, b) => b.created - a.created).map(mleadView), me: me.code, sources: SOURCES, reasons: LOST_REASONS });
    if (req.method !== "POST") return send(res, 405, { error: "Không hỗ trợ" });
    return jsonBody(req, j => {
      const act = P.slice("/api/staff/mleads/".length);
      if (act === "add") {
        const f = leadFields(null, j); if (f.error) return send(res, 400, f);
        const d = dupOf(f.account, null); if (d) return send(res, 409, { error: d });
        const now = Date.now();
        const l = Object.assign({ code: newLeadId(), manual: true, active: true, created: now, careBy: me.name, careByCode: me.code, careAt: now, trial: true }, f);
        l.hist = [{ t: now, by: me.name, byCode: me.code, act: "Thêm khách · " + f.source }];
        mleads.list.push(l); saveMleads(); console.log("Khách tự thêm:", l.name, f.phone || f.contact, "·", f.source, "· bởi", me.name);
        return send(res, 200, mleadView(l));
      }
      const l = findLead(j.code);
      if (!l || !mine(l)) return send(res, 404, { error: "Không tìm thấy khách trong danh sách của bạn" });
      const done = () => { saveMleads(); send(res, 200, mleadView(l)); };
      if (act === "edit") {
        const f = leadFields(l, j); if (f.error) return send(res, 400, f);
        const d = dupOf(f.account, l); if (d) return send(res, 409, { error: d });
        Object.assign(l, f); l.editedAt = Date.now();
        l.hist = (l.hist || []).concat({ t: l.editedAt, by: me.name, byCode: me.code, act: "Sửa thông tin" }).slice(-20);
        return done();
      }
      if (act === "delete") {
        if (l.closedAt) return send(res, 400, { error: "Khách đã chốt, không xóa được. Liên hệ quản trị nếu cần." });
        mleads.list = mleads.list.filter(x => x !== l); saveMleads(); console.log("Xóa khách tự thêm:", l.name, "· bởi", me.name);
        return send(res, 200, { ok: true });
      }
      if (act === "lost" || act === "reopen") {
        if (l.closedAt) return send(res, 400, { error: "Khách đã chốt chính thức" });
        if (act === "lost") { const r = setLost(l, j, me); if (r.error) return send(res, 400, r); } else reopenLead(l, me);
        return done();
      }
      if (act === "trial") {            // cấp mã dùng thử cho khách này (đứng tên nhân viên)
        if (l.closedAt) return send(res, 400, { error: "Khách đã chốt chính thức" });
        const ex = l.codeRef && findCode(l.codeRef); if (ex) return send(res, 400, { error: "Khách đã có mã " + ex.code });
        const c = makeCode({ name: l.name, note: "Khách tự thêm · " + l.source + (l.phone ? " · Zalo " + l.phone : ""), days: "trial" }, me); if (c.error) return send(res, 400, c);
        c.leadId = l.code; l.codeRef = c.code; saveAuthNow();
        l.hist = (l.hist || []).concat({ t: Date.now(), by: me.name, byCode: me.code, act: "Cấp mã dùng thử " + c.code }).slice(-20);
        return done();
      }
      if (act === "convert") {          // khách đồng ý → mã chính thức (chuyển mã dùng thử đang có, hoặc cấp mã mới)
        if (l.closedAt) return send(res, 400, { error: "Khách đã chốt rồi" });
        const d = parseInt(j.days, 10); if (!STAFF_EXT.includes(d)) return send(res, 400, { error: "Chọn gói hợp lệ" });
        const now = Date.now(); let c = l.codeRef && findCode(l.codeRef);
        if (c && c.trial) { c.closedAt = now; const r = applyAction(c, { action: "convert", days: d }, me); if (r.error) return send(res, 400, r); }
        else if (c) { const r = applyAction(c, { action: "extend", days: d }, me); if (r.error) return send(res, 400, r); }
        else { c = makeCode({ name: l.name, note: "Khách tự thêm · " + l.source + (l.phone ? " · Zalo " + l.phone : ""), days: String(d), maxDevices: 2 }, me); if (c.error) return send(res, 400, c); c.leadId = l.code; l.codeRef = c.code; }
        c.closedAt = c.closedAt || now; c.closedBy = me.name; c.closedByCode = me.code; c.closedDays = d; saveAuthNow();
        if (l.lostAt) { l.outcomes = (l.outcomes || []).concat({ t: now, by: me.name, act: "Khách đổi ý → chốt" }).slice(-20); l.lostAt = l.lostReason = l.followAt = null; l.lostNote = ""; }
        l.trial = false; l.wasTrial = true; l.closedAt = now; l.closedBy = me.name; l.closedByCode = me.code; l.closedDays = d; l.expires = c.expires;
        l.hist = (l.hist || []).concat({ t: now, by: me.name, byCode: me.code, act: "Chốt chính thức " + d + " ngày · mã " + c.code }).slice(-20);
        notifyClose(Object.assign({}, l, { name: l.name + " (" + l.source + ")" }));
        return done();
      }
      if (act === "info") {
        if (!l.closedAt) return send(res, 400, { error: "Chốt chính thức trước rồi mới ghi thông tin tài khoản" });
        const d = dupOf(j.account, l); if (d) return send(res, 409, { error: d });
        const r = setAcct(l, j, me.name); if (r.error) return send(res, 400, r);
        if (l.acct && l.acct.account) l.account = l.acct.account;
        const c = l.codeRef && findCode(l.codeRef); if (c) { c.acct = l.acct; saveAuthNow(); }
        return done();
      }
      return send(res, 404, { error: "Không có" });
    });
  }

  // ---------- nhân viên nội bộ: khách tự đăng ký dùng thử ----------
  if (P === "/api/staff/leads" || P === "/api/staff/leads/claim" || P === "/api/staff/leads/convert" || P === "/api/staff/leads/info" || P === "/api/staff/leads/lost" || P === "/api/staff/leads/reopen") {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (!cu.code.staff) return send(res, 403, { error: "Mã này không có quyền nội bộ" });
    if (req.method === "GET" && P === "/api/staff/leads") {
      const since = Date.now() - 30 * DAYMS;
      const list = codes.list.filter(c => c.self && (c.created >= since || (c.careByCode && normCode(c.careByCode) === normCode(cu.code.code)))).sort((a, b) => b.created - a.created).slice(0, 200).map(leadView);
      return send(res, 200, { list, me: cu.code.code, meName: cu.code.name || "", reasons: LOST_REASONS });
    }
    if (req.method === "POST" && P === "/api/staff/leads/claim") return jsonBody(req, j => {
      const c = findCode(j.code);
      if (!c || !c.self) return send(res, 404, { error: "Không tìm thấy khách" });
      const mine = c.careByCode && normCode(c.careByCode) === normCode(cu.code.code);
      if (j.release) {
        if (!mine) return send(res, 403, { error: "Chỉ người đang phụ trách mới trả lại được" });
        c.careBy = c.careByCode = c.careAt = null; c.lostAt = c.lostReason = c.lostBy = c.lostByCode = c.followAt = null; c.lostNote = "";
        c.hist = (c.hist || []).concat({ t: Date.now(), by: cu.code.name || cu.code.code, byCode: cu.code.code, act: "Trả lại khách" }).slice(-20);
      } else {
        if (c.careByCode && !mine) return send(res, 409, { error: (c.careBy || "Nhân viên khác") + " đã nhận chăm sóc khách này" });
        c.careBy = cu.code.name || cu.code.code; c.careByCode = cu.code.code; c.careAt = Date.now();
        c.hist = (c.hist || []).concat({ t: c.careAt, by: c.careBy, byCode: c.careByCode, act: "Nhận chăm sóc" }).slice(-20);
      }
      saveAuthNow(); console.log("Khách dùng thử", c.code, c.name, j.release ? "trả lại bởi" : "nhận bởi", cu.code.name);
      send(res, 200, leadView(c));
    });
    if (req.method === "POST" && (P === "/api/staff/leads/lost" || P === "/api/staff/leads/reopen")) return jsonBody(req, j => {
      const c = findCode(j.code);
      if (!c || !c.self) return send(res, 404, { error: "Không tìm thấy khách" });
      if (!c.careByCode || normCode(c.careByCode) !== normCode(cu.code.code)) return send(res, 403, { error: "Chỉ nhân viên đang phụ trách khách này mới thao tác được" });
      if (c.closedAt) return send(res, 400, { error: "Khách đã chốt chính thức" });
      const who = { code: cu.code.code, name: cu.code.name };
      if (P === "/api/staff/leads/lost") { const r = setLost(c, j, who); if (r.error) return send(res, 400, r); }
      else reopenLead(c, who);
      saveAuthNow(); console.log("Khách", c.code, c.name, P.endsWith("lost") ? "· " + c.lostReason : "· chăm sóc lại", "· bởi", cu.code.name);
      send(res, 200, leadView(c));
    });
    if (req.method === "POST" && (P === "/api/staff/leads/convert" || P === "/api/staff/leads/info")) return jsonBody(req, j => {
      const c = findCode(j.code);
      if (!c || !c.self) return send(res, 404, { error: "Không tìm thấy khách" });
      if (!c.careByCode || normCode(c.careByCode) !== normCode(cu.code.code)) return send(res, 403, { error: "Chỉ nhân viên đang phụ trách khách này mới thao tác được" });
      const who = { code: cu.code.code, name: cu.code.name };
      if (P === "/api/staff/leads/convert") {
        if (!c.trial) return send(res, 400, { error: "Khách này đã là chính thức" });
        if (c.lostAt) { c.outcomes = (c.outcomes || []).concat({ t: Date.now(), by: cu.code.name || cu.code.code, act: "Khách đổi ý → chốt" }).slice(-20); c.lostAt = c.lostReason = c.followAt = null; c.lostNote = ""; }
        const r = applyAction(c, { action: "convert", days: j.days }, who); if (r.error) return send(res, 400, r);
      } else {
        if (c.trial) return send(res, 400, { error: "Chuyển chính thức trước rồi mới ghi thông tin tài khoản" });
        const d = dupOf(j.account, c); if (d) return send(res, 409, { error: d });
        const r = setAcct(c, j, cu.code.name || cu.code.code); if (r.error) return send(res, 400, r);
      }
      saveAuthNow(); send(res, 200, leadView(c));
    });
    return send(res, 405, { error: "Không hỗ trợ" });
  }

  // ---------- nhân viên nội bộ cấp mã cho khách ----------
  if (P === "/api/staff/codes") {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (!cu.code.staff) return send(res, 403, { error: "Mã này không có quyền nội bộ" });
    if (req.method === "GET") {
      const list = codes.list.filter(c => !c.removed && c.byCode && normCode(c.byCode) === normCode(cu.code.code)).map(c => ({
        code: c.code, name: c.name, note: c.note, created: c.created, expires: c.expires, maxDevices: c.maxDevices, active: c.active,
        trial: !!c.trial, wasTrial: !!c.wasTrial, firstUse: c.firstUse || null, trialLeft: c.trial ? trialLeft(c) : null, valid: codeValid(c),
        devices: devicesOf(c.code).length, hist: (c.hist || []).slice(-3), issuedAt: c.issuedAt || c.created, trialCode: c.trialCode || null, phone: c.phone || "", fromTrial: c.self ? "Khách tự đăng ký dùng thử" : null })).sort((a, b) => b.issuedAt - a.issuedAt);
      return send(res, 200, { list, me: cu.code.name || "", dailyMax: STAFF_DAILY_MAX, trialMinutes: TRIAL_MIN });
    }
    if (req.method === "POST" && url.searchParams.get("act")) return jsonBody(req, j => {
      const c = findCode(j.code);
      if (!c || !c.byCode || normCode(c.byCode) !== normCode(cu.code.code)) return send(res, 404, { error: "Bạn chỉ thao tác được mã do mình cấp" });
      const r = applyAction(c, j, { code: cu.code.code, name: cu.code.name });
      if (r.error) return send(res, 400, r);
      saveAuthNow(); send(res, 200, { ok: true });
    });
    if (req.method === "POST") return jsonBody(req, j => {
      const r = makeCode(j, { code: cu.code.code, name: cu.code.name });
      if (r.error) return send(res, 400, r);
      send(res, 200, { code: r.code, name: r.name, note: r.note, created: r.created, expires: r.expires, maxDevices: r.maxDevices, trial: !!r.trial });
    });
  }

  // ---------- dữ liệu cho khách đã đăng nhập ----------
  if (req.method === "GET" && P === "/api/signals") {       // tín hiệu vùng MUA / BÁN đã báo trong 24 giờ (mới nhất trước)
    const cu = customer(req) || (isTester(req) ? { code: { staff: true } } : null);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (maint.staffOnly && !cu.code.staff) return send(res, 200, { paused: true, list: [] });
    return send(res, 200, { list: signalLog.filter(x => Date.now() - x.t < DAYMS).slice(-60).reverse(), now: Date.now() });
  }
  if (req.method === "GET" && (P === "/api/bars" || P === "/api/me")) {
    const cu = customer(req) || (isTester(req) ? { code: { name: "Quản trị (kiểm thử)", expires: null, staff: false } } : null);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (P === "/api/me") return send(res, 200, { name: cu.code.name || "", expires: cu.code.expires || null, staff: !!cu.code.staff, test: isTester(req), maint: !!maint.on, notifyPaused: !!maint.staffOnly && !cu.code.staff && !isTester(req),
      trial: cu.code.trial ? { leftMs: trialLeft(cu.code), totalMs: (cu.code.trialMinutes || TRIAL_MIN) * 60000, firstUse: cu.code.firstUse || null, open: isOpenNow(), sesStart: CONFIG.sessStart || 7, sesEnd: CONFIG.sessEnd || 21 } : null });
    const since = parseInt(url.searchParams.get("since") || "0", 10) || 0;
    const tf = [1, 3, 15, 60].includes(parseInt(url.searchParams.get("tf") || "1", 10)) ? parseInt(url.searchParams.get("tf") || "1", 10) : 1;
    const src = tf === 1 ? state.bars : aggBars(tf);
    const bars = since ? src.filter(b => b[0] >= since).slice(-SEND_BARS) : src.slice(-SEND_BARS);
    return send(res, 200, { symbol: state.symbol, digits: state.digits, updated: state.updated, now: Date.now(), tf, bars });
  }

  // ---------- quản trị ----------
  if (P === "/quan-tri" || P === "/quan-tri/") return view(res, "admin.html");
  if (req.method === "POST" && P === "/api/admin/login") {
    const ip = clientIp(req);
    if (tooMany(ip)) return send(res, 429, { error: "Sai quá nhiều lần, thử lại sau 15 phút." });
    return jsonBody(req, j => {
      const a = Buffer.from(String(j.password || "")), b = Buffer.from(ADMIN_PASS);
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) { addFail(ip); return send(res, 401, { error: "Sai mật khẩu" }); }
      const t = crypto.randomBytes(24).toString("hex"); adminSessions.set(t, Date.now() + 12 * 3600000);
      setCookie(req, res, "kcv_a", t, 12 * 3600); send(res, 200, { ok: true });
    });
  }
  if (P.startsWith("/api/admin/")) {
    if (!isAdmin(req)) return send(res, 401, { error: "Chưa đăng nhập quản trị" });
    if (req.method === "POST" && P === "/api/admin/logout") {
      const ck = parseCookies(req); if (ck.kcv_x && testSessions.has(ck.kcv_x)) { testSessions.delete(ck.kcv_x); maintLog(req, "Thoát kiểm thử (đăng xuất quản trị)"); }
      adminSessions.delete(ck.kcv_a); setCookie(req, res, "kcv_a", "", 0); setCookie(req, res, "kcv_x", "", 0); return send(res, 200, { ok: true });
    }
    // ---------- bảo trì & kiểm thử ----------
    if (req.method === "GET" && P === "/api/admin/maint") {
      const now = Date.now(); for (const [k, x] of testSessions) if (x.exp < now || !adminSessions.has(x.admin)) testSessions.delete(k);
      return send(res, 200, { on: !!maint.on, since: maint.since || null, note: maint.note || "", msg: MAINT_MSG, tester: isTester(req), testers: testSessions.size,
        testSubs: Object.keys(maint.testSubs).length, staffOnly: !!maint.staffOnly, staffOnlySince: maint.staffOnlySince || null, orderTf: orderTf(),
        staffDevices: Object.values(pushSubs).filter(r => { const c = findCode(r.code); return c && c.staff && codeValid(c); }).length, log: maint.log.slice(0, 100) });
    }
    if (req.method === "POST" && P === "/api/admin/maint") return jsonBody(req, j => {
      const act = String(j.action || ""), note = String(j.note || "").trim().slice(0, 200), ck = parseCookies(req);
      if (act === "on") {
        if (maint.on) return send(res, 200, { ok: true });
        maint.on = true; maint.since = Date.now(); maint.note = note; maintLog(req, "BẬT bảo trì", note ? { note } : null);
        return send(res, 200, { ok: true });
      }
      if (act === "off") {
        if (!maint.on) return send(res, 200, { ok: true });
        const n = testSessions.size; testSessions.clear(); setCookie(req, res, "kcv_x", "", 0);
        const dur = Date.now() - (maint.since || Date.now());
        maint.on = false; maint.note = ""; maintLog(req, "TẮT bảo trì – mở lại website", { note: "Bảo trì " + durTxt(dur) + (n ? " · tự thoát " + n + " phiên kiểm thử" : "") });
        return send(res, 200, { ok: true });
      }
      if (act === "note") { maint.note = note; maintLog(req, "Sửa ghi chú bảo trì", note ? { note } : null); return send(res, 200, { ok: true }); }
      if (act === "test-on") {
        if (isTester(req)) return send(res, 200, { ok: true });
        const t = crypto.randomBytes(24).toString("hex"); testSessions.set(t, { exp: Date.now() + 12 * 3600000, admin: ck.kcv_a });
        setCookie(req, res, "kcv_x", t, 12 * 3600); maintLog(req, "VÀO chế độ kiểm thử", { note: maint.on ? "Website vẫn bảo trì" : "Website đang mở" });
        return send(res, 200, { ok: true });
      }
      if (act === "test-off") {
        if (ck.kcv_x && testSessions.has(ck.kcv_x)) { testSessions.delete(ck.kcv_x); maintLog(req, "THOÁT chế độ kiểm thử"); }
        setCookie(req, res, "kcv_x", "", 0); return send(res, 200, { ok: true });
      }
      if (act === "test-push") {
        if (!Object.keys(maint.testSubs).length) return send(res, 400, { error: "Chưa có thiết bị kiểm thử. Cách bật: trên điện thoại mở /quan-tri, đăng nhập quản trị → bấm VÀO CHẾ ĐỘ KIỂM THỬ → Mở website kiểm thử → kéo xuống bấm Bật thông báo. (Điện thoại đó không được đang đăng nhập mã khách.)" });
        return sampleZonePush(Object.entries(maint.testSubs), maint.testSubs, "[KIỂM THỬ] ").then(r => send(res, 200, r));
      }
      if (act === "staff-on" || act === "staff-off") {             // chỉ tài khoản nội bộ nhận thông báo tín hiệu (thử tín hiệu trước khi mở cho khách)
        const on = act === "staff-on"; if (!!maint.staffOnly === on) return send(res, 200, { ok: true });
        const dur = on ? 0 : Date.now() - (maint.staffOnlySince || Date.now());
        maint.staffOnly = on; maint.staffOnlySince = on ? Date.now() : null;
        maintLog(req, on ? "BẬT chỉ nội bộ nhận thông báo – khách tạm không nhận" : "TẮT chỉ nội bộ – khách nhận thông báo lại", on ? null : { note: "Đã chạy " + durTxt(dur) });
        return send(res, 200, { ok: true });
      }
      if (act === "order-tf") {                                  // khung sinh lệnh nội bộ + Telegram + tổng kết
        const tf = Number(j.tf); if (![1, 3, 15, 60].includes(tf)) return send(res, 400, { error: "Khung không hợp lệ" });
        if (tf === orderTf()) return send(res, 200, { ok: true });
        const old = orderTf(); maint.orderTf = tf; seedOrders = true;
        maintLog(req, "Đổi khung lệnh nội bộ & Telegram", { note: ({ 1: "M1", 3: "M3", 15: "M15", 60: "H1" })[old] + " → " + ({ 1: "M1", 3: "M3", 15: "M15", 60: "H1" })[tf] });
        return send(res, 200, { ok: true });
      }
      if (act === "test-subs-clear") { maint.testSubs = {}; saveMaint(); return send(res, 200, { ok: true }); }
      return send(res, 400, { error: "Thao tác không hợp lệ" });
    });
    if (req.method === "GET" && P === "/api/admin/codes") {
      const list = codes.list.map(c => {
        const devs = devicesOf(c.code).map(([, s]) => s);
        const pushN = Object.values(pushSubs).filter(r => normCode(r.code) === normCode(c.code)).length;
        return Object.assign({}, c, { byLabel: byLabel(c), push: pushN, devices: devs.length, lastSeen: devs.reduce((m, s) => Math.max(m, s.lastSeen || 0), 0) || null, valid: codeValid(c), trialLeft: c.trial ? trialLeft(c) : null });
      }).sort((a, b) => b.created - a.created);
      return send(res, 200, { trialMinutes: TRIAL_MIN, list, issuers: codes.list.filter(c => c.staff).map(c => ({ code: c.code, name: c.name })), deleted: (codes.deleted || []).slice(-100).reverse(), blocked: (codes.blocked || []).slice(0, 100), feed: { updated: state.updated, bars: state.bars.length }, pushTotal: Object.keys(pushSubs).length });
    }
    if (req.method === "POST" && P === "/api/admin/codes") {
      return jsonBody(req, j => {
        const r = makeCode(j, null);
        if (r.error) return send(res, 400, r);
        send(res, 200, Object.assign({}, r, { byLabel: byLabel(r) }));
      });
    }
    if (maint.on && (P === "/api/admin/internal-test" || P === "/api/admin/lead-test" || P === "/api/admin/push-test") && req.headers["x-kcv-confirm"] !== "1")
      return send(res, 409, { needConfirm: true, error: "Đang bảo trì: tin thử này gửi tới nhân viên / khách / Telegram THẬT. Cần xác nhận riêng." });
    if (req.method === "POST" && P === "/api/admin/internal-test") return jsonBody(req, J => {
      if (J.kind === "zone") {                       // mẫu thông báo KHÁCH nhận: "GIÁ ĐANG TRONG VÙNG MUA / BÁN"
        const tz = String(J.code || "").trim(); if (tz && !findCode(tz)) return send(res, 404, { error: "Không tìm thấy mã " + tz });
        const L = Object.entries(pushSubs).filter(([, r]) => { const c = findCode(r.code); return c && codeValid(c) && (tz ? normCode(c.code) === normCode(tz) : c.staff); });
        return sampleZonePush(L, null).then(r => send(res, 200, { ok: r.ok, total: r.total, n: 2, telegram: false, only: tz || null, kind: "zone" }));
      }
      // tin thử cả MUA và BÁN, theo đúng công thức đang chạy (giá quanh giá hiện tại)
      const now = Date.now(), recs = [1, -1].map(d => ({ s: demoSig(d), rec: null }));
      for (const x of recs) {
        const base = buildInternal(x.s, [x.s], Object.assign({}, CONFIG, { tfLabel: ({ 1: "M1", 3: "M3", 15: "M15", 60: "H1" })[orderTf()] }));
        x.rec = { id: "test" + now + (x.s.dir === 1 ? "b" : "s"), t: now, dir: x.s.dir, add: false, entry: x.s.entry, text: "[TIN THỬ – KHÔNG GIAO DỊCH]\n" + base.text, push: { title: "[THỬ] " + base.push.title, body: base.push.body } };
        internalLog.push(x.rec);
      }
      internalLog = internalLog.slice(-100); saveJson(INTERNAL_FILE, internalLog);
      // J.code: chỉ gửi tới thiết bị của 1 mã (vd mã của anh) · J.telegram: có gửi nhóm Telegram không (mặc định có)
      const target = String(J.code || "").trim();
      if (target && !findCode(target)) return send(res, 404, { error: "Không tìm thấy mã " + target });
      const staff = Object.entries(pushSubs).filter(([, r]) => { const c = findCode(r.code); return c && codeValid(c) && (target ? normCode(c.code) === normCode(target) : c.staff); });
      const tg = J.telegram !== false && !!(TG_TOKEN && TG_CHAT);
      return Promise.all(recs.map(x => pushTo(staff, { title: x.rec.push.title, body: x.rec.push.body, tag: "itest" + x.rec.id, url: "/noi-bo#" + x.rec.id }))).then(rs => {
        if (tg) (async () => { for (const x of recs) await sendTelegram(x.rec.text); })();
        send(res, 200, { ok: rs[0].ok, total: rs[0].total, n: recs.length, telegram: tg, only: target || null });
      });
    });
    if (req.method === "POST" && P === "/api/admin/lead-test") {
      const dest = LEAD_TG || null, where = LEAD_TG ? "lead" : (TG_TOKEN && TG_CHAT ? "main" : "none");
      if (where === "none") return send(res, 400, { error: "Chưa cài Telegram (KCV_TG_LEAD_CHAT / KCV_TG_CHAT trong start.bat)" });
      return sendTelegram(dest, "🎁 [TIN THỬ] Khách dùng thử mới\nTên: Khách thử\nZalo: 0912 345 678\n(Đây là tin kiểm tra nhóm Telegram khách dùng thử)")
        .then(ok => ok ? send(res, 200, { ok: true, where }) : send(res, 502, { error: "Telegram không nhận tin. Kiểm tra token, ID nhóm và bot đã được thêm vào nhóm chưa." }));
    }
    if (req.method === "POST" && P === "/api/admin/push-test") {
      return jsonBody(req, async j => {
        const list = Object.entries(pushSubs).filter(([, r]) => !j.code || normCode(r.code) === normCode(j.code));
        if (!list.length) return send(res, 400, { error: "Chưa có thiết bị nào bật thông báo" });
        const r = await sampleZonePush(list, null);                // gửi mẫu "vùng MUA" + "vùng BÁN" đúng dạng khách nhận
        send(res, 200, r);
      });
    }
    if (req.method === "GET" && P === "/api/admin/storage") return send(res, 200, storageInfo());
    // tải dữ liệu nến M1 đang dùng để tính tín hiệu (đối chiếu với TradingView) – giờ Việt Nam
    if (req.method === "GET" && P === "/api/admin/bars.csv") {
      const z = x => (x < 10 ? "0" : "") + x, vn = t => { const d = new Date(t * 1000 + 7 * 3600000); return d.getUTCFullYear() + "-" + z(d.getUTCMonth() + 1) + "-" + z(d.getUTCDate()) + " " + z(d.getUTCHours()) + ":" + z(d.getUTCMinutes()); };
      const csv = "time_vn,unix,open,high,low,close\r\n" + state.bars.map(b => [vn(b[0]), b[0], b[1], b[2], b[3], b[4]].join(",")).join("\r\n");
      res.writeHead(200, { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": 'attachment; filename="kcv-nen-m1-' + Date.now() + '.csv"', "Cache-Control": "no-store" });
      return res.end("\ufeff" + csv);
    }
    if (req.method === "POST" && P === "/api/admin/backup/now")
      return runBackup("thu-cong", true).then(b => send(res, 200, { ok: true, name: b.name, size: b.size, sent: bkState.lastSent && Date.now() - bkState.lastSent < 60000, err: bkState.lastErr || null }))
        .catch(e => send(res, 500, { error: "Không tạo được bản sao lưu: " + e.message }));
    if (req.method === "GET" && P === "/api/admin/backup/download") {
      let name = url.searchParams.get("name") || "";
      try {
        if (!name) { flushAll(); name = BK.createBackup(ROOT, BACKUP_DIR, "tai-ve").name; }
        if (!BK.NAME_RE.test(name)) return send(res, 400, { error: "Tên file không hợp lệ" });
        const f = path.join(BACKUP_DIR, name); if (!fs.existsSync(f)) return send(res, 404, { error: "Không còn file này" });
        const buf = fs.readFileSync(f);
        res.writeHead(200, { "Content-Type": "application/zip", "Content-Length": buf.length, "Content-Disposition": 'attachment; filename="' + name + '"', "Cache-Control": "no-store" });
        return res.end(buf);
      } catch (e) { return send(res, 500, { error: "Lỗi tải sao lưu: " + e.message }); }
    }
    if (req.method === "POST" && P === "/api/admin/restore") {
      return readRaw(req, 60 * 1024 * 1024, buf => {
        let info;
        if (BK.isEncrypted(buf)) {                       // file .kcvbak lấy từ Telegram: giải mã trước
          const tries = [req.headers["x-backup-pass"] ? decodeURIComponent(String(req.headers["x-backup-pass"])) : null, BK_PASS, ADMIN_PASS].filter(Boolean);
          let plain = null; for (const pw of tries) { try { plain = BK.decryptBackup(buf, pw); break; } catch (e) {} }
          if (!plain) return send(res, 400, { error: "File đã mã hóa – mật khẩu không đúng. Nhập mật khẩu quản trị lúc tạo bản sao lưu.", needPassword: true });
          buf = plain;
        }
        try { info = BK.inspectBackup(buf); } catch (e) { return send(res, 400, { error: e.message }); }
        if (url.searchParams.get("check")) return send(res, 200, { ok: true, codes: info.codes, leads: info.leads, files: Object.keys(info.files) });
        try {
          flushAll(); const safe = BK.createBackup(ROOT, BACKUP_DIR, "truoc-khoi-phuc");          // bản an toàn trước khi ghi đè
          for (const [f, data] of Object.entries(info.files)) { const p = path.join(ROOT, f); fs.writeFileSync(p + ".tmp", data); fs.renameSync(p + ".tmp", p); }
          console.log("ĐÃ KHÔI PHỤC từ bản sao lưu:", Object.keys(info.files).join(", "), "· bản an toàn:", safe.name, "· máy chủ khởi động lại…");
          send(res, 200, { ok: true, codes: info.codes, leads: info.leads, safe: safe.name });
          setTimeout(() => process.exit(0), 800);                                   // start.bat tự bật lại máy chủ với dữ liệu mới
        } catch (e) { send(res, 500, { error: "Khôi phục lỗi: " + e.message }); }
      }, () => send(res, 413, { error: "File quá lớn" }));
    }
    if (req.method === "GET" && P === "/api/admin/mleads")
      return send(res, 200, { list: mleads.list.slice().sort((a, b) => b.created - a.created).map(mleadView), sources: SOURCES });
    if (req.method === "POST" && P === "/api/admin/info") {
      return jsonBody(req, j => {
        const c = findCode(j.code); if (!c) return send(res, 404, { error: "Không tìm thấy mã" });
        const d = dupOf(j.account, c); if (d) return send(res, 409, { error: d });
        const r = setAcct(c, j, "Admin"); if (r.error) return send(res, 400, r);
        const ml = c.leadId && findLead(c.leadId); if (ml) { ml.acct = c.acct; if (c.acct.account) ml.account = c.acct.account; saveMleads(); }
        saveAuthNow(); send(res, 200, { ok: true });
      });
    }
    // ---------- quản lý link giới thiệu ----------
    if (req.method === "GET" && P === "/api/admin/refs") {
      const now = Date.now(), list = refList().map(r => {
        const cs = codes.list.filter(c => c.self && c.refSlug === r.slug);
        const won = cs.filter(c => c.closedAt), dep = cs.reduce((a, c) => a + (c.acct && Number(c.acct.deposit) > 0 ? Number(c.acct.deposit) : 0), 0);
        const m30 = cs.filter(c => now - c.created < 30 * DAYMS).length, d7 = cs.filter(c => now - c.created < 7 * DAYMS).length;
        return Object.assign({}, r, { signups: cs.length, trialing: cs.filter(c => c.trial && codeValid(c)).length, won: won.length, active7: d7, last30: m30,
          lost: cs.filter(c => c.lostAt && !c.closedAt).length, deposit: dep, lastSignup: cs.reduce((m, c) => Math.max(m, c.created), 0) || null,
          customers: cs.sort((a, b) => b.created - a.created).slice(0, 300).map(c => ({ name: c.name, phone: c.phone, code: c.code, created: c.created, trial: !!c.trial, valid: codeValid(c), removed: !!c.removed,
            careBy: c.careBy || null, closedAt: c.closedAt || null, closedBy: c.closedBy || null, closedDays: c.closedDays || null, lostReason: c.lostAt && !c.closedAt ? c.lostReason : null, deposit: c.acct ? c.acct.deposit : null, expires: c.expires || null })) });
      });
      return send(res, 200, { list, site: (CONFIG.siteUrl || "").replace(/\/$/, "") });
    }
    if (req.method === "POST" && P === "/api/admin/refs") return jsonBody(req, j => {
      const L = refList(), act = String(j.action || ""), slug = String(j.slug || "").trim().toLowerCase();
      const name = String(j.name || "").trim().slice(0, 60), note = String(j.note || "").trim().slice(0, 300), contact = String(j.contact || "").trim().slice(0, 80);
      if (act === "add") {
        if (!refSlugOk(slug)) return send(res, 400, { error: "Đường dẫn chỉ gồm chữ thường không dấu, số, dấu gạch ngang (2–40 ký tự). Ví dụ: kimthuhien" });
        if (RESERVED.includes(slug) || findRef(slug)) return send(res, 409, { error: "Đường dẫn /" + slug + " đã được dùng, chọn tên khác" });
        if (name.length < 2) return send(res, 400, { error: "Nhập tên nguồn (vd Kim Thu Hiền)" });
        L.push({ slug, name, note, contact, active: true, created: Date.now(), clicks: 0, uniq: 0 }); saveAuthNow(); return send(res, 200, { ok: true });
      }
      const r = findRef(slug); if (!r) return send(res, 404, { error: "Không tìm thấy link" });
      if (act === "edit") {
        if (name.length < 2) return send(res, 400, { error: "Nhập tên nguồn" });
        if (name !== r.name) for (const c of codes.list) if (c.refSlug === r.slug) { c.ref = name; c.note = String(c.note || "").replace("Nguồn: " + r.name, "Nguồn: " + name); }   // đổi tên → cập nhật khách cũ
        r.name = name; r.note = note; r.contact = contact;
      } else if (act === "toggle") r.active = !r.active;
      else if (act === "reset") { r.clicks = 0; r.uniq = 0; }
      else if (act === "delete") {
        if (codes.list.some(c => c.refSlug === r.slug)) return send(res, 400, { error: "Link đã có khách đăng ký – chỉ tạm dừng được, không xóa để giữ số liệu" });
        codes.refs = L.filter(x => x !== r);
      } else return send(res, 400, { error: "Thao tác không hợp lệ" });
      saveAuthNow(); send(res, 200, { ok: true });
    });
    if (req.method === "POST" && P === "/api/admin/update") {
      return jsonBody(req, j => {
        const c = findCode(j.code); if (!c) return send(res, 404, { error: "Không tìm thấy mã" });
        const r = applyAction(c, j, null);
        if (r.error) return send(res, 400, r);
        saveAuthNow(); send(res, 200, { ok: true });
      });
    }
    return send(res, 404, { error: "Không có" });
  }

  // ---------- trang chính: đã có mã → chart, chưa có → trang nhập mã ----------
  if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, { error: "Không hỗ trợ" });
  if (P === "/" || P === "/index.html") {
    if (isTester(req) && url.searchParams.has("trang-nhap-ma")) return view(res, "login.html");     // admin xem thử trang nhập mã
    return view(res, customer(req) || isTester(req) ? "index.html" : "login.html");
  }
  // link giới thiệu riêng (vd /kimthuhien): ghi nhớ nguồn 30 ngày rồi mở form dùng thử
  { const slug = P.replace(/^\/+|\/+$/g, "").toLowerCase(), r = slug && findRef(slug);
    if (r) {
      if (P !== "/" + slug) { res.writeHead(302, { Location: "/" + slug + (url.search || "") }); return res.end(); }
      if (!r.active) { res.writeHead(302, { Location: "/" }); return res.end(); }     // link đang tạm dừng → trang thường, không gắn nguồn
      r.clicks = (r.clicks || 0) + 1; if (parseCookies(req).kcv_ref !== slug) r.uniq = (r.uniq || 0) + 1; dirtyRefs();
      setCookie(req, res, "kcv_ref", slug, 30 * 86400);
      return view(res, "login.html");
    } }

  // ---------- file công khai (ảnh giới thiệu, cấu hình) ----------
  const file = path.normalize(path.join(PUB, decodeURIComponent(P)));
  if (!file.startsWith(PUB + path.sep)) return send(res, 403, { error: "Cấm" });
  const ext = path.extname(file).toLowerCase();
  // Video: hỗ trợ tua (Range) – iPhone bắt buộc phải có mới phát được
  if (ext === ".mp4") {
    return fs.stat(file, (err, st) => {
      if (err) return send(res, 404, "Không tìm thấy", "text/plain; charset=utf-8");
      const range = /bytes=(\d*)-(\d*)/.exec(req.headers.range || "");
      const head = { "Content-Type": "video/mp4", "Accept-Ranges": "bytes", "Cache-Control": "public, max-age=86400" };
      if (range) {
        let start = range[1] ? parseInt(range[1], 10) : st.size - parseInt(range[2], 10);
        let end = range[1] && range[2] ? Math.min(parseInt(range[2], 10), st.size - 1) : st.size - 1;
        if (isNaN(start) || start < 0 || start >= st.size || end < start) { res.writeHead(416, { "Content-Range": "bytes */" + st.size }); return res.end(); }
        res.writeHead(206, Object.assign(head, { "Content-Range": "bytes " + start + "-" + end + "/" + st.size, "Content-Length": end - start + 1 }));
        if (req.method === "HEAD") return res.end();
        return fs.createReadStream(file, { start, end }).pipe(res);
      }
      res.writeHead(200, Object.assign(head, { "Content-Length": st.size }));
      if (req.method === "HEAD") return res.end();
      fs.createReadStream(file).pipe(res);
    });
  }
  fs.readFile(file, (err, buf) => {
    if (err) return send(res, 404, "Không tìm thấy trang", "text/plain; charset=utf-8");
    send(res, 200, buf, TYPES[ext] || "application/octet-stream");
  });
}).listen(PORT, () => console.log("Kim Chỉ Vàng đang chạy: http://localhost" + (PORT === 80 ? "" : ":" + PORT) + "   ·   Quản trị: /quan-tri"));
