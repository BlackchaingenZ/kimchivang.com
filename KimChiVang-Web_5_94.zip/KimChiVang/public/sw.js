// Kim Chỉ Vàng – nhận thông báo lệnh kể cả khi đã đóng trang (v2: bấm thông báo mở thẻ hướng dẫn vào lệnh)
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("push", e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (err) { d = { title: "Kim Chỉ Vàng", body: e.data ? e.data.text() : "" }; }
  e.waitUntil(self.registration.showNotification(d.title || "Kim Chỉ Vàng", {
    body: d.body || "", icon: d.icon || "/icon-192.png", badge: "/icon-192.png",
    tag: d.tag || undefined, renotify: true, requireInteraction: false, vibrate: [120, 60, 120],
    data: { url: d.url || "/" }
  }));
});
self.addEventListener("notificationclick", e => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || "/";
  if (/^https?:/i.test(url) && new URL(url).origin !== self.location.origin) { e.waitUntil(self.clients.openWindow(url)); return; }   // link ngoài (Zalo gia hạn): mở cửa sổ mới, giữ nguyên trang chart
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(list => {
    const want = new URL(url, self.location.origin);
    for (const c of list) if ("focus" in c) {
      const cur = new URL(c.url);
      if (cur.pathname === want.pathname && want.searchParams.get("sig")) { c.postMessage({ kcvOpen: url }); return c.focus(); }   // trang chart đang mở: hiện thẻ hướng dẫn ngay
      c.navigate && c.navigate(url).catch(() => {}); return c.focus();
    }
    return self.clients.openWindow(url);
  }));
});
