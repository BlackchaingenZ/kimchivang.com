// ============================================================================
// KIM CHỈ VÀNG EP – engine JavaScript
// Sinh lệnh theo chỉ báo "KIM CHỈ VÀNG EP – SMC ONLY [nguyeneuro] v2.0" (Pine v5):
//   1. pivot đỉnh/đáy swingLen nến → giá đóng cửa vượt đỉnh = xu hướng TĂNG, thủng đáy = xu hướng GIẢM
//   2. có đỉnh mới khi xu hướng giảm → vùng BÁN (SELL VIP) = nến tăng gần nhất trước đỉnh; điểm BÁN = đáy vùng − offset
//      có đáy mới khi xu hướng tăng  → vùng MUA (BUY VIP) = nến giảm gần nhất trước đáy; điểm MUA = đỉnh vùng + offset
//   3. giá đóng cửa xuyên qua vùng (trên đỉnh vùng bán / dưới đáy vùng mua) → xóa vùng
//   Vào lệnh: lệnh chờ – vùng còn hiệu lực (chưa bị xuyên, trong boxExtend nến) mà giá chạm điểm vào → khớp đúng mức đó.
//   Mỗi vùng khớp tối đa 1 lệnh, không giới hạn số lệnh chạy cùng lúc. Chốt lời / cắt lỗ / gồng giữ công thức cũ.
// Chỉ chạy trên các nến M1 ĐÃ ĐÓNG. bars = [{t: open ms UTC, o, h, l, c}]
// ============================================================================
const KCV_PRESETS = { "SMC": {} };
const KCV_FIXED = {
  swingLen: 5, boxExtend: 40, entryOffset: 2, obLook: 10,
  // cơ chế vào lệnh theo vùng OB: cắt lỗ ngoài vùng + slBuffer, chốt lời = rr × khoảng cắt lỗ, không gồng,
  // chỉ khớp vùng cùng chiều xu hướng (vùng ngược chiều đang chờ thì hủy), mỗi chiều tối đa maxPerDir lệnh
  roundEntry: true,           // điểm vào làm tròn số nguyên (như nhãn Pine)
  slMode: "ob", slBuffer: 2, rr: 2, trendOnly: true, maxPerDir: 1,
  tpDist: 8, slDist: 20, useDca: true, dcaDist: 10, priceUnit: 1, lateTol: 3, maxActive: Infinity,
  sessSH: 7, sessSM: 0, sessEH: 21, sessEM: 0, tzOff: 7 * 3600000, tick: 0.001
};

function kcvRun(bars, cfg) {
  const P = Object.assign({}, KCV_FIXED);
  if (cfg) for (const k in cfg) if (cfg[k] !== undefined && cfg[k] !== null && k !== "preset") P[k] = cfg[k];
  const n = bars.length;
  const O = new Array(n), H = new Array(n), L = new Array(n), C = new Array(n), T = new Array(n);
  for (let i = 0; i < n; i++) { const b = bars[i]; O[i] = b.o; H[i] = b.h; L[i] = b.l; C[i] = b.c; T[i] = b.t; }
  const rt = v => Math.round(v / P.tick) * P.tick;
  const DAY = 86400000, SL = P.swingLen;
  // ta.pivothigh / ta.pivotlow (cao hơn hẳn các nến bên trái, không thấp hơn nến bên phải)
  const pivH = i => { const c = i - SL; if (c - SL < 0) return NaN; const v = H[c];
    for (let j = c - SL; j < c; j++) if (H[j] >= v) return NaN;
    for (let j = c + 1; j <= i; j++) if (H[j] > v) return NaN; return v; };
  const pivL = i => { const c = i - SL; if (c - SL < 0) return NaN; const v = L[c];
    for (let j = c - SL; j < c; j++) if (L[j] <= v) return NaN;
    for (let j = c + 1; j <= i; j++) if (L[j] < v) return NaN; return v; };

  // ---------- state ----------
  let lastPh = NaN, lastPl = NaN, prevPh = NaN, prevPl = NaN, bullTrend = false, bearTrend = false;
  const zones = [];            // mọi vùng OB đã vẽ: {id, dir, b0, b1, top, bot, entry, made, mit, fill}
  let live = [];               // vùng chưa bị xuyên
  const trend = new Array(n).fill(0);
  let active = [];
  const sigs = [], marks = [], exits = [], rs = [];
  let nSig = 0, nTP = 0, nSL = 0, nUnk = 0, pnlAll = 0;
  let sesStartV = NaN, sesEndV = NaN, inWinV = false, cutoffV = 0;

  for (let i = 0; i < n; i++) {
    const tClose = T[i] + (P.barMs || 60000);      // giờ đóng nến (khung 1 phút mặc định; 3m/15m/1h khi xem khung lớn)
    // phiên (giờ Việt Nam)
    const dayStart = Math.floor((tClose + P.tzOff) / DAY) * DAY - P.tzOff;
    let sesDur = (P.sessEH * 60 + P.sessEM - P.sessSH * 60 - P.sessSM) * 60000; if (sesDur <= 0) sesDur += DAY;
    let sesStart = dayStart + (P.sessSH * 60 + P.sessSM) * 60000; if (tClose < sesStart) sesStart -= DAY;
    sesStartV = sesStart; sesEndV = sesStart + sesDur;
    inWinV = tClose >= sesStartV && tClose <= sesEndV;

    // A. theo dõi lệnh đang chạy (chốt lời / cắt lỗ / gồng) – giữ nguyên công thức
    for (let k = active.length - 1; k >= 0; k--) {
      const sg = active[k];
      if (!(i > sg.bar)) continue;
      const hitTP = sg.dir === 1 ? H[i] >= sg.tp : L[i] <= sg.tp;
      const hitSL = sg.dir === 1 ? L[i] <= sg.sl : H[i] >= sg.sl;
      if (hitTP || hitSL) {
        const res = hitTP && hitSL ? "?" : hitTP ? "TP" : "SL";
        const exPx = res === "TP" ? sg.tp : sg.sl;
        const pnl = (exPx - sg.entry) * sg.dir / P.priceUnit;
        pnlAll += pnl;
        if (res === "TP") nTP++; else if (res === "SL") nSL++; else nUnk++;
        sg.closedOut = tClose > sg.sesEnd;
        if (sg.inWin) rs.push({ tClose, tOpen: sg.tOpen, kind: res, pnl });
        sg.endBar = i; sg.res = res; sg.pnl = pnl; sg.exitT = tClose;
        exits.push({ bar: i, dir: sg.dir, res, pnl, add: !!sg.isAdd, y: sg.dir === 1 ? H[i] : L[i] });
        active.splice(k, 1);
      } else if (P.useDca && P.slMode === "fixed" && !sg.isAdd && !sg.added) {
        const dcaHit = sg.dir === 1 ? L[i] <= sg.addAt : H[i] >= sg.addAt;
        if (dcaHit) {
          sg.added = true; sg.tp = sg.entry; sg.tpBE = true;
          sg.boxTP = [Math.max(sg.entry, sg.addAt), Math.min(sg.entry, sg.addAt)];
          const sg2 = { id: sigs.length, dir: sg.dir, bar: i, entry: sg.addAt, tp: sg.entry, sl: sg.sl, src: "Gồng", zone: sg.zone, tOpen: sg.tOpen, tSig: tClose,
            inWin: sg.inWin, sesEnd: sg.sesEnd, isAdd: true, added: true, addAt: NaN, endBar: null, res: null, pnl: null, parent: sg.id, boxTP: null, boxSL: null };
          nSig++; sigs.push(sg2); active.push(sg2);
          marks.push({ bar: i, dir: sg.dir, dca: true, y: sg.dir === 1 ? L[i] : H[i] });
        }
      }
    }

    // B. lệnh chờ: vùng còn hiệu lực, giá chạm điểm vào → khớp đúng mức
    const OBM = P.slMode !== "fixed";            // "ob" / "points": luật vùng OB (thuận xu hướng, mỗi chiều 1 lệnh, không gồng)
    const ZSL = P.slMode === "ob";               // "ob": cắt lỗ ngoài vùng + chốt lời theo tỷ lệ · "points": lời tpDist / lỗ slDist giá
    for (const z of live) {
      if (z.fill !== null || z.cancel !== null || i <= z.made || i > z.b1) continue;
      // giá chạm điểm vào của vùng còn hiệu lực = "giá đang trong vùng MUA / BÁN" (thông báo cho khách, lần chạm đầu tiên)
      const inRange = z.dir === 1 ? L[i] <= z.entry && H[i] >= z.bot : H[i] >= z.entry && L[i] <= z.top;   // nến chạm khoảng vào lệnh
      if (z.touch === null && inRange) { z.touch = i; z.tTouch = tClose; z.inWin = inWinV; }
      if (OBM && P.maxPerDir && active.filter(a => a.dir === z.dir && !a.isAdd).length >= P.maxPerDir) continue;   // chiều này đang có lệnh
      if (inRange) {
        const d = z.dir, e = z.entry;
        let sl = ZSL ? rt(d === 1 ? z.bot - P.slBuffer : z.top + P.slBuffer) : rt(e - d * P.slDist * P.priceUnit);
        if (P.roundEntry) sl = d === 1 ? Math.floor(sl) : Math.ceil(sl);            // làm tròn số nguyên, lệch ra ngoài vùng (an toàn hơn)
        let tp = ZSL ? rt(e + d * P.rr * Math.abs(e - sl)) : rt(e + d * P.tpDist * P.priceUnit);
        if (P.roundEntry) tp = Math.round(tp);
        const sg = { id: sigs.length, dir: d, bar: i, entry: e, tp, sl, risk: Math.abs(e - sl),
          src: "OB", zone: z.id, tOpen: tClose, tSig: tClose, inWin: inWinV, sesEnd: sesEndV, isAdd: false, added: false,
          addAt: rt(e - d * P.dcaDist * P.priceUnit), endBar: null, res: null, pnl: null, tpBE: false };
        sg.tp0 = sg.tp;
        sg.boxTP = [Math.max(e, sg.tp), Math.min(e, sg.tp)];
        sg.boxSL = [Math.max(e, sg.sl), Math.min(e, sg.sl)];
        z.fill = i; z.sig = sg.id;
        nSig++; sigs.push(sg); active.push(sg);
        marks.push({ bar: i, dir: d, dca: false, y: d === 1 ? L[i] : H[i] });
      }
    }

    // C. 1. xu hướng (swing & trend)
    const ph = pivH(i), pl = pivL(i);
    if (!isNaN(ph)) lastPh = ph;
    if (!isNaN(pl)) lastPl = pl;
    const cPrev = i > 0 ? C[i - 1] : NaN;
    // ta.crossover / ta.crossunder giữ lịch sử của GIÁ TRỊ ĐƯỢC TRUYỀN VÀO lúc gọi hàm (trước khi bị gán na),
    // không phải giá trị cuối nến của biến → "phía trước" = last_ph_val tại thời điểm gọi ở nến trước
    const phCall = lastPh, plCall = lastPl;
    const xo = C[i] > phCall && cPrev <= prevPh, xu = C[i] < plCall && cPrev >= prevPl;
    prevPh = phCall; prevPl = plCall;
    if (xo) { bullTrend = true; bearTrend = false; lastPh = NaN; }     // if ta.crossover(close, last_ph_val)
    if (xu) { bearTrend = true; bullTrend = false; lastPl = NaN; }     // if ta.crossunder(close, last_pl_val)
    trend[i] = bullTrend ? 1 : bearTrend ? -1 : 0;
    if (P.slMode !== "fixed" && P.trendOnly && trend[i] !== 0)
      for (const z of live) if (z.fill === null && z.cancel === null && z.dir !== trend[i]) z.cancel = i;   // xu hướng đổi chiều → hủy lệnh chờ ngược chiều

    // C. 2. vùng Order Block
    if (!isNaN(ph) && bearTrend) {
      let k = 0; for (let j = 1; j <= P.obLook; j++) { const b = i - SL - j; if (b >= 0 && C[b] > O[b]) { k = j; break; } }
      if (k > 0) { const b = i - SL - k; const z = { id: zones.length, dir: -1, b0: b, b1: b + P.boxExtend, top: H[b], bot: L[b], entry: P.roundEntry ? Math.round(L[b] - P.entryOffset) : rt(L[b] - P.entryOffset), made: i, t0: T[b], mit: null, fill: null, sig: null, cancel: null, touch: null };
        zones.push(z); live.push(z); }
    }
    if (!isNaN(pl) && bullTrend) {
      let k = 0; for (let j = 1; j <= P.obLook; j++) { const b = i - SL - j; if (b >= 0 && C[b] < O[b]) { k = j; break; } }
      if (k > 0) { const b = i - SL - k; const z = { id: zones.length, dir: 1, b0: b, b1: b + P.boxExtend, top: H[b], bot: L[b], entry: P.roundEntry ? Math.round(H[b] + P.entryOffset) : rt(H[b] + P.entryOffset), made: i, t0: T[b], mit: null, fill: null, sig: null, cancel: null, touch: null };
        zones.push(z); live.push(z); }
    }
    // C. 3. xóa vùng khi giá đóng cửa xuyên qua
    for (const z of live) if (z.dir === -1 ? C[i] > z.top : C[i] < z.bot) z.mit = i;
    live = live.filter(z => z.mit === null);
    // vùng vừa xuất hiện mà giá đóng cửa ĐANG nằm trong khoảng vào lệnh (MUA: đáy vùng → điểm vào, BÁN: điểm vào → đỉnh vùng)
    // → tính là "giá đang trong vùng" ngay nến này, không chờ nến sau
    for (const z of live) if (z.made === i && z.touch === null && z.cancel === null && (z.dir === 1 ? C[i] <= z.entry && C[i] >= z.bot : C[i] >= z.entry && C[i] <= z.top)) { z.touch = i; z.tTouch = tClose; z.inWin = inWinV; }
    cutoffV = sesStartV;
  }

  // ---------- thống kê phiên ----------
  let wWin = 0, wLoss = 0, wBe = 0, wNet = 0;
  for (const r of rs) {
    if (r.tClose >= cutoffV && r.tOpen >= cutoffV) {
      wNet += r.pnl;
      if (r.pnl > 0) wWin++; else if (r.pnl < 0) wLoss++; else wBe++;
    }
  }
  const last = n - 1, trendDir = n ? trend[last] : 0;
  const pending = live.filter(z => z.fill === null && z.cancel === null && last <= z.b1);          // lệnh chờ còn hiệu lực
  return {
    P, n, sigs, marks, exits, tls: [], active, trendDir, trend, zones, live, pending,
    structWhy: trendDir === 0 ? "Chưa có phá cấu trúc" : "",
    stats: { wWin, wLoss, wBe, wNet, nSig, nTP, nSL, nUnk, pnlAll },
    session: { start: sesStartV, end: sesEndV, inWin: inWinV }
  };
}

// ============================================================================
// TỔNG KẾT TUẦN / THÁNG – chỉ lệnh vào và đóng trong 07:00–21:00 (giờ VN)
// Làm mới mỗi tháng: chỉ tính các lệnh vào trong tháng hiện tại.
// ============================================================================
function kcvSummary(res, nowMs) {
  const TZ = 7 * 3600000, DAY = 86400000;
  const vn = t => new Date(t + TZ);
  const now = vn(nowMs), Y = now.getUTCFullYear(), M = now.getUTCMonth();
  const monthStart = Date.UTC(Y, M, 1) - TZ, monthEnd = Date.UTC(Y, M + 1, 1) - TZ;   // mốc UTC
  const dayKey = t => { const d = vn(t); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()); }; // ms của 00:00 VN (tính như UTC)
  const blank = () => ({ n: 0, win: 0, loss: 0, be: 0, net: 0 });
  const add = (g, s) => { g.n++; g.net += s.pnl; if (s.pnl > 0) g.win++; else if (s.pnl < 0) g.loss++; else g.be++; };
  const fin = g => { g.net = Math.round(g.net * 100) / 100; g.rate = g.n ? Math.round(g.win / g.n * 100) : null; return g; };
  const trades = res.sigs.filter(s => s.res !== null && s.inWin && s.tOpen >= monthStart && s.tOpen < monthEnd);
  const total = blank(), days = new Map();
  for (const s of trades) { add(total, s); const k = dayKey(s.tOpen); if (!days.has(k)) days.set(k, blank()); add(days.get(k), s); }
  // các tuần (thứ 2 → CN), cắt theo tháng, tới tuần hiện tại
  const first = Date.UTC(Y, M, 1), last = Date.UTC(Y, M + 1, 0), today = dayKey(nowMs);
  const weeks = [];
  let ws = first, idx = 1;
  while (ws <= Math.min(last, today)) {
    const dow = (new Date(ws).getUTCDay() + 6) % 7;            // 0 = thứ 2
    const we = Math.min(last, ws + (6 - dow) * DAY);
    const g = blank();
    for (const [k, v] of days) if (k >= ws && k <= we) { g.n += v.n; g.win += v.win; g.loss += v.loss; g.be += v.be; g.net += v.net; }
    weeks.push(Object.assign(fin(g), { idx: idx++, from: ws, to: we, current: today >= ws && today <= we }));
    ws = we + DAY;
  }
  const dayList = [...days.entries()].sort((a, b) => a[0] - b[0]).map(([k, v]) => Object.assign(fin(v), { day: k }));
  let best = null, worst = null;
  for (const d of dayList) { if (!best || d.net > best.net) best = d; if (!worst || d.net < worst.net) worst = d; }
  return { month: M + 1, year: Y, total: fin(total), weeks, days: dayList, best, worst, tradingDays: dayList.length, updated: nowMs };
}
if (typeof module !== "undefined") module.exports = { kcvRun, kcvSummary, KCV_PRESETS, KCV_FIXED };
