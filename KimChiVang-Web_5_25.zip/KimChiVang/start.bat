@echo off
chcp 65001 >nul
title Kim Chi Vang - may chu gia
REM 1) Ma bi mat cho EA: nhap dung ma nay vao o Token cua EA KCV_PriceFeed
set KCV_TOKEN=doi-ma-bi-mat-nay
REM 2) Mat khau trang quan tri  kimchivang.com/quan-tri  (doi thanh mat khau rieng, khong dau)
set KCV_ADMIN=doi-mat-khau-quan-tri
REM 3) (Tuy chon) Tu gui tin lenh NOI BO vao nhom Telegram: dien token bot va ID nhom, de trong neu khong dung
set KCV_TG_TOKEN=
set KCV_TG_CHAT=
set PORT=80
cd /d %~dp0
:loop
node server.js
echo May chu dung, tu khoi dong lai sau 5 giay...
timeout /t 5 >nul
goto loop
