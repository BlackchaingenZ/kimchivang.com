// ============================================================================
// Web Push không cần thư viện ngoài (RFC 8291 aes128gcm + RFC 8292 VAPID)
// ============================================================================
"use strict";
const crypto = require("crypto");
const fs = require("fs");

const b64u = buf => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64u = s => Buffer.from(String(s).replace(/-/g, "+").replace(/_/g, "/"), "base64");

// Khóa VAPID: tạo 1 lần, lưu file để các thiết bị đã đăng ký không bị mất
function loadVapid(file) {
  try { const v = JSON.parse(fs.readFileSync(file, "utf8")); if (v.publicKey && v.privateJwk) return v; } catch (e) {}
  const { publicKey, privateKey } = crypto.generateKeyPairSync("ec", { namedCurve: "prime256v1" });
  const jwk = privateKey.export({ format: "jwk" });
  const pub = Buffer.concat([Buffer.from([4]), unb64u(jwk.x), unb64u(jwk.y)]);
  const v = { publicKey: b64u(pub), privateJwk: jwk };
  fs.writeFileSync(file, JSON.stringify(v));
  return v;
}

function vapidHeader(endpoint, vapid, subject) {
  const aud = new URL(endpoint).origin;
  const head = b64u(JSON.stringify({ typ: "JWT", alg: "ES256" }));
  const body = b64u(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: subject }));
  const key = crypto.createPrivateKey({ key: vapid.privateJwk, format: "jwk" });
  const sig = crypto.sign("sha256", Buffer.from(head + "." + body), { key, dsaEncoding: "ieee-p1363" });
  return "vapid t=" + head + "." + body + "." + b64u(sig) + ", k=" + vapid.publicKey;
}

function encrypt(payload, p256dh, auth) {
  const uaPublic = unb64u(p256dh), authSecret = unb64u(auth);
  const ecdh = crypto.createECDH("prime256v1"); ecdh.generateKeys();
  const asPublic = ecdh.getPublicKey();
  const shared = ecdh.computeSecret(uaPublic);
  const keyInfo = Buffer.concat([Buffer.from("WebPush: info\0"), uaPublic, asPublic]);
  const ikm = Buffer.from(crypto.hkdfSync("sha256", shared, authSecret, keyInfo, 32));
  const salt = crypto.randomBytes(16);
  const cek = Buffer.from(crypto.hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: aes128gcm\0"), 16));
  const nonce = Buffer.from(crypto.hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: nonce\0"), 12));
  const c = crypto.createCipheriv("aes-128-gcm", cek, nonce);
  const ct = Buffer.concat([c.update(Buffer.concat([Buffer.from(payload), Buffer.from([2])])), c.final(), c.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([asPublic.length]), asPublic, ct]);
}

// Gửi 1 thông báo. Trả về mã HTTP (201 = thành công, 404/410 = thiết bị đã hủy đăng ký)
async function sendPush(sub, data, vapid, subject) {
  const body = encrypt(JSON.stringify(data), sub.keys.p256dh, sub.keys.auth);
  const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), 10000);
  try {
    const r = await fetch(sub.endpoint, {
      method: "POST", signal: ctrl.signal,
      headers: { "Content-Type": "application/octet-stream", "Content-Encoding": "aes128gcm", "TTL": "1800", "Urgency": "high",
        "Authorization": vapidHeader(sub.endpoint, vapid, subject) },
      body
    });
    return r.status;
  } catch (e) { return 0; } finally { clearTimeout(to); }
}

module.exports = { loadVapid, sendPush, encrypt, vapidHeader, b64u, unb64u };
