// ============================================================================
// Kim Chỉ Vàng – máy chủ nhận giá MT5, khóa trang bằng mã khách hàng, phục vụ web
// Chạy:  node server.js        (cần Node.js 18 trở lên, không cần cài thư viện)
// Biến môi trường (đặt trong start.bat):
//   KCV_TOKEN  mã bí mật, phải trùng với ô Token trong EA
//   KCV_ADMIN  mật khẩu trang quản trị /quan-tri
//   PORT       cổng web (mặc định 80 – MT5 chỉ gửi được qua cổng 80/443)
// ============================================================================
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = parseInt(process.env.PORT || "80", 10);
const TOKEN = process.env.KCV_TOKEN || "doi-ma-bi-mat-nay";
const ADMIN_PASS = process.env.KCV_ADMIN || "doi-mat-khau-quan-tri";
const ROOT = __dirname;
const PUB = path.join(ROOT, "public");
const VIEWS = path.join(ROOT, "views");
const DATA = path.join(ROOT, "data.json");
const CODES_FILE = path.join(ROOT, "codes.json");
const SESS_FILE = path.join(ROOT, "sessions.json");
const MAX_BARS = 3000;           // số nến máy chủ giữ
const SEND_BARS = 3000;          // số nến gửi cho trang web
const SESSION_DAYS = 90;         // khách đăng nhập 1 lần, giữ 90 ngày
const CONFIG = require("./public/config.js");

if (TOKEN === "doi-ma-bi-mat-nay") console.warn("⚠  Đang dùng Token mặc định. Hãy đổi KCV_TOKEN (trong start.bat) và Token trong EA.");
if (ADMIN_PASS === "doi-mat-khau-quan-tri") console.warn("⚠  Đang dùng mật khẩu quản trị mặc định. Hãy đổi KCV_ADMIN trong start.bat.");

// ---------- lưu file an toàn ----------
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { return d; } };
function saveJson(f, obj) { const tmp = f + ".tmp"; fs.writeFile(tmp, JSON.stringify(obj), err => { if (!err) fs.rename(tmp, f, () => {}); }); }

// ---------- dữ liệu giá ----------
let state = readJson(DATA, null);
if (!state || !Array.isArray(state.bars)) state = { symbol: "XAUUSD", digits: 3, updated: 0, bars: [] };
else console.log("Đã đọc", state.bars.length, "nến từ data.json");
let dirty = false;
setInterval(() => { if (dirty) { dirty = false; saveJson(DATA, state); } }, 15000);
function merge(incoming) {
  const map = new Map(state.bars.map(b => [b[0], b]));
  for (const b of incoming) {
    if (!Array.isArray(b) || b.length < 5) continue;
    const v = b.slice(0, 5).map(Number);
    if (!v.every(Number.isFinite) || v[0] % 60 !== 0) continue;
    map.set(v[0], v);
  }
  state.bars = [...map.values()].sort((a, b) => a[0] - b[0]).slice(-MAX_BARS);
}


// ============================================================================
// MÃ KHÁCH HÀNG & PHIÊN ĐĂNG NHẬP
// ============================================================================
let codes = readJson(CODES_FILE, { list: [] });          // {code,name,note,created,expires,maxDevices,active}
let sessions = readJson(SESS_FILE, {});                    // token -> {code,created,lastSeen,ua,ip}
let adminSessions = new Map();                             // token -> expires
let authDirty = false;
setInterval(() => { if (authDirty) { authDirty = false; saveJson(CODES_FILE, codes); saveJson(SESS_FILE, sessions); } }, 10000);
const saveAuthNow = () => { authDirty = false; saveJson(CODES_FILE, codes); saveJson(SESS_FILE, sessions); };

const normCode = s => String(s || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
const findCode = c => codes.list.find(x => normCode(x.code) === normCode(c));
const ALPH = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";      // bỏ chữ dễ nhầm O/0, I/1, L
function newCode() {
  let c;
  do { const b = crypto.randomBytes(8); c = "KCV-" + [...b.slice(0, 4)].map(x => ALPH[x % ALPH.length]).join("") + "-" + [...b.slice(4)].map(x => ALPH[x % ALPH.length]).join(""); }
  while (findCode(c));
  return c;
}
const codeValid = c => c && c.active && (!c.expires || c.expires > Date.now());
const devicesOf = code => Object.entries(sessions).filter(([, s]) => normCode(s.code) === normCode(code));

function parseCookies(req) {
  const out = {}; (req.headers.cookie || "").split(";").forEach(p => { const i = p.indexOf("="); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}
function isHttps(req) { return req.headers["x-forwarded-proto"] === "https" || /https/.test(req.headers["cf-visitor"] || ""); }
function setCookie(req, res, name, val, maxAgeSec) {
  const c = name + "=" + encodeURIComponent(val) + "; Path=/; HttpOnly; SameSite=Lax; Max-Age=" + maxAgeSec + (isHttps(req) ? "; Secure" : "");
  const prev = res.getHeader("Set-Cookie"); res.setHeader("Set-Cookie", prev ? [].concat(prev, c) : c);
}
function clientIp(req) { return req.headers["cf-connecting-ip"] || (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || req.socket.remoteAddress || ""; }

// Phiên khách: trả về {token, sess, code} hoặc null
function customer(req) {
  const t = parseCookies(req).kcv_s; if (!t || !sessions[t]) return null;
  const s = sessions[t], c = findCode(s.code);
  if (!codeValid(c) || s.created + SESSION_DAYS * 86400000 < Date.now()) { delete sessions[t]; authDirty = true; return null; }
  const now = Date.now(); if (now - (s.lastSeen || 0) > 60000) { s.lastSeen = now; authDirty = true; }
  return { token: t, sess: s, code: c };
}
function isAdmin(req) { const t = parseCookies(req).kcv_a; const e = t && adminSessions.get(t); if (e && e > Date.now()) return true; if (t) adminSessions.delete(t); return false; }

// Chống dò mã: tối đa 8 lần sai / 15 phút / IP
const fails = new Map();
function tooMany(ip) { const f = fails.get(ip); return f && f.n >= 8 && f.until > Date.now(); }
function addFail(ip) { const f = fails.get(ip); if (!f || f.until < Date.now()) fails.set(ip, { n: 1, until: Date.now() + 15 * 60000 }); else f.n++; }

// ============================================================================
// WEB
// ============================================================================
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".json": "application/json" };
function send(res, code, body, type) {
  res.writeHead(code, { "Content-Type": type || "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Frame-Options": "SAMEORIGIN" });
  res.end(typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function view(res, name) {
  fs.readFile(path.join(VIEWS, name), (err, buf) => err ? send(res, 500, "Thiếu file " + name, "text/plain; charset=utf-8") : send(res, 200, buf, TYPES[".html"]));
}
function readBody(req, limit, cb) {
  let body = "", size = 0, dead = false;
  req.on("data", c => { size += c.length; if (size > limit) { dead = true; req.destroy(); } else body += c; });
  req.on("end", () => { if (!dead) cb(body); });
}
const jsonBody = (req, cb) => readBody(req, 20000, b => { let j = {}; try { j = JSON.parse(b || "{}"); } catch (e) {} cb(j); });

http.createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  const P = url.pathname;

  // ---------- EA đẩy giá ----------
  if (req.method === "POST" && P === "/api/push") {
    if (req.headers["x-token"] !== TOKEN) return send(res, 401, { error: "Sai Token" });
    return readBody(req, 8e6, body => {
      try {
        const j = JSON.parse(body);
        if (!Array.isArray(j.bars)) throw new Error("thiếu bars");
        merge(j.bars);
        if (j.symbol) state.symbol = String(j.symbol).slice(0, 24);
        if (Number.isInteger(j.digits)) state.digits = j.digits;
        state.updated = Date.now(); dirty = true;
        send(res, 200, { ok: true, bars: state.bars.length });
      } catch (e) { send(res, 400, { error: "Dữ liệu không hợp lệ: " + e.message }); }
    });
  }

  // ---------- khách đăng nhập / đăng xuất ----------
  if (req.method === "POST" && P === "/api/login") {
    const ip = clientIp(req);
    if (tooMany(ip)) return send(res, 429, { error: "Nhập sai quá nhiều lần. Vui lòng thử lại sau 15 phút." });
    return jsonBody(req, j => {
      const c = findCode(j.code);
      if (!c) { addFail(ip); return send(res, 401, { error: "Mã truy cập không đúng. Kiểm tra lại hoặc nhắn Zalo để được cấp mã." }); }
      if (!c.active) return send(res, 403, { error: "Mã này đã bị khóa. Vui lòng liên hệ Zalo để được hỗ trợ." });
      if (c.expires && c.expires <= Date.now()) return send(res, 403, { error: "Mã này đã hết hạn. Vui lòng liên hệ Zalo để gia hạn." });
      // Giới hạn thiết bị: vượt quá thì đăng xuất thiết bị cũ nhất
      const devs = devicesOf(c.code).sort((a, b) => (a[1].lastSeen || a[1].created) - (b[1].lastSeen || b[1].created));
      while (devs.length >= (c.maxDevices || 2)) { delete sessions[devs.shift()[0]]; }
      const t = crypto.randomBytes(24).toString("hex");
      sessions[t] = { code: c.code, created: Date.now(), lastSeen: Date.now(), ua: String(req.headers["user-agent"] || "").slice(0, 160), ip };
      c.lastLogin = Date.now(); saveAuthNow();
      setCookie(req, res, "kcv_s", t, SESSION_DAYS * 86400);
      send(res, 200, { ok: true, name: c.name || "" });
    });
  }
  if (req.method === "POST" && P === "/api/logout") {
    const cu = customer(req); if (cu) { delete sessions[cu.token]; saveAuthNow(); }
    setCookie(req, res, "kcv_s", "", 0); return send(res, 200, { ok: true });
  }

  // ---------- dữ liệu cho khách đã đăng nhập ----------
  if (req.method === "GET" && (P === "/api/bars" || P === "/api/me")) {
    const cu = customer(req);
    if (!cu) return send(res, 401, { error: "Chưa đăng nhập" });
    if (P === "/api/me") return send(res, 200, { name: cu.code.name || "", expires: cu.code.expires || null });
    const since = parseInt(url.searchParams.get("since") || "0", 10) || 0;
    const bars = since ? state.bars.filter(b => b[0] >= since) : state.bars.slice(-SEND_BARS);
    return send(res, 200, { symbol: state.symbol, digits: state.digits, updated: state.updated, now: Date.now(), bars });
  }

  // ---------- quản trị ----------
  if (P === "/quan-tri" || P === "/quan-tri/") return view(res, "admin.html");
  if (req.method === "POST" && P === "/api/admin/login") {
    const ip = clientIp(req);
    if (tooMany(ip)) return send(res, 429, { error: "Sai quá nhiều lần, thử lại sau 15 phút." });
    return jsonBody(req, j => {
      const a = Buffer.from(String(j.password || "")), b = Buffer.from(ADMIN_PASS);
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) { addFail(ip); return send(res, 401, { error: "Sai mật khẩu" }); }
      const t = crypto.randomBytes(24).toString("hex"); adminSessions.set(t, Date.now() + 12 * 3600000);
      setCookie(req, res, "kcv_a", t, 12 * 3600); send(res, 200, { ok: true });
    });
  }
  if (P.startsWith("/api/admin/")) {
    if (!isAdmin(req)) return send(res, 401, { error: "Chưa đăng nhập quản trị" });
    if (req.method === "POST" && P === "/api/admin/logout") { adminSessions.delete(parseCookies(req).kcv_a); setCookie(req, res, "kcv_a", "", 0); return send(res, 200, { ok: true }); }
    if (req.method === "GET" && P === "/api/admin/codes") {
      const list = codes.list.map(c => {
        const devs = devicesOf(c.code).map(([, s]) => s);
        return Object.assign({}, c, { devices: devs.length, lastSeen: devs.reduce((m, s) => Math.max(m, s.lastSeen || 0), 0) || null, valid: codeValid(c) });
      }).sort((a, b) => b.created - a.created);
      return send(res, 200, { list, feed: { updated: state.updated, bars: state.bars.length } });
    }
    if (req.method === "POST" && P === "/api/admin/codes") {
      return jsonBody(req, j => {
        const name = String(j.name || "").trim().slice(0, 80);
        if (!name) return send(res, 400, { error: "Nhập tên khách" });
        const days = parseInt(j.days, 10) || 0;
        const c = { code: newCode(), name, note: String(j.note || "").slice(0, 200), created: Date.now(),
          expires: days > 0 ? Date.now() + days * 86400000 : null, maxDevices: Math.max(1, Math.min(5, parseInt(j.maxDevices, 10) || 2)), active: true };
        codes.list.push(c); saveAuthNow(); send(res, 200, c);
      });
    }
    if (req.method === "POST" && P === "/api/admin/update") {
      return jsonBody(req, j => {
        const c = findCode(j.code); if (!c) return send(res, 404, { error: "Không tìm thấy mã" });
        const kick = () => devicesOf(c.code).forEach(([t]) => delete sessions[t]);
        if (j.action === "lock") { c.active = false; kick(); }
        else if (j.action === "unlock") c.active = true;
        else if (j.action === "reset") kick();
        else if (j.action === "extend") { const d = parseInt(j.days, 10) || 30; c.expires = Math.max(Date.now(), c.expires || Date.now()) + d * 86400000; }
        else if (j.action === "forever") c.expires = null;
        else if (j.action === "delete") { kick(); codes.list = codes.list.filter(x => x !== c); }
        else return send(res, 400, { error: "Thao tác không hợp lệ" });
        saveAuthNow(); send(res, 200, { ok: true });
      });
    }
    return send(res, 404, { error: "Không có" });
  }

  // ---------- trang chính: đã có mã → chart, chưa có → trang nhập mã ----------
  if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, { error: "Không hỗ trợ" });
  if (P === "/" || P === "/index.html") return view(res, customer(req) ? "index.html" : "login.html");

  // ---------- file công khai (ảnh giới thiệu, cấu hình) ----------
  const file = path.normalize(path.join(PUB, decodeURIComponent(P)));
  if (!file.startsWith(PUB + path.sep)) return send(res, 403, { error: "Cấm" });
  fs.readFile(file, (err, buf) => {
    if (err) return send(res, 404, "Không tìm thấy trang", "text/plain; charset=utf-8");
    send(res, 200, buf, TYPES[path.extname(file).toLowerCase()] || "application/octet-stream");
  });
}).listen(PORT, () => console.log("Kim Chỉ Vàng đang chạy: http://localhost" + (PORT === 80 ? "" : ":" + PORT) + "   ·   Quản trị: /quan-tri"));
