// ============================================================================
// CẤU HÌNH KIM CHỈ VÀNG – dùng chung cho trang web và máy chủ
// Sửa xong: lưu file, tắt start.bat rồi bật lại.
// ============================================================================
var KCV_CONFIG = {
  preset: "Cân bằng",      // "Chặt (v1)" | "Cân bằng" | "Nhiều tín hiệu"
  tpDist: 8,               // chốt lời (giá)
  slDist: 20,              // cắt lỗ (giá)
  dcaDist: 10,             // khoảng gồng (giá)
  useDca: true,            // gồng thêm 1 lệnh
  groupUrl: "https://zalo.me/g/n0klfsnyret89urnzzec",   // link nhóm Zalo tư vấn
  accountUrl: "https://zalo.me/0886558169",            // link Zalo liên hệ tư vấn (nút thứ 2)
  hotline: "",             // số hiển thị dưới nút (để trống = ẩn)
  siteUrl: "https://kimchivang.com",   // địa chỉ web (dùng cho thông báo)
  notifyEntries: true,     // thông báo khi có lệnh vào mới (kể cả gồng)
  notifyExits: true,       // thông báo khi lệnh đóng (ăn / lỗ / hòa)
  notifySessionOnly: true, // chế độ mặc định khi khách bật thông báo: true = trong phiên 07:00–21:00, false = cả 24 giờ (khách tự đổi được)
  trialMinutes: 300,       // thời gian dùng thử (phút) – đếm liên tục kể từ lúc đăng ký / mở mã lần đầu
  sessStart: 7,            // giờ bắt đầu phiên (giờ VN)
  sessEnd: 21,             // giờ kết thúc phiên
  // ---- Tin nhắn NỘI BỘ cho nhân viên ----
  capitals: [20000, 5000, 3000, 1000],  // các mức vốn (USD) hiện trong tin và bảng quy đổi theo vốn
  // Link giới thiệu ban đầu (kimchivang.com/kimthuhien). Chỉ dùng cho LẦN CHẠY ĐẦU TIÊN –
  // sau đó thêm / sửa / tạm dừng link tại trang quản trị → mục "🔗 Link giới thiệu".
  refLinks: {
    "kimthuhien": "Kim Thu Hiền",
  },
  // Trợ lý cấp mã (hiện ở trang đăng nhập, khi dùng thử và khi hết giờ dùng thử)
  assistants: [
    { name: "Lan Anh", phone: "0878587386" },
    { name: "Minh Anh", phone: "0586532206" },
  ],
  axisStep: 2,             // biểu đồ: khoảng cách vạch giá ở cột giá bên phải (2 = 4220 · 4218 · 4216)
  lotPer1000: 0.04,        // khối lượng cho mỗi 1.000 USD vốn (20.000 USD → 0.8 lot)
  usdVnd: 26000,           // tỷ giá quy đổi USD → VNĐ (tham khảo) cho bảng "Quy đổi theo vốn"
  internalMention: "@All"  // dòng gắn thẻ cuối tin ("" để bỏ)
};
if (typeof module !== "undefined") module.exports = KCV_CONFIG;
